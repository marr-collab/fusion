# Energy is not phase: executable frozen-carrier demonstration

Run from this folder:

```text
python -m pip install -r requirements.txt
python reproduce.py
```

Python 3.12 was used. No historical Atlas directory or network data download is needed after installing NumPy/SciPy. The matrix, fast eigenvector, original receipt and original algorithm are included. `result.json` and `execution.txt` contain the new execution. Running again overwrites only these two outputs.

The data are the actual 1,243-coordinate frozen electromagnetic–material–alpha carrier from Phase_Return. `krylov_original.py` extracts the original `phi` and `Krylov` definitions without algorithm changes; their complete original source is retained under `historical_source/`. `input_manifest.json` checks the immutable inputs.

The plotted energy is E/E(0), where E=0.5*y.T@y in the original physical-energy coordinates. The selected fast eigenmode is unit norm. The full-matrix implicit midpoint solve and the original reciprocal Hermitian-Krylov exponential are compared against the exact solution of the archived eigenpair. Four fixed 2 ns steps produce the energy samples; phase lines join step boundaries, not resolved substeps.

The original receipt gives midpoint state error 1.4543444332813 and exponential error 5.822489879473e-12. The public-release execution gives 1.4543444332813 and approximately 5.99594e-12. Floating-point/library execution can change the last tiny residual; the historical value is not substituted for the rerun. The invariant-plane residual is checked against the full matrix.

This is an executable test of frozen phase action, not a claim that the full nonlinear plasma can be advanced accurately at any large step. The associated historical program contains separate nonlinear coupling, pressure, source and support tests. Energy transfer depends on the current–field phase; this demonstration does not calculate a new alpha gain or device output.

The 56-second video is a visualization of this receipt. It is silent with on-screen explanations, has no fabricated terminal execution, and labels both archived and fresh errors. Original authors: R. Wade H. Marr and Joseph Adam Thiel. Rights are selected by the depositors; historical third-party notices remain applicable.
