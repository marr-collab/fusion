Optional MP4 regeneration, Windows with Arial/Consolas system fonts:
python -m pip install -r video_source/requirements-video.txt
python video_source/render_video.py

The scientific receipt is regenerated separately with python reproduce.py.
Rendering writes video_output/. It does not change the archived carrier or equations.
Fonts and FFmpeg are runtime dependencies, not bundled research inputs.
