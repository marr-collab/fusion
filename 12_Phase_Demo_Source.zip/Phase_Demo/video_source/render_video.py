"""Captioned scientific animation from recorded numerical arrays, not generated imagery."""
from pathlib import Path
import json,math,subprocess,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import imageio_ffmpeg
R=Path(__file__).resolve().parents[1];D=R;V=R/'video_output';V.mkdir(exist_ok=True);Q=R/'video_output/checks';Q.mkdir(parents=True,exist_ok=True)
r=json.loads((D/'result.json').read_text(encoding='utf-8'));fps=30;duration=56;W,H=1280,720
BG='#0b1b29';WHITE='#f4f7fa';MUTED='#afc5d3';TEAL='#40d9c2';ORANGE='#ffae61';BLUE='#84b6ff';GRID='#29404e';PANEL='#112c3e'
fonts={}
def font(n,bold=False,mono=False):
 key=(n,bold,mono)
 if key not in fonts:fonts[key]=ImageFont.truetype('C:/Windows/Fonts/'+('consola.ttf' if mono else 'arialbd.ttf' if bold else 'arial.ttf'),n)
 return fonts[key]
def txt(d,xy,s,n=30,c=WHITE,b=False,mono=False):d.text(xy,s,font=font(n,b,mono),fill=c,spacing=9)
def scientific(d,xy,mant,exponent,n=54,c=TEAL):
 text=mant+' × 10';txt(d,xy,text,n,c,True)
 width=d.textlength(text,font=font(n,True));txt(d,(xy[0]+width+3,xy[1]-2),str(exponent),int(n*.6),c,True)
def lines(d,xy,s,n=30,c=WHITE,b=False):
 for j,line in enumerate(s.split('\n')):txt(d,(xy[0],xy[1]+j*(n+12)),line,n,c,b)
def panel(d,box):d.rounded_rectangle(box,radius=20,fill=PANEL)
def dot(d,x,y,c,r=8):d.ellipse((x-r,y-r,x+r,y+r),fill=c)
def base(t,title,kicker='ADDRESS-FIRST FUSION  /  EXECUTABLE RECEIPT'):
 im=Image.new('RGB',(W,H),BG);d=ImageDraw.Draw(im)
 txt(d,(50,26),kicker,20,MUTED,True);txt(d,(50,76),title,46,WHITE,True)
 txt(d,(50,665),'Marr & Thiel  •  Frozen electromagnetic–plasma carrier',21,MUTED)
 d.rectangle((0,709,int(W*t/duration),719),fill=TEAL)
 return im,d
def axes(d,box,xlabels,ylabels,xname,yname):
 x0,y0,x1,y1=box
 for val,label in ylabels:
  y=y1-(y1-y0)*val;d.line((x0,y,x1,y),fill=GRID,width=2);txt(d,(x0-90,y-13),label,23,MUTED)
 for val,label in xlabels:
  x=x0+(x1-x0)*val;d.line((x,y0,x,y1),fill=GRID,width=1);txt(d,(x-10,y1+12),label,24,MUTED)
 txt(d,(x0,y0-38),yname,24,MUTED);txt(d,(x1-195,y1+48),xname,24,MUTED)
def frame(t):
 if t<5.5:
  im,d=base(t,'We preserved the electromagnetic phase.')
  panel(d,(50,175,1230,545));lines(d,(92,210),'A fast plasma–field clock.\nA reciprocal exponential.\nIts physical phase retained.',44,WHITE,True)
  txt(d,(92,443),'Constructed and tested on the same carrier.',32,TEAL,True)
  txt(d,(52,585),'The numerical comparison shows the operation.',33,WHITE)
 elif t<12:
  im,d=base(t,'The same physical numerical carrier')
  panel(d,(50,167,775,590));lines(d,(80,193),'1,243 coupled coordinates\nElectron–ion–alpha currents + fields\nReactive containing constraint',32)
  txt(d,(80,365),'Selected fast phase: 2.229 ps per cycle',31,TEAL,True)
  txt(d,(80,425),'Time step: 2 ns',40,WHITE,True)
  txt(d,(80,493),'About 897 physical cycles in one step.',28,MUTED)
  panel(d,(800,167,1230,590));txt(d,(830,205),'Quadratic energy',29,MUTED)
  txt(d,(830,274),'E = ½ yᵀy',44,WHITE,True)
  lines(d,(830,367),'Physical energy\ncoordinates.\nUnit-norm fast mode.',29)
 elif t<23:
  im,d=base(t,'Both preserve the quadratic energy')
  txt(d,(85,153),'Implicit midpoint',26,ORANGE,True);txt(d,(590,153),'Reciprocal exponential',26,TEAL,True)
  box=(155,245,1160,490);axes(d,box,[(x/8,str(x)) for x in [0,2,4,6,8]],[(0,'0.9999'),(.5,'1.0000'),(1,'1.0001')],'Time [ns]','Normalized energy E / E(0)')
  n=min(4,int((t-12)/2.0));x0,y0,x1,y1=box
  for key,col in [('midpoint_energy_ratio',ORANGE),('exponential_energy_ratio',TEAL)]:
   pts=[(x0+(x1-x0)*row['t_ns']/8,y1-(y1-y0)*(.5+(row[key]-1)/.0002)) for row in r['steps'][:n+1]]
   if len(pts)>1:d.line(pts,fill=col,width=4)
   for x,y in pts:
    if col==ORANGE:d.rectangle((x-9,y-9,x+9,y+9),outline=col,width=3)
    else:dot(d,x,y,col,4)
  txt(d,(75,590),'Computed energy drift stays below 3e-15 over four steps.',29,WHITE)
 elif t<34:
  im,d=base(t,'The exponential retains the actual phase')
  txt(d,(85,150),'Exact phase / exponential',25,TEAL,True);txt(d,(680,150),'Midpoint phase',25,ORANGE,True)
  box=(145,233,800,490);axes(d,box,[(x/8,str(x)) for x in [0,2,4,6,8]],[(0,'0'),(.5,'2,000'),(1,'4,000')],'Time [ns]','Accumulated cycles at 2 ns step boundaries')
  n=min(4,max(1,int((t-23)/1.7)));x0,y0,x1,y1=box
  for key,col in [('physical_phase_rad',TEAL),('midpoint_phase_rad',ORANGE)]:
   pts=[(x0+(x1-x0)*row['t_ns']/8,y1-(y1-y0)*(row[key]/(2*math.pi))/4000) for row in r['steps'][:n+1]]
   d.line(pts,fill=col,width=4)
   for x,y in pts:dot(d,x,y,col,6)
  panel(d,(855,220,1230,530));txt(d,(880,242),'After ONE 2 ns step',25,WHITE,True)
  txt(d,(880,302),'5,637.53 rad',36,TEAL,True);txt(d,(880,350),'physical phase',23,MUTED)
  txt(d,(880,410),'3.14088 rad',36,ORANGE,True);txt(d,(880,458),'midpoint phase',23,MUTED)
  txt(d,(60,586),'θphysical = ωh       θmidpoint = 2 arctan(ωh / 2)',31,WHITE)
  txt(d,(60,628),'Lines join step endpoints; they do not depict substep trajectories.',21,MUTED)
 elif t<43:
  im,d=base(t,'The constructed update reaches the phase state')
  cx,cy,rr=295,372,163;d.ellipse((cx-rr,cy-rr,cx+rr,cy+rr),outline=GRID,width=3)
  d.line((cx-rr-20,cy,cx+rr+20,cy),fill=GRID,width=2);d.line((cx,cy-rr-20,cx,cy+rr+20),fill=GRID,width=2)
  for name,col in [('exact',WHITE),('midpoint',ORANGE),('exponential',TEAL)]:
   a,b=r['endpoint_coordinates'][name];x,y=cx+rr*a,cy-rr*b
   d.line((cx,cy,x,y),fill=col,width=3)
   if name=='exact':d.ellipse((x-12,y-12,x+12,y+12),outline=col,width=3)
   else:dot(d,x,y,col,7)
  txt(d,(70,566),'2 ns endpoint • actual fast-mode plane',25,MUTED)
  panel(d,(570,166,1230,601));txt(d,(600,190),'Full-state error on the unit-norm mode',26,WHITE)
  txt(d,(600,246),'Implicit midpoint',26,ORANGE,True);txt(d,(600,282),'1.454',62,ORANGE,True)
  txt(d,(600,376),'Reciprocal exponential',26,TEAL,True);scientific(d,(600,414),'5.82',-12)
  txt(d,(600,493),'Archived receipt; fresh rerun: 6.00e-12',24,MUTED)
  txt(d,(600,548),'White ring: exact. Teal dot: exponential.',23,WHITE)
 elif t<49:
  im,d=base(t,'Why plasma–field calculations care')
  panel(d,(50,172,1230,570));txt(d,(90,208),'Work depends on the current–field phase.',39,WHITE,True)
  txt(d,(90,291),'W = ∫ j · E dt',57,TEAL,True)
  lines(d,(90,393),'Preserved phase makes the admitted\ncurrent–field progression calculable.',36)
  txt(d,(52,601),'Measured on the frozen carrier; nonlinear coupling has its own refinement tests.',26,MUTED)
 else:
  im,d=base(t,'A phase operation you can reproduce.')
  panel(d,(50,159,1230,555));log=(D/'execution.txt').read_text(encoding='utf-8').splitlines()
  txt(d,(80,181),'CAPTURED EXECUTION OUTPUT',19,MUTED,True)
  for j,line in enumerate(log[:8]):txt(d,(80,223+j*36),line,25,TEAL if j==0 or j==7 else WHITE,mono=True)
  txt(d,(52,581),'Download 12_Phase_Demo_Source.zip from the Zenodo release.',28,WHITE,True)
  txt(d,(52,625),'Source, matrix, receipt and exact command included. Link in the post.',25,MUTED)
 return im

out=V/'Phase_Preservation_56s.mp4';exe=imageio_ffmpeg.get_ffmpeg_exe()
cmd=[exe,'-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart','-metadata','title=Constructed phase-faithful electromagnetic progression',str(out)]
log=(Q/'encode.log').open('wb');p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=log)
for i in range(fps*duration):
 im=frame(i/fps);p.stdin.write(im.tobytes())
 if i%120==0:im.save(Q/f'frame_{i//fps:02}.png')
p.stdin.close();assert p.wait()==0;log.close()
frame(38).save(V/'Phase_Preservation_Poster.png')
for t in [2,8,18,28,38,46,52]:frame(t).save(Q/f'key_{t:02}.png')
check=subprocess.run([exe,'-v','error','-i',str(out),'-f','null','-'],capture_output=True);assert check.returncode==0 and not check.stderr,check.stderr
probe=subprocess.run([exe,'-hide_banner','-i',str(out)],capture_output=True,text=True,encoding='utf-8',errors='replace')
(Q/'video_streams.txt').write_text(probe.stderr,encoding='utf-8')
(Q/'video_validation.json').write_text(json.dumps({'duration_seconds':duration,'frames':fps*duration,'fps':fps,'width':W,'height':H,'codec':'H.264','pixel_format':'yuv420p','audio':'none; captioned silent-first design','decode_all_frames':'passed','bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'frozen_receipt':r['archived_values'],'fresh_rerun':{'midpoint_error':r['midpoint_state_error'],'exponential_error':r['exponential_state_error']}},indent=2),encoding='utf-8')
print('Video complete:',out,out.stat().st_size,flush=True)
