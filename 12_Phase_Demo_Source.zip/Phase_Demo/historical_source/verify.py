"""Independent phase, support and source acceptance tests."""
import bootstrap
from bootstrap import OUT,initial
import numpy as np,json
from scipy.linalg import eigh,solve
from exponential import Krylov

def run():
    d=np.load(OUT/'fast_structure.npz');J=d['J'];v=d['fast_real'];vi=d['fast_imag'];w=max(d['lambda_']);rows=[]
    for dt in (2e-9,1e-9,5e-10,2.5e-10,1e-6):
        exact=v*np.cos(w*dt)+vi*np.sin(w*dt)
        k=Krylov(lambda y:J@y,J@v,64);computed=v+dt*k.action(dt,1)
        mp=solve(np.eye(len(v))-dt*J/2,(np.eye(len(v))+dt*J/2)@v)
        row=dict(dt=dt,exponential_phase_state_error=float(np.linalg.norm(computed-exact)),midpoint_phase_state_error=float(np.linalg.norm(mp-exact)),exponential_norm_error=float(abs(np.linalg.norm(computed)-np.linalg.norm(v))),phase_radians=float(w*dt));rows.append(row)
        assert row['exponential_phase_state_error']<3e-8,row
    source=json.loads((OUT/'source_operation.json').read_text());collision=json.loads((OUT/'local_collision.json').read_text());overlap=json.loads((OUT/'overlap_source.json').read_text())
    assert abs(source['energy_residual_J'])<1e-6
    assert abs(source['canonical_angular_residual_Js'])<1e-10
    assert abs(collision['collision_energy_residual_J'])<1e-6
    assert overlap['overlap_translation'][-1]['fusion_W']==0.
    # Krylov dimension comparison on the SAME actual nonlinear step.
    f,*_=initial();a=np.load(OUT/'exp2ns.npz');b=np.load(OUT/'exp2ns_k480.npz');delta=a['fields'][-1]-b['fields'][-1];de=a['field_rates'][-1]-b['field_rates'][-1]
    kk=dict(field_difference_J=float(.5*delta@f.KB@delta+.5*de@f.ME@de),species_work_difference_J=float(np.linalg.norm(a['history'][-1,-8:]-b['history'][-1,-8:])))
    result=dict(phase_tests=rows,source_energy_residual_J=source['energy_residual_J'],source_canonical_residual_Js=source['canonical_angular_residual_Js'],collision_energy_residual_J=collision['collision_energy_residual_J'],disjoint_overlap_W=0.,krylov_320_to_480=kk,scope='Frozen actual-generator phase test and finite nonlinear/source tests. No inference of uniform nonlinear accuracy or rotating fusion return.')
    (OUT/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':run()
