"""Physical fast-generator and rotating support compatibility construction."""
import bootstrap
from bootstrap import initial,OUT
import numpy as np,json,time
from scipy.linalg import eigh,null_space
from exponential import Metrics,geometry,Frozen
from advance import rotation

def run():
    start=time.time();f,c,fluid,alpha,a,ed,rho,meta=initial();met=Metrics(f,fluid)
    fd,ad=geometry(f,c,met,fluid,alpha,a,([s['U'] for s in fluid],np.zeros_like(alpha['x']),a),1e-20)
    gen=Frozen(f,met,fluid,alpha,fd,ad)
    J=np.column_stack([gen.op(col) for col in np.eye(gen.size)]);lam,V=eigh(1j*J)
    idx=np.argmax(lam);v=V[:,idx];freq=lam[idx]
    groups={'electron':slice(0,12),'deuterium':slice(12,24),'tritium':slice(24,36),'alpha':slice(36,gen.nv),'magnetic':gen.ix,'inductive':gen.iy,'electrostatic':gen.iz}
    fractions={key:float(np.vdot(v[sl],v[sl]).real) for key,sl in groups.items()}
    nocharge=J.copy();nocharge[gen.iz,:]=0;nocharge[:,gen.iz]=0
    nocurrent=J.copy();nocurrent[:gen.nv,gen.iy]=0;nocurrent[gen.iy,:gen.nv]=0;nocurrent[:gen.nv,gen.iz]=0;nocurrent[gen.iz,:gen.nv]=0
    rot=np.column_stack([rotation(f,x) for x in np.eye(f.nf)])
    rows=[]
    for m in (1,2,3,4):
        ids=np.where(np.array(f.labels)==m)[0];test=f.G.T@rot[:,ids];N=null_space(test)
        rows.append(dict(m=m,field_dimension=len(ids),flux_constraint_rank=int(np.linalg.matrix_rank(test)) if np.linalg.norm(test)>0 else 0,admitted_rotating_dimension=N.shape[1],null_residual=float(np.linalg.norm(test@N))))
    # Prepared, unit-energy fast phase witness, actual joint eigenvector.
    real=np.sqrt(2)*v.real;imag=np.sqrt(2)*v.imag
    phases=[]
    for dt in (2e-9,1e-9,5e-10,2.5e-10):
        exact=np.exp(-1j*freq*dt);mp=(1-1j*freq*dt/2)/(1+1j*freq*dt/2)
        phases.append(dict(dt=dt,exact_unwrapped=freq*dt,midpoint_unwrapped=2*np.arctan(freq*dt/2),physical_phase_error_abs=float(abs(exact-mp))))
    # Conservative geometry keeps the same skew-coupled charge/current law.
    result=dict(size=gen.size,fast_frequency_rad_s=float(freq),period_ps=float(2*np.pi/freq*1e12),energy_fractions=fractions,skew_defect=float(np.linalg.norm(J+J.T)/np.linalg.norm(J)),without_scalar_response_fast_rad_s=float(max(abs(eigh(1j*nocharge,eigvals_only=True)))),without_current_coupling_fast_rad_s=float(max(abs(eigh(1j*nocurrent,eigvals_only=True)))),support_rotating_subspaces=rows,phase_witness=phases,seconds=time.time()-start)
    np.savez_compressed(OUT/'fast_structure.npz',J=J,lambda_=lam,fast_real=real,fast_imag=imag,rotation=rot,KB=f.KB,ME=f.ME,KP=f.KP,G=f.G)
    (OUT/'fast_structure.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':run()
