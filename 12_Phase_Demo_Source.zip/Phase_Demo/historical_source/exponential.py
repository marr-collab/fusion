"""Reciprocal exponential discrete-gradient advance on the Atlas V carrier.

The frozen generator includes ALL live alpha velocities, all three material
velocities, Maxwell and scalar fields, and the ideal support constraint.
Geometry and pressure are iterated, not fixed to an inherited background.
The exponential is evaluated by Hermitian Krylov, with explicit refinement.
This is a locally exact nonlinear method, NOT a uniform-accuracy theorem.
"""
import bootstrap
import numpy as np
from scipy.linalg import eigh, null_space, solve, block_diag
from advance import cross_matrix,rotation
from ellipsoid import closure

def root(A,p):
    ev,V=eigh(A)
    if min(ev)<=0: raise ValueError('Nonpositive physical metric')
    return (V*ev**p)@V.T

def phi(z,k):
    z=np.asarray(z,dtype=complex); out=np.empty_like(z); small=abs(z)<.03
    from math import factorial
    out[small]=sum(z[small]**j/factorial(j+k) for j in range(12))
    out[~small]=np.expm1(z[~small])/z[~small]
    for j in range(1,k):out[~small]=(out[~small]-1/factorial(j))/z[~small]
    return out

class Metrics:
    def __init__(self,f,fluid):
        self.kr=root(f.KB,.5); self.ki=root(f.KB,-.5)
        self.ei=root(f.ME,-.5);self.er=root(f.ME,.5)
        self.pi=root(f.KP,-.5);self.pr=root(f.KP,.5)
        H=self.ei@f.G;self.Q=null_space(H.T);self.E=self.ei@self.Q
        self.C=self.kr@self.E
        self.ms=[];self.mi=[];self.mr=[]
        for s in fluid:
            mm=np.kron(np.eye(3),(s['X'].T*(s['w']*s['m']))@s['X'])
            self.ms.append(mm);self.mi.append(root(mm,-.5));self.mr.append(root(mm,.5))
        self.Mi=block_diag(*self.mi);self.Mr=block_diag(*self.mr)
        self.react=solve(H.T@H,H.T@self.ei,assume_a='pos')
        self.lift=self.ei@H@solve(H.T@H,np.eye(H.shape[1]),assume_a='pos')
        self.wall_mass=solve(H.T@H,np.eye(H.shape[1]),assume_a='pos')

class Frozen:
    def __init__(self,f,metric,fluid,alpha,fd,ad):
        self.f=f; self.met=metric; self.fd=fd;self.ad=ad
        self.nv=36+3*len(alpha['w']);self.nx=f.nf;self.ny=metric.Q.shape[1];self.nz=f.np
        self.ix=slice(self.nv,self.nv+self.nx); self.iy=slice(self.ix.stop,self.ix.stop+self.ny);self.iz=slice(self.iy.stop,None)
        self.size=self.iy.stop+self.nz
        self.asqrt=np.sqrt(alpha['w']*alpha['mass'])
        HA=np.concatenate([d['HA']@mi for d,mi in zip(fd,metric.mi)],1)
        HD=np.concatenate([d['HD']@mi for d,mi in zip(fd,metric.mi)],1)
        A,D,bm=ad
        aa=(A*(alpha['w']*alpha['charge']/self.asqrt)[:,None,None]).transpose(1,0,2).reshape(f.nf,-1)
        dd=(D*(alpha['w']*alpha['charge']/self.asqrt)[:,None,None]).transpose(1,0,2).reshape(f.np,-1)
        self.HA=np.c_[HA,aa];self.HD=np.c_[HD,dd]
        self.ha=metric.E.T@self.HA;self.hd=metric.pi@self.HD
        self.gf=block_diag(*[mi@d['gyro']@mi for mi,d in zip(metric.mi,fd)])
        self.ga=alpha['charge'][:,None,None]/alpha['mass'][:,None,None]*cross_matrix(bm)
        self.force=np.zeros(self.size)
        self.force[:36]=np.concatenate([mi@d['pressure'] for mi,d in zip(metric.mi,fd)])

    def op(self,z):
        v=z[:self.nv];x=z[self.ix];y=z[self.iy];p=z[self.iz];out=np.zeros_like(z)
        out[:36]=self.gf@v[:36]
        out[36:self.nv]=np.einsum('nij,nj->ni',self.ga,v[36:].reshape(-1,3)).ravel()
        out[:self.nv]-=self.ha.T@y+self.hd.T@p
        out[self.ix]=self.met.C@y
        out[self.iy]=self.ha@v-self.met.C.T@x
        out[self.iz]=self.hd@v
        return out

    def pack(self,fluid,alpha,a,ed,rho):
        return np.r_[*(mr@s['U'].ravel() for mr,s in zip(self.met.mr,fluid)),(self.asqrt[:,None]*alpha['v']).ravel(),self.met.kr@a,self.met.Q.T@self.met.er@ed,self.met.pi@rho]

    def unpack(self,z):
        u=[(mi@z[12*k:12*k+12]).reshape(3,4) for k,mi in enumerate(self.met.mi)]
        v=z[36:self.nv].reshape(-1,3)/self.asqrt[:,None]
        return u,v,self.met.ki@z[self.ix],self.met.E@z[self.iy],self.met.pi@z[self.iz]

class Krylov:
    def __init__(self,op,v,n=160):
        self.norm=np.linalg.norm(v);N=len(v);n=min(n,N)
        V=np.zeros((N,n),complex);T=np.zeros((n,n),complex)
        V[:,0]=v/max(self.norm,1e-300)
        for k in range(n):
            w=1j*op(V[:,k]);z=V[:,:k+1].conj().T@w;w-=V[:,:k+1]@z
            zz=V[:,:k+1].conj().T@w;w-=V[:,:k+1]@zz;z+=zz
            T[:k+1,k]=z;T[k,:k+1]=z.conj();beta=np.linalg.norm(w)
            if beta<1e-12 or k==n-1: break
            V[:,k+1]=w/beta
        self.V=V[:,:k+1];self.T=(T[:k+1,:k+1]+T[:k+1,:k+1].conj().T)/2
        self.lam,self.Z=eigh(self.T);self.c=self.norm*self.Z[0].conj()
        self.U=self.V@self.Z;self.remainder=beta

    def action(self,t,k=1):
        return (self.U@(self.c*phi(-1j*self.lam*t,k))).real

def geometry(f,cache,met,fluid,alpha,a,guess,dt):
    us,dx,abar=guess;fd=[]
    for s,u in zip(fluid,us):
        X=s['X'];Fmid=s['F']+dt*u/2;delta=dt*X@u.T
        A,B,S,D=cache.sample(X@Fmid.T)
        S0=cache.sample(X@s['F'].T)[2];S1=cache.sample(X@(s['F']+dt*u).T)[2]
        defect=S1-S0-np.einsum('nij,nj->ni',D,delta)
        D+=defect[:,:,None]*delta[:,None,:]/np.maximum(np.sum(delta**2,1)[:,None,None],1e-40)
        bm=np.einsum('nik,i->nk',B,abar);L=u[:,:3]@np.linalg.inv(Fmid[:,:3])
        Cend,Cavg=closure(s['C'],-L[None]+s['q']/s['m']*cross_matrix(bm),dt)
        stress=np.einsum('n,nij->ij',s['w']*s['m'],Cavg)
        pressure=np.c_[stress@np.linalg.inv(Fmid[:,:3]).T,np.zeros(3)].ravel()
        HA=np.einsum('n,nic,nj->icj',s['w']*s['q'],A,X).reshape(f.nf,12)
        HD=np.einsum('n,nic,nj->icj',s['w']*s['q'],D,X).reshape(f.np,12)
        gyro=np.einsum('n,nab,ni,nj->aibj',s['w']*s['q'],cross_matrix(bm),X,X).reshape(12,12)
        fd.append(dict(HA=HA,HD=HD,gyro=gyro,pressure=pressure,Cend=Cend,Cavg=Cavg))
    A,B,S,D=cache.sample(alpha['x']+dx/2)
    S0=cache.sample(alpha['x'])[2];S1=cache.sample(alpha['x']+dx)[2]
    defect=S1-S0-np.einsum('nij,nj->ni',D,dx)
    D+=defect[:,:,None]*dx[:,None,:]/np.maximum(np.sum(dx**2,1)[:,None,None],1e-40)
    bm=np.einsum('nik,i->nk',B,abar)
    return fd,(A,D,bm)

def step(f,cache,fluid,alpha,a,ed,rho,dt,tol=1e-8,nk=160,maxiter=30,accounts=False,drive=None):
    met=Metrics(f,fluid);guess=([s['U'].copy() for s in fluid],dt*alpha['v'],a.copy())
    d0,d1=(np.zeros(f.nw),np.zeros(f.nw)) if drive is None else drive
    ds=(d1-d0)/dt
    if np.linalg.norm(f.G.T@ed-d0)>1e-12*max(np.linalg.norm(f.G)*np.linalg.norm(ed),np.linalg.norm(d0),1.):raise ValueError('Initial support voltage incompatible with field rate')
    residuals=[];xs=[];rs=[]
    for it in range(maxiter):
        fd,ad=geometry(f,cache,met,fluid,alpha,a,guess,dt);gen=Frozen(f,met,fluid,alpha,fd,ad)
        z0=gen.pack(fluid,alpha,a,ed,rho)
        port=np.zeros((gen.size,f.nw));port[:gen.nv]=-gen.HA.T@met.lift;port[gen.ix]=met.kr@met.lift
        res=gen.op(z0)+gen.force+port@d0
        kry=Krylov(gen.op,res,nk);zend=z0+dt*kry.action(dt,1);zavg=z0+dt*kry.action(dt,2)
        slope=Krylov(gen.op,port@ds,nk) if np.linalg.norm(ds)>0 else None
        if slope is not None:zend+=dt*dt*slope.action(dt,2);zavg+=dt*dt*slope.action(dt,3)
        us,vm,ab,eb,pb=gen.unpack(zavg);new=(us,dt*vm,ab)
        oldflat=np.r_[*(u.ravel() for u in guess[0]),guess[1].ravel(),guess[2]]
        flat=np.r_[*(u.ravel() for u in us),new[1].ravel(),ab]
        if it==0:scale=np.r_[*(np.full(12,max(np.linalg.norm(u),1e4)) for u in us),np.full(new[1].size,max(np.max(abs(new[1])),1e-10)),np.full(len(ab),max(np.linalg.norm(ab),1.))]
        rr=(flat-oldflat)/scale;error=max(abs(rr));residuals.append(float(error))
        if error<tol:break
        xs.append(flat/scale);rs.append(rr);xs=xs[-5:];rs=rs[-5:]
        if len(rs)>1:
            R=np.array(rs);gram=R@R.T;reg=max(np.trace(gram)*1e-12,1e-32)
            coeff=solve(gram+reg*np.eye(len(gram)),np.ones(len(gram)));coeff/=sum(coeff)
            val=(.95*(coeff@xs)+.05*oldflat/scale)*scale
        else: val=.8*flat+.2*oldflat
        guess=([val[k*12:k*12+12].reshape(3,4) for k in range(3)],val[36:36+new[1].size].reshape(new[1].shape),val[-len(a):])
    else:raise RuntimeError(f'exponential geometry iteration failed {error:.3e}')
    u1,v1,a1,ed1,phi1=gen.unpack(zend);ed1+=met.lift@d1
    ed1-=met.lift@(f.G.T@ed1-d1)  # remove only null-space roundoff
    fluid1=[{**s,'F':s['F']+dt*u,'U':v,'C':d['Cend']} for s,u,v,d in zip(fluid,us,u1,fd)]
    alpha1={**alpha,'x':alpha['x']+dt*vm,'v':v1}
    rho1=f.KP@phi1
    pressure=np.array([dt*d['pressure']@u.ravel() for d,u in zip(fd,us)])
    report=dict(iterations=it+1,iteration_residual=error,krylov_dimension=len(kry.lam),fast_rad_s=float(max(abs(kry.lam))),quadratic_work_residual_J=float(.5*(zend-z0)@(zend+z0)-dt*gen.force@zavg) if drive is None else None,pressure_work_J=pressure.tolist(),flux_residual=float(np.linalg.norm(f.G.T@(a1-a)-dt*(d0+d1)/2)),nonlinear_history=residuals)
    # Independent weak Gauss check: the distribution endpoints generate rho.
    actual=sum(np.einsum('n,ni->i',s['w']*s['q'],cache.sample(s['X']@s['F'].T)[2]) for s in fluid1)
    actual+=np.einsum('n,ni->i',alpha1['w']*alpha1['charge'],cache.sample(alpha1['x'])[2])
    report['gauss_absolute_C']=float(np.linalg.norm(actual-rho1))
    report['gauss_energy_defect_J']=float(.5*actual@solve(f.KP,actual)-.5*rho1@phi1)
    if accounts:
        # Resolve the frozen exponential trajectory, including its fast phases,
        # solely for quadrature of reciprocal work and support reaction.
        # Products of two fast components have twice the state frequency.
        # At most four radians of product phase per 8-node Gauss subinterval.
        nq=max(24,int(np.ceil(4*max(abs(kry.lam))*dt))+16)
        from numpy.polynomial.legendre import leggauss
        if nq>100000:raise RuntimeError('Work quadrature requires subdivision')
        # Composite 8-point Gauss avoids high-order root construction cost.
        ng=max(1,int(np.ceil(nq/8)));g,w=leggauss(8)
        times=(np.arange(ng)[:,None]+(g+1)/2)*dt/ng;weights=np.tile(w*dt/(2*ng),ng)
        times=times.ravel();coeff=phi(-1j*kry.lam[:,None]*times[None],1)*kry.c[:,None]*times
        coeff_slope=None if slope is None else phi(-1j*slope.lam[:,None]*times[None],2)*slope.c[:,None]*times**2
        def readout(matrix,indices):
            value=(matrix@z0[indices])[:,None]+((matrix@kry.U[indices])@coeff).real
            if slope is not None:value+=((matrix@slope.U[indices])@coeff_slope).real
            return value
        voltage=d0[:,None]+ds[:,None]*times
        ey=readout(met.E,gen.iy)+met.lift@voltage;ps=readout(met.pi,gen.iz);aa=readout(met.ki,gen.ix)
        work=[];current=np.zeros_like(aa)
        for sl in [slice(0,12),slice(12,24),slice(24,36),slice(36,gen.nv)]:
            ja=readout(gen.HA[:,sl],sl);jd=readout(gen.HD[:,sl],sl);current+=ja
            work.append([-float(np.sum(weights*np.sum(ja*ey,axis=0))),-float(np.sum(weights*np.sum(jd*ps,axis=0)))])
        sheet=-met.react@(current-f.KB@aa)+(met.wall_mass@ds)[:,None]
        jaa=np.column_stack([rotation(f,col) for col in aa.T])
        report.update(work_J=work,source_work_J=float(np.sum(weights*np.sum(voltage*sheet,axis=0))),support_angular_impulse=float(-np.sum(weights*np.sum(jaa*(f.G@sheet),axis=0))),work_quadrature_points=len(times),sheet_rms=float(np.sqrt(np.sum(weights*np.sum(sheet**2,axis=0))/dt)))
        ka=f.KB@aa;net=current+f.G@sheet-ka
        formative=np.sum(ey*(f.KB@ey),axis=0)
        netpair=np.sum(ka*solve(f.ME,net,assume_a='pos'),axis=0)
        containing=np.sum(ka*solve(f.ME,ka,assume_a='pos'),axis=0)
        hc=float(a1@f.KB@ed1-a@f.KB@ed)
        report['persistence']=dict(cross_account_increment=hc,integrated_formative=float(weights@formative),integrated_containing=float(weights@containing),integrated_source_minus_containing=float(weights@netpair),increment_residual=float(hc-weights@(formative+netpair)),scope='actual sourced field cross-account; no numerical persistence ratio or completed return assigned')
    return fluid1,alpha1,a1,ed1,rho1,report
