"""Exact phi and Krylov definitions extracted from archived exponential.py. No algorithm changes."""
import numpy as np
from scipy.linalg import eigh

def phi(z,k):
    z=np.asarray(z,dtype=complex); out=np.empty_like(z); small=abs(z)<.03
    from math import factorial
    out[small]=sum(z[small]**j/factorial(j+k) for j in range(12))
    out[~small]=np.expm1(z[~small])/z[~small]
    for j in range(1,k):out[~small]=(out[~small]-1/factorial(j))/z[~small]
    return out

class Krylov:
    def __init__(self,op,v,n=160):
        self.norm=np.linalg.norm(v);N=len(v);n=min(n,N)
        V=np.zeros((N,n),complex);T=np.zeros((n,n),complex)
        V[:,0]=v/max(self.norm,1e-300)
        for k in range(n):
            w=1j*op(V[:,k]);z=V[:,:k+1].conj().T@w;w-=V[:,:k+1]@z
            zz=V[:,:k+1].conj().T@w;w-=V[:,:k+1]@zz;z+=zz
            T[:k+1,k]=z;T[k,:k+1]=z.conj();beta=np.linalg.norm(w)
            if beta<1e-12 or k==n-1: break
            V[:,k+1]=w/beta
        self.V=V[:,:k+1];self.T=(T[:k+1,:k+1]+T[:k+1,:k+1].conj().T)/2
        self.lam,self.Z=eigh(self.T);self.c=self.norm*self.Z[0].conj()
        self.U=self.V@self.Z;self.remainder=beta

    def action(self,t,k=1):
        return (self.U@(self.c*phi(-1j*self.lam*t,k))).real
