"""Reproduce the existing frozen-carrier phase comparison; no new plasma model."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['OMP_NUM_THREADS']='2'
from pathlib import Path
import json,hashlib,platform,sys
import numpy as np
import scipy
from scipy.linalg import solve,lu_factor,lu_solve
from krylov_original import Krylov
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in json.loads((R/'input_manifest.json').read_text(encoding='utf-8'))['files']:
 assert sha(R/row['path'])==row['sha256'],row['path']
d=np.load(R/'fast_structure.npz');J=d['J'];v=d['fast_real'];vi=d['fast_imag'];omega=float(max(d['lambda_']));h=2e-9
exact=v*np.cos(omega*h)+vi*np.sin(omega*h)
k=Krylov(lambda y:J@y,J@v,64);exp=v+h*k.action(h,1)
lhs=np.eye(len(v))-h*J/2;rhs=np.eye(len(v))+h*J/2
mp=solve(lhs,rhs@v)
err_exp=float(np.linalg.norm(exp-exact));err_mp=float(np.linalg.norm(mp-exact))
e0=.5*float(v@v)
hist=json.loads((R/'verification.json').read_text(encoding='utf-8'))['phase_tests'][0]
# Independent full-matrix exponential is unnecessary: the archived eigenpair gives
# the exact invariant-plane solution, checked against the actual full matrix.
pair_res=max(np.linalg.norm(J@v-omega*vi),np.linalg.norm(J@vi+omega*v))/omega
steps=[{'step':0,'t_ns':0.,'midpoint_energy_ratio':1.,'exponential_energy_ratio':1.,'physical_phase_rad':0.,'midpoint_phase_rad':0.}]
ym=v.copy();ye=v.copy();fac=lu_factor(lhs)
for n in range(1,5):
 ym=lu_solve(fac,rhs@ym);q=Krylov(lambda y:J@y,J@ye,64);ye=ye+h*q.action(h,1)
 steps.append({'step':n,'t_ns':n*h*1e9,'midpoint_energy_ratio':float(ym@ym/(2*e0)),'exponential_energy_ratio':float(ye@ye/(2*e0)),'physical_phase_rad':n*omega*h,'midpoint_phase_rad':n*2*np.arctan(omega*h/2)})
coords=lambda y:[float(v@y),float(vi@y)]
result={'carrier_dimension':len(v),'omega_rad_s':omega,'period_ps':2*np.pi/omega*1e12,'step_ns':h*1e9,'initial_energy':e0,'energy_metric':'E(y)=0.5*y.T@y in the archived physical energy coordinates; plot shows E/E(0).','skew_relative':float(np.linalg.norm(J+J.T)/np.linalg.norm(J)),'eigenpair_relative_residual':float(pair_res),'midpoint_state_error':err_mp,'exponential_state_error':err_exp,'midpoint_energy_relative_error':float(abs(mp@mp/(2*e0)-1)),'exponential_energy_relative_error':float(abs(exp@exp/(2*e0)-1)),'physical_phase_rad':omega*h,'midpoint_phase_rad':2*np.arctan(omega*h/2),'endpoint_coordinates':{'exact':coords(exact),'midpoint':coords(mp),'exponential':coords(exp)},'steps':steps,'archived_values':hist,'environment':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform()},'scope':'Actual archived 1243-coordinate frozen generator, selected unit-norm fast eigenmode. Phase result is not a nonlinear plasma accuracy theorem. Lines joining step-boundary values are visualization only.'}
assert pair_res<1e-12 and result['skew_relative']<1e-12
assert abs(err_mp-hist['midpoint_phase_state_error'])<1e-10
assert err_exp<3e-8
assert max(abs(x[key]-1) for x in steps for key in ['midpoint_energy_ratio','exponential_energy_ratio'])<1e-8
(R/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
log=['$ python reproduce.py',f'Carrier: {len(v):,} coordinates | step: 2 ns',f'Fast period: {result["period_ps"]:.6f} ps',f'Midpoint state error:    {err_mp:.12g}',f'Exponential state error: {err_exp:.12g}',f'Midpoint energy drift:  {result["midpoint_energy_relative_error"]:.3e}',f'Exponential energy drift: {result["exponential_energy_relative_error"]:.3e}','PASS: input hashes, eigenpair, phase and energy checks','Frozen-stage comparison; nonlinear coupling needs separate tests.']
(R/'execution.txt').write_text('\n'.join(log)+'\n',encoding='utf-8');print('\n'.join(log))
