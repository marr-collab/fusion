"""Safe reproduction: immutable archive, disposable work outputs. No physics models edited."""
from pathlib import Path
import json,hashlib,sys,subprocess,shutil,os,shlex,time
R=Path(__file__).resolve().parents[1]
LIB=R/'public_evidence' if (R/'public_evidence').exists() else R/'archive'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def verify():
 manifest=R/'registers/public_archive_manifest.json'
 entries=json.loads(manifest.read_text(encoding='utf-8'))['entries'];bad=[]
 for r in entries:
  p=LIB/r['path']
  if not p.exists() or sha(p)!=r['sha256']:bad.append(r['path'])
 checks=[]
 for c in json.loads((R/'registers/claims.json').read_text(encoding='utf-8')):
  p=R/c['receipt'];obj=json.loads(p.read_text(encoding='utf-8'))
  for k in c['json_pointer'].split('/')[1:]:obj=obj[int(k)] if isinstance(obj,list) else obj[k.replace('~1','/').replace('~0','~')]
  if c.get('transform'):obj+=1
  checks.append({'id':c['id'],'passed':obj==c['value'] and sha(p)==c['sha256']})
 result={'archive_files':len(entries),'mismatches':bad,'claim_checks':checks,'scope':'Byte identity and receipt pointer validation, not a rerun of historical physics.'}
 (R/'validation').mkdir(exist_ok=True);(R/'validation/integrity.json').write_text(json.dumps(result,indent=2))
 print('Archive files',len(entries),'mismatches',len(bad),'claims',len(checks));assert not bad and all(x['passed'] for x in checks)
def stage(all_science=False):
 dest=R/'work/Fusion_POG';dest.mkdir(parents=True,exist_ok=True)
 dirs=None if all_science else {'Generative','Burn_Renewal'}
 for p in (LIB/'Fusion_POG').rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(LIB/'Fusion_POG')
  if dirs and rel.parts[0] not in dirs:continue
  if 'tmp' in rel.parts or p.suffix.lower() not in ('.py','.npz','.json','.csv','.txt','.md','.npy'):continue
  dst=dest/rel;dst.parent.mkdir(parents=True,exist_ok=True)
  if not dst.exists():shutil.copy2(p,dst)
 return dest
def run(stage_name,cmd):
 env=os.environ.copy();env['OPENBLAS_NUM_THREADS']='2';env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONUTF8']='1'
 started=time.time();p=subprocess.run([sys.executable]+shlex.split(cmd),cwd=R/'work/Fusion_POG'/stage_name,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
 (R/'validation').mkdir(exist_ok=True);name=stage_name+'_'+cmd.split()[0].replace('.py','')
 (R/'validation'/f'{name}.log').write_text(p.stdout+'\n'+p.stderr,encoding='utf-8')
 print(name,'exit',p.returncode,'seconds',round(time.time()-started,2));p.check_returncode()
 return {'stage':stage_name,'command':cmd,'exit_code':p.returncode,'seconds':time.time()-started}
def main():
 op=sys.argv[1] if len(sys.argv)>1 else 'verify'
 if op=='verify':verify()
 elif op=='quick':
  stage();res=[run('Generative','constructors.py'),run('Burn_Renewal','waterbag_reactions.py')]
  (R/'validation/quick_reproduction.json').write_text(json.dumps(res,indent=2))
 elif op=='run':
  name=sys.argv[2];d=next(x for x in json.loads((R/'registers/demonstrations.json').read_text(encoding='utf-8')) if x['id']==name)
  if not d['commands']:print('Use preserved exact recipe:',d['recipe_source']);print('\n'.join(d['recipe_commands']));return
  stage(True)
  for cmd in d['commands']:run(d['stage'],cmd)
 else:raise SystemExit('Usage: python demos/run.py verify | quick | run DEMO_ID')
if __name__=='__main__':main()
