# Publication architecture: operations first

The flagship establishes the expanded design space through constructed results. Annex A derives geometry and current; B derives source and receiving; C derives reciprocal dynamics, phase and preparation; D derives physical succession and moving response. The Recognition and Construction Atlas maps these operations to formative recognition and upstream dependency. The passports turn each subject into a concrete research entry point.

## Sharing units

Share the flagship PDF as the entrance. Share each technical PDF with its literal-LaTeX MD/TXT master, bibliography and claim/demonstration registers. Share the presentation with its speaking outline. The Reading ZIP contains these current public files. The Full Research ZIP adds the historical scientific library needed to execute the shared constructors and inspect original derivations.

There is one current public edition. Historical research remains under `archive/`, with original authorship and byte identities. The public equations and numerical values retain their physical conditions; the explanatory order follows capability and dependency rather than the order of past troubleshooting.

## Publication test

Every principal result identifies what was constructed, which design relation is available, its mathematical realization, its numerical or analytical witness, and a usable next calculation. Supporting diagnostics explain admission and composition. The subject of the publications is the physical and computational capability itself.
