# Bibliography and derivational provenance

**E1.** Opal Issan, Jonathan Citrin, Matt Landreman and Brendan Tracey. *Analytic non-axisymmetric 3D MHD equilibria without stellarator symmetry*. arXiv:2610.07304v1, 5 October 2026. https://doi.org/10.48550/arXiv.2610.07304 . Full text inspected at https://arxiv.org/html/2610.07304v1 . External result, not an endorsement of this program.

**E2.** H.-S. Bosch and G. M. Hale. *Improved formulas for fusion cross-sections and thermal reactivities*. Nuclear Fusion 32 (1992). https://doi.org/10.1088/0029-5515/32/4/I07 . Supplied empirical cross-section input; coefficient provenance is retained in Burn_Renewal.

**U1.** R. Wade H. Marr and Joseph Adam Thiel. *From Availability to Projection*, version 3, 3 October 2026. Exact MD source in archive.

**U2.** R. Wade H. Marr. D-Series papers, including *Discrete Ordered Variation*, *Refinement Without Continuity*, *Succession Without Passage*, *Phase Through Projection*, and *Field-Relative Direction Without Metric*. Original versions and dates retained in archive/D Series. Catalog PDF and individual literal-math TXT companions remain distinct sources.

**U3.** *The Projected Electromagnetic Grammar*; *The Electromagnetic Articulation*; *Closure Through Participation*; *The Addressed Closure*; *From Participation to Quantitative Closure*; *From Closure to Composition*; *The Grammar as Instrument*. Original authorship/version metadata retained in exact archived sources and upstream_sources.json.

**R1.** Gemini Argon recapture supplied by the user, *New Astra Fusion Atlas Recapture*. Recognition/history source, copied unchanged in registers. Its interpretations are reconciled with originating equations and receipts.

**P1.** R. Wade H. Marr and Joseph Adam Thiel. Fusion POG, operational stack v0.2, generative constructions v0.3, pre-Atlas investigations, Fusion Grammar Recapture and Composition Atlases I-XI. October 2026. Individual master sources, figure data, code and receipts are indexed in source_navigation.json and archive_manifest.json.

The complete primary-link index records each external reference together with the local manuscript that invokes it. Follow that originating manuscript for the exact constitutive purpose; inclusion does not imply independent empirical validation of this program. All capstone numerical claims use preserved local receipts, not secondary web summaries.
