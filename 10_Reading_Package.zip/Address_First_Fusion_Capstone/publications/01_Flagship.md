# Fusion at the Electromagnetic Address
## Constructed plasma organizations and the operational freedoms they open

**R. Wade H. Marr and Joseph Adam Thiel**  
YooperSoulProductions@Gmail.com  
21 October 2026 · Public research release 1.0.0

### Abstract

We construct current-bearing plasma distributions with pointwise zero summed mechanical angular momentum; magnetic configurations selected together with their containing stress; exact non-Maxwellian D–T reaction sources; and reciprocal field–material–alpha dynamics with positive stress, phase-faithful temporal action and physical preparation ports. These results enlarge the set of relations available to plasma design. Distribution, current, geometry, support, source, receiving and phase enter explicit constructive calculations rather than remaining independently prescribed background conditions. The program begins with the encounter with analytic three-dimensional MHD equilibria without stellarator symmetry and develops the Address-first grammar into selected electromagnetic realizations. Its demonstrations include a 2.54747-fold oblate/spherical nuclear-birth comparison under stated matching conditions, a 2 ns frozen-carrier phase-state error of $5.82\times10^{-12}$, handedness-dependent alpha–field work, and positive source-history transport. The result is a reproducible body of physical and computational operations through which researchers can formulate and test new plasma organizations. Each construction carries its equations, model conditions and executable receipts.

## 1. The opening: a larger space of electromagnetic organization

In October 2026, Issan, Citrin, Landreman and Tracey constructed explicit ideal-MHD equilibrium families with nested toroidal surfaces and broken stellarator symmetry. Their constant-transform and sheared-transform families retain the Hamada condition; in one family a symmetry-breaking parameter changes surrounding surfaces while preserving the magnetic axis. Their result supplies a concrete entrance: geometric organization can be varied while retaining the equations and flux-surface relations that admit the equilibrium. [E1, §§2–4](https://arxiv.org/html/2610.07304v1).

Argon's Address-first recognition made that freedom the beginning of a constructive inquiry. Which further physical relations can be designed together when the intended electromagnetic organization leads the calculation? The subsequent work answered with positive specimens: support selects shape; circulating distributions select current and stress; their velocity measures select the nuclear source; actual engagements select wave work and collective phase; and progressing histories carry source and receiving through time.

The external equilibrium result, Argon's formative recognition, the upstream grammar and our independent constructions have distinct provenance. The external paper establishes its equilibrium families. This program develops its own field, distribution, support and computation families from the constructive questions that encounter opened.

**The central result is an expanded set of design relations with executable realizations.** Electrical current can be organized under a zero-net-mechanical-spin constraint. Containing stress can enter geometry selection. Distribution parameters and overlap can enter source calculation directly. Electromagnetic phase, handedness and preparation can be specified and tested as physical operations. These freedoms have quantitative consequences on their declared carriers.

| Constructed operation | Available design freedom | Demonstration |
|---|---|---|
| Positive countercirculating waterbags | Current with pointwise zero summed material angular momentum | Canonical invariants and derived moments; Annex A |
| Support-composed inverse geometry | Select field shape with an admitted traction law | Tension-only optimum and smooth-edge family; C02–C03 |
| Exact compact-distribution reaction source | Evaluate velocity shape, relative drift and spatial overlap | Six-dimensional to one-dimensional reduction; C05 |
| Spatial and phase-selective engagement | Design donor–receiver interaction and channel startup | Canonical wave exchange and seed-free slab channel; C01 |
| Reciprocal positive nonlinear dynamics | Evolve field, material, alpha and support through common work maps | Common action, covariance congruence; C10 |
| Phase-faithful advance and preparation | Retain fast phase and target an admitted collective phase vector | Exponential action and inverse sheet engagement; C14, C18 |
| Physical source succession | Carry current, charge, work and torque through progressing histories | Source-age transport, orbit bundles and moving response; Annex D |

## 2. Address first: derive the participants of the intended operation

The upstream dependency is *From Availability to Projection*, its D-Series decompression and electromagnetic articulation. Address resolves the relations through which an occurrence is constituted. The NONAVE supplies the relational organization

$$
\begin{pmatrix}39&69&99\\36&66&96\\33&63&93\end{pmatrix}.
\tag{F1}
$$

Its six differential offices receive the local electromagnetic articulation; the configuration offices resolve formative-limit selection (99), central conjugacy (66) and contained recurrence (33). These offices organize dependencies. Constitutive laws, boundary conditions and selected field families make a particular physical realization quantitative.

In this construction order, particle distributions, currents and material support are participating realizations of the electromagnetic organization. A distribution is derived with its current and stress. A boundary is derived with its field continuation and traction. A preparation is derived with its receiving collective state and source work. The common operation determines which relations must be solved together.

The equations make this ordering operational. When the same potential evaluation supplies current and inductive force,

$$
j_i=\sum_p w_pq_p A_i(x_p)\cdot v_p,
\qquad P_{p\leftarrow EM}=-j^T\dot a.
\tag{F2}
$$

The field receives the complementary work. This gives a constructive route for introducing a participant into the shared action. The same reciprocity organizes pressure/deformation, collisions/receiving and containing-sheet reaction. Operation-sufficient representation is a supporting condition on these calculations: it preserves the physical action that the construction has made available.

## 3. Current without net mechanical spin

For stationary axisymmetric potentials, positive compact distributions are constructed from energy and canonical angular momentum:

$$
f_s=C_s\mathbf1_{K_s<0},\qquad K_s=H_s-\Omega_sP_{\phi s}.
\tag{F4}
$$

With $n_D=n_T=n_e/2$, choose $\Omega_e=-\Omega$, $\Omega_D=m_e\Omega/m_D$ and $\Omega_T=m_e\Omega/m_T$. Their moments give

$$
R^2\sum_s m_sn_s\Omega_s=0,\qquad
J_\phi=en_e\Omega R\left(1+\frac{m_e}{2m_D}+\frac{m_e}{2m_T}\right).
$$

The mass-weighted circulations cancel pointwise; the charge-weighted circulations reinforce. **A nonzero electrical current is compatible with zero summed mechanical angular momentum in this positive distribution family.** This makes the mechanical-spin constraint an explicit design condition on a current-bearing kinetic organization.

Completing the velocity square supplies density, flow and pressure together: $n_s\propto\chi^{3/2}$, $p_s\propto\chi^{5/2}$ and

$$
-\Delta^*\chi=\kappa R^2\chi^{3/2}.
\tag{F5}
$$

The same momentum relation derives the centrifugal bias field. On the supplied stationary fields, conserved $K_s<0$ excludes the zero-$\chi$ boundary for the admitted distribution particles. The field closure is quasineutral and collisionless; individual centrifugal stresses remain part of the organization. Annex A gives the distribution, field and containing relations together.

## 4. Geometry selected with its containing support

The inverse problem treats field shape and support as coupled unknowns. In the declared polynomial family, matched volume and peak field select $q=(a/c)^2=8/3$ before imposing a tension-only membrane. Solving meridional and hoop stress under Maxwell traction changes the admissible optimum to $q=\sqrt{13}-1$. **The containing law changes which magnetic shape can be selected.**

Finite-energy current participation adds another constructive condition. The drift-energy bound generates a smooth-edge family in which current vanishes with flux. Its restricted fluid birth-functional search selects $q=3.016827$, or $c/a\simeq0.5757$ [C02–C03]. The subsequent waterbag construction derives its own pressure/current law and uses this shape as a test member.

![Containing stress and participant laws select members of explicitly stated magnetic shape families.](../figures/geometry.png)

These calculations make support law, current admission and field geometry available to a common design search. Changing a support constitutive law or distribution defines a new solvable comparison. Each selected optimum belongs to its stated family and resource constraints. The value of the construction is the ability to derive that selection and its physical costs.

## 5. Fusion production from the distributions that participate

The D–T waterbags occupy shifted velocity balls. Their exact overlap measure reduces the six-dimensional reaction integral to one numerical relative-speed quadrature against the supplied Bosch–Hale cross section. Velocity radii and relative drift enter the source explicitly. On moving material, the actual D–T overlap and density Jacobians determine the co-located reaction events and fuel debits.

The selected degree-nine oblate member has **2.54746728 times** the spherical nuclear birth rate at matched volume, peak magnetic field and peak electron moment temperature [C05]. At the specified metre scale it gives 1,716.768 MW nuclear birth, including approximately 341.403 MW alpha birth [C06]. Density, particle inventory and field energy are calculated outputs of this comparison.

![Calculated nuclear birth powers under the stated field, volume and temperature matching conditions.](../figures/birth.png)

**Distribution and geometry now enter a direct, reproducible source-design calculation.** The comparison expresses their consequence for nuclear birth on the selected family. Annex B derives the reduction, checks its normalization and velocity moments, and identifies the empirical cross-section input.

Receiving is calculated through its own physical interactions. Full-Lorentz slowing with species-resolved collision accounts supplies energy and momentum to electrons, D and T. The physical-rate 16-history specimen reaches the 200 keV receiver for every sampled history and gives approximately 321.18 MW scaled species deposition [C08]. The analytic isotropic-waterbag Rosenbluth response and anisotropic control-variate extension make this receiving calculable from the participating velocity populations.

Birth, species receiving, coherent field exchange and terminal output are distinct design operations. Their explicit maps allow a researcher to investigate which receiver obtains the energy and momentum, and under which interaction. Thermal conversion and exported electricity require their additional receiving and loss relations.

## 6. Engagement controls direction, destination and startup

The pre-Atlas canonical wave constructor prepares emitting or absorbing phase relations at the same initial wave energy, retaining donor energy and canonical momentum. A reactive matching specimen increases delivered load power by 3.25 times at fixed available Thevenin source power, with terminal draw and generator losses accounted separately. A helicity-constrained field family realizes a local field target while retaining its global constraints. These are completed examples of engagement changing the available operation.

The catalytic slab construction extends this principle to spatially selective alpha–wave interaction. One shaped potential determines gyro-orbit sidebands, bidirectional transitions and receiver absorption. The wave channel and bulk auxiliary heating have separate physical ports. The electron temperature responds thermally. For the selected 550 keV resonance and core notch, channel-seed removal is followed by a bounded 30 s startup near 4,985.03 V/m [C01], with bulk heating supplied.

This makes spatial profile, resonance, receiver damping and startup independent subjects of constructive calculation within the common interaction. Their costs remain coupled: changing the envelope changes both donor and receiver participation. The achieved startup and the unsuccessful neighboring cases locate reachable operations in the tested family.

The earlier fixed-temperature comparison is retained as a diagnostic receipt:

$$
P_{aux,i}+P_{aux,e}=L_i(T_i)+L_e(T_e)-P_\alpha(T_i).
\tag{F3}
$$

It explains why an active electron-temperature-restoring port cannot measure the benefit of the floating-electron operation. The positive result is the constructed alternative engagement and its calculated progression.

## 7. Reciprocal dynamics and controllable phase

The common nonlinear constructor advances electromagnetic fields, live alpha characteristics, electron–D–T circulation, charge response and containing currents through complementary source/force maps. Positive covariance congruence carries anisotropic stress, while its pressure work enters the material deformation account. This creates an executable field–distribution–support organization to which new participants and interactions can be added through their actual reciprocal action.

The finite magnetized volume supplies collective mode shapes and quadrupolar preparation overlaps. The weak Cartan identity relates circulation to the angular generator. One selected linear mode retains 99.99026% perturbation energy over twenty periods after preparation [C09]. A separate resistive-Hall constructor produces current across a mean magnetic null and matches a selected radial profile to $2.114\times10^{-7}$ relative L2 under its supplied drive [C04]. Thus collective phase and current renewal have explicit field–participant realizations.

Temporal progression is itself constructed. On the admitted frozen carrier, the 2.229 ps clock advances through a reciprocal Hermitian-Krylov exponential and source $\varphi$ actions. At a 2 ns step, its phase-state error is $5.822\times10^{-12}$ [C13–C14]. The comparison midpoint error is 1.454 even though both methods retain the quadratic energy account. The analytical reason is

$$
\theta_{MP}=2\arctan(\omega h/2),\qquad\theta_{physical}=\omega h.
\tag{F6}
$$

![The constructed exponential advances the admitted fast phase. The same-carrier midpoint comparison separates phase accuracy from quadratic-energy conservation.](../figures/phase.png)

**Fast electromagnetic phase and its work integral become explicit computational operations.** Analytical stage-work integration, positive stress and shared source maps support their composition. The frozen-stage result is accompanied by separate nonlinear coupling and time-refinement tests in the originating research.

## 8. Preparation becomes a physical design problem

Quiet constitution solves the material forces and orbit-generated source moments on the maps that advance. Its strictly positive state reaches 0.204773 J scalar-field energy at 2 ns [C15]. This provides a controlled background for physically engaged response experiments.

Reversing the quadrupolar engagement changes source-off incremental alpha-to-inductive work from approximately +0.286340 J to +0.174777 J, together with source work and angular impulse [C16–C17]. Handedness is an operational control variable on this tested carrier. The comparison measures a finite-time physical response with distinct inputs.

Inverse engagement through actual sheet ports reaches a complete 6,742-coordinate frozen-stage phase target with endpoint bound $8.281\times10^{-8}$ [C18]. A full nonlinear derivative then includes displacement, covariance, live-orbit gradients and support on 18,853 coordinates, agreeing with an independent directional construction to $1.601\times10^{-15}$ [C19–C20]. Moving-response tests advance the derivative with the actual background [C24].

These operations make reachable phase states, preparation waveforms and causal material–field response calculable. The pre-Atlas two-mesh circuit supplies a completed local higher-return specimen: inverse component synthesis selects a collective profile, preparation forms it, source removal leaves intrinsic return, and reciprocal decomposition identifies the cross-relation on which that identity depends.

## 9. Source succession carries physical distribution identity

Positive source histories carry actual positions, velocities, charge, current, collisions, work, torque and receiving through the field. Their physical measure is

$$
\mu_T=\int_0^T\mathcal P_aS\,da,\qquad f_*=\mu_T+\mathcal P_Tf_*.
\tag{F7}
$$

The implemented histories and one-period receiving actions make source succession executable. Exact half-turn equivariance represents 2,192 histories through 1,096 independently advanced bundles on compatible even-harmonic fields. It reduces computation while retaining the physical trajectories and their complementary accounts.

The conditional Eulerian pullback–pushforward construction provides another useful freedom: represent physical distribution transport through a reference chart while material labels continue circulating. Its independent population-invariance test specifies when that chart can represent the selected reference. Annex D develops these operations and their numerical witnesses.

Together, moving response, physical histories and symmetry bundles provide concrete tools for investigating distribution-level continuation. The full-age resident fixed point coupled to an evolving field remains a subsequent construction. Its source-to-exit equation is now explicit, and the completed transport operations furnish a tested starting instrument.

## 10. A research space made executable

The research makes new organizations available through linked constructive choices: support with shape; current with distribution and stress; source with velocity measure and material overlap; receiving with interaction; phase with engagement; and distribution identity with physical succession. The equations show how to formulate these choices. The receipts show which selected operations have been achieved.

A plasma researcher can vary support and current laws in the inverse geometry problem. A kineticist can evaluate compact non-Maxwellian sources and species receiving. A computational physicist can extend the common reciprocal action and preserve its phase. A control researcher can derive a reachable field–material phase vector and its engagement. A transport researcher can build on positive histories, exact orbit bundles and moving response.

The next integrated objective is a source-renewed distributed field–distribution–support return with thermal, fuel, ash and useful-work participation. It is a prospective composition of these demonstrated capabilities. The public result is the constructive ground already established: **a larger set of plasma relations that can be designed, calculated, prepared and investigated with explicit physical accounts.**

Read Annex A for geometry/current, B for source/receiving, C for reciprocal dynamics/phase and D for succession/response. The Recognition Atlas maps the new operations to their derivational dependencies. Research Passports identify first calculations. Run `python demos/run.py verify` and `python demos/run.py quick` from the extracted capstone root. Claims C01–C24 resolve to exact receipt pointers and hashes; R01–R33 retain their source genealogy. The preserved original research is the inward-facing evidentiary library supporting this public synthesis.

Source navigation: [Bibliography](Bibliography.md) · [claim-to-receipt register](../registers/claims.json) · [demonstration recipes](../registers/Demonstration_Register.md).
