# Geometry Through Containing Participation
## Field shape, supporting stress and current-bearing distributions as coupled design relations

**R. Wade H. Marr and Joseph Adam Thiel**  
YooperSoulProductions@Gmail.com  
21 October 2026 · Public research release 1.0.0

### Abstract

We construct magnetic geometry together with its containing stress and positive current-bearing participants. Tension-only membrane support selects an explicit oblate limit; finite-energy current participation generates a smooth-edge family; canonical electron–D–T waterbags produce density, pressure and electric current with pointwise zero summed mechanical angular momentum. These solved constructions make support law, field shape and distribution choice available to a common inverse-design calculation.

## 1. Recognition and inverse problem

**Operational freedom.** A researcher can specify a support law and a mechanical-spin condition, derive the field and distribution they admit, and calculate their source consequences. The following constructions provide explicit solutions and the equations for changing those choices.

Recognition R07 asks which support can carry the field selected by a birth-functional optimization. R08 asks which participants can carry its current with finite energy. R09 asks which pressure law follows from those participants. These questions determine the physical family available to design. The upstream dependencies are *From Participation to Quantitative Closure*, the containing relation in *The Addressed Closure*, and the sourced participant relations in *The Electromagnetic Articulation*.

The original non-stellarator-symmetric encounter remains the conceptual entrance, but the present axisymmetric search is independent. Axisymmetry and isotropic static force balance are supplied trial restrictions. They are not conclusions of the grammar or properties required of a future fusion device.

## 2. A polynomial field and its matched resources

In normalized units, use a poloidal field with

$$
\mathbf B=R^{-1}\nabla\psi\times\mathbf e_\phi,
\qquad\psi=AR^2(1-R^2/a^2-z^2/c^2).
\tag{A1}
$$

The Grad-Shafranov equation supplies $p=k\psi$ and $J_\phi=kR$, with $k=A(8/a^2+2/c^2)$. Let $q=(a/c)^2$. Fix volume-equivalent radius to one: $a=q^{1/6}$ and $c=q^{-1/3}$. Peak-field matching gives

$$
A=\frac1{2\sqrt{M(q)}},\qquad
M(q)=\begin{cases}1&q\le2,\\q^2/[4(q-1)]&q>2.\end{cases}
\tag{A2}
$$

Direct integration gives $\langle p^2\rangle=256A^4(4+q)^2/3465$. Under the supplied equal-temperature Maxwellian moment passport, this is the shape factor in the D-T birth functional. Its unconstrained maximum occurs at $q=8/3$. This calculation fixes peak field and volume, not every material or engineering resource.

## 3. Support enters the optimization

For the selected zero-exterior-field branch, a boundary current carries the jump in tangential magnetic field. The membrane receives $P_b=B_t^2/(2\mu_0)$. Parameterize its surface by $R=a\sin\theta$, $z=c\cos\theta$ and $\ell=(a^2\cos^2\theta+c^2\sin^2\theta)^{1/2}$. Its curvatures are $\kappa_s=ac/\ell^3$ and $\kappa_\phi=c/(a\ell)$. Mechanical equilibrium requires

$$
\kappa_sN_s+\kappa_\phi N_\phi=P_b,
\qquad \frac{d(RN_s)}{d\theta}=N_\phi\frac{dR}{d\theta}.
\tag{A3}
$$

With $y=\sin^2\theta$ and $P_0=2A^2$, the regular solution is

$$
N_s=\frac{aP_0\ell}{2c}\left[\frac{qy}{2}+\frac{(1-q)y^2}{3}\right],
\qquad N_\phi=(P_b-\kappa_sN_s)/\kappa_\phi.
\tag{A4}
$$

On the relevant oblate branch the minimum ratio is $(12-q^2-2q)/(q+2)$. Tension-only support therefore requires $q\le\sqrt{13}-1$. The earlier optimum requires compressive hoop stress and is outside this support class. This is a positive inverse result: a physical containing restriction selects a different shape. A shell that can carry compression would define a different optimization, not invalidate the derivation.

The full virial balance includes support traction. A field-only volume integral cannot certify an isolated plasma. The retained scripts independently check the surface/volume balance and the signs of the derived tensions.

![Shape selection with explicit comparison classes.](../figures/geometry.png)

## 4. The edge-current admission test

Minimizing drift kinetic energy at fixed current, or applying Cauchy-Schwarz, gives

$$
\frac12\sum_s m_sn_s|u_s|^2
\ge\frac{|J|^2}{2\sum_s n_sq_s^2/m_s}.
\tag{A5}
$$

If density vanishes linearly with distance $\delta$ from a smooth boundary and current approaches a nonzero limit, the lower bound has an integral proportional to $\int d\delta/\delta$. A regular MHD field can consequently fail to admit that selected finite-energy participant law.

The reconstructed fluid branch uses

$$
p(\psi)=\tfrac12\kappa\psi^2,\qquad
J_\phi=\kappa R\psi,\qquad
-\nabla\cdot(R^3\nabla u)=\kappa R^5u,\quad\psi=R^2u.
\tag{A6}
$$

The smooth-boundary Ritz search selects $q=3.0168271858$ [C02]. Its degree-nine birth ratio against the same-constitutive spherical member is **2.41198272** [C03]. The JSON field named `birth_gain_vs_same_constitutive_sphere` stores **1.41198272**, the fractional increase; adding one gives the ratio. This is not the later waterbag reaction ratio. The selected peak moment temperature is approximately 16.71 keV under the supplied profile, not a solved thermal transport temperature.

## 5. The positive kinetic construction

Use stationary axisymmetric particle invariants $H_s=m_s|v|^2/2+q_s\Phi$ and $P_{\phi s}=m_sRv_\phi+q_s\psi$. A compact nonincreasing distribution is

$$
f_s=C_s\mathbf1_{H_s-\Omega_sP_{\phi s}<0},\qquad
K_s=\frac{m_s}{2}|v-\Omega_sR\mathbf e_\phi|^2-W_s,
\tag{A7}
$$

where $W_s=q_s\Omega_s\psi-q_s\Phi+m_s\Omega_s^2R^2/2$. Velocity integration gives $n_s=C_s(4\pi/3)(2W_s/m_s)^{3/2}$ and $p_s=2n_sW_s/5$.

Choose $n_D=n_T=n_e/2$, $\Omega_e=-\Omega$, $\Omega_D=m_e\Omega/m_D$ and $\Omega_T=m_e\Omega/m_T$. Then

$$
R^2\sum_s m_sn_s\Omega_s=0,
\qquad J_\phi=en_e\Omega(1+\bar\mu)R,
\quad\bar\mu=\tfrac12(m_e/m_D+m_e/m_T).
\tag{A8}
$$

Define $\chi=\psi+m_e\Omega R^2/(2e)$ and $\Phi=-\Omega\chi/2$. Completing the momentum relation produces

$$
-\Delta^*\chi=\kappa R^2\chi^{3/2},\qquad
\mathbf B=\mathbf B_\chi-(m_e\Omega/e)\mathbf e_z.
\tag{A9}
$$

The resulting exterior must carry the uniform bias normal field. The earlier zero-exterior support cannot simply be inherited. This change illustrates the same inverse principle again: admitting a participant changes the field and its containing relation.

At $\chi=0$, $K_s$ is nonnegative. A particle with conserved $K_s<0$ cannot reach that boundary. The result is exact for these supplied stationary fields and distribution particles. Its field constitutive closure is quasineutral; the original source separately evaluates the Gauss defect. It is not a claim that all fusion-born alphas satisfy the same invariant admission condition.

## 6. Phase-correlated current renewal

The separate resistive-Hall constructor supplies a mean harmonic EMF $-\langle J_zB_r\rangle/(en)$ across a mean poloidal null. Its forward test generates current from zero under boundary drive. A radial handoff uses $n\propto\chi^{3/2}$ and $v_{max}\propto\chi^{1/2}$, so the leading weak-drift boundary scattering rate $\nu(v_{max})\propto n/v_{max}^3$ is constant for fixed Coulomb logarithm.

Inverse frequency selection reproduces $J_\phi=10\rho(r)r$ to $2.114\times10^{-7}$ relative L2 [C04]. Harmonic truncation and weak-drift validity set wider physical limits than that solve residual. Removing the drive causes resistive decay. The completed result is a calculated source-to-current renewal map, not endogenous fusion continuation.

## 7. Reproduction and transfer

**What this opens.** Support constitutive law, field shape and current-bearing distribution can be varied through one inverse problem. The zero-spin family adds a concrete mechanical constraint that still admits current. The null-ring constructor adds a calculated harmonic renewal engagement and source cost.

Use demonstration sets `geometry` and `current`; their full commands and input hashes are in the demonstration register. `Inverse_Synthesis/solve_regular_shape.py` produces the shape receipt. `Active_Renewal/kinetic_constructor.py` and `profile_handoff.py` supply the independent distribution and renewal constructors. Read the archived masters for normalized units and all rejected branches.

The immediate research transfer is to replace a trial field family, support law or distribution while retaining A3, A5 and the common source moments. Geometry can then be selected under the new admitted operation. The solved specimens establish inverse constitution as an executable design operation across declared field, support and participant families.


Source navigation: [Bibliography](Bibliography.md) · [claim-to-receipt register](../registers/claims.json) · [demonstration recipes](../registers/Demonstration_Register.md).
