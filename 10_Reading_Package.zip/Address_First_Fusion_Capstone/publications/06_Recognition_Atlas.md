# Recognition and Construction Atlas
## Operational freedoms, derivations and executable witnesses

**R. Wade H. Marr and Joseph Adam Thiel**  
YooperSoulProductions@Gmail.com  
21 October 2026 · Public research release 1.0.0

This atlas is a map of what researchers can now construct. Each entry begins with an available operation and its demonstrated realization, then traces the recognition and upstream dependency that opened it. Stable R01–R33 identifiers preserve the research genealogy. Dependencies determine the order; the historical Atlas number locates the originating work. Physical conditions remain attached to each demonstration.

## R01 · Vary asymmetric geometry while retaining admitted field-line return

**Newly available operation:** Use the exact nonsymmetric family to select a geometric port target and provide a field-line solver benchmark.

**Demonstrated construction:** G1 verifies spatial field-line return and a selected geometric port target on the supplied ideal-MHD family. It does not establish active temporal confinement.

**Mathematical realization:** Use the published asymmetric field-line family, preserve its admitted domain, and vary the signed geometry parameter.

**Formative recognition:** The external equilibrium families retain force balance and flux surfaces while changing reflection symmetry. Argon reads this as an entrance to configurational closure.

**Dependency:** Original physical encounter and upstream grammar. Upstream: FAP §§4,7-11; PEG §§5,9; GI §4.4.

**Recognition history:** A convenient geometric symmetry was being used as a proxy for admissible equilibrium organization.

**Originating constructor:** Generative

**Source:** [Fusion_Generative_Constructions_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R02 · Formulate field, participant and support as a common inverse problem

**Newly available operation:** Specify the intended electromagnetic operation and solve for its participating field, distributions and containing conditions.

**Demonstrated construction:** The inverse problem is explicitly formulated; supplied constitutive laws and search restrictions determine its selected solutions.

**Mathematical realization:** Specify unknown field, participant distributions, boundary and work identity before selecting a trial family.

**Formative recognition:** The six differential offices and configuration offices 99,66,33 distinguish local articulation, boundary admission, conjugacy and return.

**Dependency:** R01. Upstream: FAP §§7-11; PEG §§5,9.

**Recognition history:** Nine relational offices could be mistaken for nine physical components or additional equations.

**Originating constructor:** Inverse_Synthesis

**Source:** [Inverse_Electromagnetic_Synthesis_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R03 · Construct current and reciprocal force from one action

**Newly available operation:** Introduce a new participant through a shared potential evaluation and its work-conjugate source/force maps.

**Demonstrated construction:** Implicit kinetic-field matrix and complementary work close on the retained finite carrier; Atlas II tight energy residual 0.01388 J.

**Mathematical realization:** Compose field, moving particles, fluid and support through common canonical maps.

$$
j_i=\sum_p w_pq_p A_i(x_p)\cdot v_p,\quad P_{p\leftarrow EM}=-j^T\dot a
$$

**Formative recognition:** Shared evaluation gives an actual reciprocal action: j_i=sum wq A_i(x)·v and particle inductive power=-j^T adot.

**Dependency:** R02. Upstream: D1-D5 via FR §2; CC §3.1; QC.

**Recognition history:** Independent current deposition and force evaluation can appear mutually coupled without complementary work.

**Originating constructor:** Reciprocal_Atlas

**Source:** [Reciprocal_Kinetic_Composition_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R30 · Synthesize local field shape under helicity constraints

**Newly available operation:** Select a local field target within an admitted curl eigenspace while retaining the global constraints and removed-energy account.

**Demonstrated construction:** G2 reaches its constrained energy bound and local field target; a force-free field does not support an arbitrary nonconstant scalar-pressure gradient.

**Mathematical realization:** Construct curl eigenfields and constrained spectral descent with an explicit removed-energy receiver.

**Formative recognition:** The admitted curl eigenspace permits a selected local field target while retaining the global constraints.

**Dependency:** R02. Upstream: EA Theorem 9; PEG conjugacy.

**Recognition history:** A field-energy/helicity account can conceal different local field profiles.

**Originating constructor:** Generative

**Source:** [Fusion_Generative_Constructions_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R33 · Carry inventory and delayed receiving through positive reduced dynamics

**Newly available operation:** Use positive finite-bin transport and explicit fuel, heat and support inventories as compositional tools.

**Demonstrated construction:** v0.2 technical receipts remain valid on their reduced carriers; they are not promoted to generative physical design gain.

**Mathematical realization:** Construct finite-bin positive transport, invariant-region and preparation witnesses, fuel/heat/support accounts and their separating cases.

**Formative recognition:** Positive reduced state, invariant admission and inventory delay have exact local continuation roles.

**Dependency:** R02. Upstream: CC §3.1; GI; CTP operative inheritance.

**Recognition history:** A present alpha-energy or inventory total can omit the next deposition or processing response.

**Originating constructor:** Program

**Source:** [Fusion_Operational_Stack_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [05_Source_Succession_and_Return](05_Source_Succession_and_Return.md).

## R04 · Calculate thermal response to alpha-energy redistribution

**Newly available operation:** Let electron temperature respond under fixed electron input and compare the resulting ion/electron energy allocation.

**Demonstrated construction:** The clamped-temperature identity and floating-electron carrier are explicit in the integrated construction ledger.

**Mathematical realization:** Set electron auxiliary input to zero or a fixed resource and solve its thermal response.

$$
P_{aux,i}+P_{aux,e}=L_i(T_i)+L_e(T_e)-P_\alpha(T_i)
$$

**Formative recognition:** Summed auxiliary power is fixed when summed losses and alpha birth are fixed. A null saving in that setup is an accounting identity.

**Dependency:** R03. Upstream: GI §4.4; CC §3.

**Recognition history:** Holding both thermal temperatures fixed with an active electron port masks internal energy redirection.

**Originating constructor:** Integrated

**Source:** [RADIAL_ENVELOPE_CONSTRUCTION.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [03_Nuclear_Source_and_Channel](03_Nuclear_Source_and_Channel.md).

## R07 · Select magnetic geometry together with support stress

**Newly available operation:** Change the containing law and calculate the magnetic shapes its Maxwell traction can support.

**Demonstrated construction:** Polynomial family optimum shifts from q=8/3 to sqrt(13)-1 under tension-only support.

**Mathematical realization:** Solve meridional/hoop membrane equations with Maxwell traction and virial balance.

$$
\kappa_sN_s+\kappa_\phi N_\phi=P_b,\quad d(RN_s)/d\theta=N_\phi dR/d\theta
$$

**Formative recognition:** Tension-only membrane equilibrium restricts the shape that can carry the selected magnetic boundary load.

**Dependency:** R02, R03. Upstream: QC support and virial; TAC §§1-5.

**Recognition history:** An optimized plasma shape had silently inherited an unconstrained containing material.

**Originating constructor:** Inverse_Synthesis

**Source:** [Inverse_Electromagnetic_Synthesis_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R29 · Inverse-design, prepare and test a coupling-essential return

**Newly available operation:** Choose circuit components for a collective profile, prepare it, release it and identify its constitutive cross-relation through reciprocal removal.

**Demonstrated construction:** Completed coupling-essential circuit return on its local carrier; distributed burning fusion return remains prospective.

**Mathematical realization:** Inverse-synthesize and prepare a positive two-mesh circuit mode, then remove its cross-relation with complementary accounts.

**Formative recognition:** J5 requires the specified higher identity to depend on a cross-relation under an admitted reciprocal removal.

**Dependency:** R03. Upstream: EA J4/J5; CTP §15; CC §§6,9.

**Recognition history:** Coupling or synchronization was being promoted directly into a higher returning identity.

**Originating constructor:** Generative

**Source:** [Fusion_Generative_Constructions_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R31 · Select emitting or absorbing wave participation through phase

**Newly available operation:** Prepare different donor phases at the same initial wave energy and calculate the complementary canonical exchange.

**Demonstrated construction:** G3 emits or absorbs under prepared phase; its separate conservative transport channel is not silently identified as a derived coarse-graining.

**Mathematical realization:** Advance canonical wave quadratures and particle phases with interaction energy and canonical momentum retained.

**Formative recognition:** A common wave-particle Hamiltonian gives emitting and absorbing engagements at the same initial wave energy.

**Dependency:** R03. Upstream: D26-D34; EA sourced participation.

**Recognition history:** A scalar wave amplitude does not identify the phase relation of its participating donor population.

**Originating constructor:** Generative

**Source:** [Fusion_Generative_Constructions_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [03_Nuclear_Source_and_Channel](03_Nuclear_Source_and_Channel.md).

## R32 · Increase delivered power through reactive matching

**Newly available operation:** Derive a matching component for a finite-impedance source and calculate receiver power with source dissipation.

**Demonstrated construction:** G4 gives 3.25 times load power at fixed available source; actual terminal draw differs.

**Mathematical realization:** Cancel the supplied reactance at the operating frequency and retain generator dissipation.

**Formative recognition:** A derived reactive component changes the physical load seen by a finite-impedance source.

**Dependency:** R03. Upstream: CC §§6-9; PEG persistence calibration.

**Recognition history:** Delivered receiver power and available generator power were treated as the same knob.

**Originating constructor:** Generative

**Source:** [Fusion_Generative_Constructions_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R05 · Construct a catalytic channel with its own receiver and startup

**Newly available operation:** Design receiver matching and test channel-seed removal while accounting separately for bulk heating.

**Demonstrated construction:** Separated-channel equilibria and grid-dependent startup tests close on the slab carrier; seed removal refers to the channel only.

**Mathematical realization:** Derive channel damping from the receiving resonance and evolve its energy with bidirectional alpha transport.

**Formative recognition:** A channel can amplify from the alpha gradient while a separate bulk heater remains supplied.

**Dependency:** R04. Upstream: EA §§14-19; CC §3.1.

**Recognition history:** A single wave bucket was charged with both a bulk heating load and the much smaller alpha donor.

**Originating constructor:** Integrated

**Source:** [RADIAL_ENVELOPE_CONSTRUCTION.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [03_Nuclear_Source_and_Channel](03_Nuclear_Source_and_Channel.md).

## R08 · Construct a smooth-edge finite-energy current family

**Newly available operation:** Use the drift-energy condition to derive a vanishing-edge current and solve its field/pressure eigenfamily.

**Demonstrated construction:** Selected fluid q=3.016827, with declared temperature-profile birth functional and separate convergence tests.

**Mathematical realization:** Replace the linear-pressure branch with p=κψ²/2 and Jφ=κRψ and solve the smooth-edge eigenproblem.

$$
u_{drift}\ge J^2/(2\sum_s n_sq_s^2/m_s)
$$

**Formative recognition:** The lower drift-energy bound diverges when current remains finite as density vanishes linearly.

**Dependency:** R07. Upstream: QC; EA §§14-19.

**Recognition history:** A smooth pressure-zero field was treated as enough to admit a vanishing-density current carrier.

**Originating constructor:** Inverse_Synthesis

**Source:** [Inverse_Electromagnetic_Synthesis_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R06 · Design spatial and resonant alpha engagement

**Newly available operation:** Vary the potential profile and resonance through the same orbit sidebands, reverse transitions and receiving map.

**Demonstrated construction:** 550 keV case reaches a bounded 30 s seed-free channel endpoint near 4985.03 V/m. The fast-helium inventory reversal is not demonstrated.

**Mathematical realization:** Construct a Gaussian core notch, Bessel sideband map and spatial fast/ash transport.

**Formative recognition:** One potential can determine gyro-orbit sidebands, conservative energy/radial transitions and receiver absorption.

**Dependency:** R05. Upstream: CC §3.1; GI §4.4.

**Recognition history:** A radial displacement or potential envelope could be erased by an inventory bucket or local coupling approximation.

**Originating constructor:** Integrated

**Source:** [RADIAL_ENVELOPE_CONSTRUCTION.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [03_Nuclear_Source_and_Channel](03_Nuclear_Source_and_Channel.md).

## R09 · Derive current, density and stress from positive invariant distributions

**Newly available operation:** Generate the moments and field equation from a common canonical waterbag family.

**Demonstrated construction:** Exact collisionless invariant construction on supplied stationary fields, with quasineutral field closure and a separately calculated Gauss defect.

**Mathematical realization:** Complete the square in H-Ω_s Pφs and solve -Δ*χ=κR²χ^(3/2).

$$
f_s=C_s\mathbf1_{H_s-\Omega_sP_{\phi s}<0},\quad-\Delta^*\chi=\kappa R^2\chi^{3/2}
$$

**Formative recognition:** Positive invariant waterbags generate n∝χ^(3/2), p∝χ^(5/2), centrifugal bias and actual current together.

**Dependency:** R08. Upstream: FAP §11; EA §§14-19; CTP §§3-5.

**Recognition history:** A fluid pressure law was being carried into a distribution without deriving its moments.

**Originating constructor:** Active_Renewal

**Source:** [Active_Electromagnetic_Renewal_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R10 · Carry current with pointwise zero summed mechanical spin

**Newly available operation:** Choose coordinated electron–D–T circulation so mass-weighted angular momentum cancels while charge-weighted current remains.

**Demonstrated construction:** Pointwise angular cancellation and invariant confinement for K_s<0; this is not a fusion-alpha confinement theorem.

**Mathematical realization:** Choose Ω_e=-Ω, Ω_D=m_eΩ/m_D, Ω_T=m_eΩ/m_T with n_D=n_T=n_e/2.

$$
R^2\sum_s m_sn_s\Omega_s=0,\quad J_\phi=R\sum_s q_sn_s\Omega_s\ne0
$$

**Formative recognition:** Mass-weighted countercirculation cancels material angular momentum pointwise while charge-weighted circulation remains.

**Dependency:** R09. Upstream: EA participating sources; FR §7.

**Recognition history:** Net mechanical angular momentum and electrical circulation were being identified.

**Originating constructor:** Active_Renewal

**Source:** [Active_Electromagnetic_Renewal_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R11 · Renew current across a mean magnetic null through harmonic participation

**Newly available operation:** Calculate the phase-correlated Hall EMF, target radial current and required drive from the participating harmonic response.

**Demonstrated construction:** Projected radial current matches target to 2.114e-7 relative L2; source removal produces resistive decay.

**Mathematical realization:** Solve distributed resistive-Hall harmonics, prepare from zero current, test driven continuation and removal.

**Formative recognition:** The mean Hall correlation can supply azimuthal EMF where the mean poloidal magnetic field vanishes.

**Dependency:** R09. Upstream: FAP §11; PEG §9; EA §§14-19.

**Recognition history:** Mean-field static Ohm balance omitted harmonic participating currents.

**Originating constructor:** Active_Renewal

**Source:** [Active_Electromagnetic_Renewal_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [02_Geometry_and_Current](02_Geometry_and_Current.md).

## R12 · Calculate non-Maxwellian fusion sources by exact velocity reduction

**Newly available operation:** Vary compact velocity radii and relative drift in a one-dimensional source quadrature derived from exact ball overlap.

**Demonstrated construction:** 2.54746728 oblate/spherical birth ratio at fixed volume, peak field and peak moment temperature; particle inventory is not matched.

**Mathematical realization:** Reduce the six-dimensional D-T integral to one speed quadrature against the supplied Bosch-Hale cross section.

$$
\mathcal R_{DT}=n_Dn_T\int P_d(g)\sigma(\mu g^2/2)g\,dg
$$

**Formative recognition:** Ball overlap gives the exact relative-speed measure, including its nonzero-drift support.

**Dependency:** R09, R10. Upstream: QC constitutive completion; GI §4.4.

**Recognition history:** Maxwellian reactivity and a non-Maxwellian velocity population are different constitutive inputs.

**Originating constructor:** Burn_Renewal

**Source:** [Waterbag_Fusion_and_Renewal_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [03_Nuclear_Source_and_Channel](03_Nuclear_Source_and_Channel.md).

## R14 · Derive preparation from a magnetized collective volume

**Newly available operation:** Let finite geometry and vector Lorentz coupling select collective field profiles and their port overlaps.

**Demonstrated construction:** A selected quadrupole-prepared mode retains 99.99026% perturbation energy over 20 periods on its linear carrier.

**Mathematical realization:** Retain U_s×B_0 and u_s0×B_1 in the finite oblate field-participant eigenproblem.

**Formative recognition:** Full vector Lorentz coupling and finite geometry admit different collective volume responses and port overlaps.

**Dependency:** R03, R09, R11. Upstream: PEG conjugacy; EA; FR §§1,6.

**Recognition history:** An unmagnetized axially uniform conductor had been used to decide propagation in a finite magnetized body.

**Originating constructor:** Internal_Renewal

**Source:** [Internal_Electromagnetic_Renewal_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R13 · Calculate species-resolved alpha receiving

**Newly available operation:** Assign energy and momentum along physical slowing histories to their actual receiving species.

**Demonstrated construction:** 16 sampled histories reach the 200 keV cutoff; deposition is about 321.18 MW on that prescribed carrier, not a population-wide retention guarantee.

**Mathematical realization:** Use waterbag Rosenbluth coefficients and full-rate characteristics with receiving ledgers.

**Formative recognition:** Actual Lorentz slowing assigns species energy and momentum along retained histories.

**Dependency:** R12, R03. Upstream: QC; CTP support accounts.

**Recognition history:** A nuclear birth margin can be mistaken for deposited heat, coherent field drive or net electrical output.

**Originating constructor:** Finite_Slip_Renewal

**Source:** [Metre_Scale_Renewal_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [03_Nuclear_Source_and_Channel](03_Nuclear_Source_and_Channel.md).

## R15 · Resolve collective phase through the circulation generator

**Newly available operation:** Calculate handedness and co-rotating frequency from the weak Cartan relation and participating mode structure.

**Demonstrated construction:** The phase relation is analytical; the 1.9 ppm numerical frequency coincidence is carrier-specific.

**Mathematical realization:** Derive R=-VJ, handedness and co-rotating frequencies and compare bases.

**Formative recognition:** The weak Cartan identity projects circulation onto the physical angular generator.

**Dependency:** R14. Upstream: D26-D34; FR §5.

**Recognition history:** A near equality of frequencies could be mistaken for an invariant spectral identity.

**Originating constructor:** Composition_Atlas

**Source:** [Active_Fusion_Composition_Atlas_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R16 · Constitute a four-species electromagnetic mean together

**Newly available operation:** Let resident alpha current and charge participate in selecting the common field, potential and material circulation.

**Demonstrated construction:** Source-current fixed point and weak continuity close on the selected mixed-invariant occupation; its full orbital stationarity is a separate test.

**Mathematical realization:** Solve the four-species magnetic/electrostatic/current equations together and derive moving-boundary waterbag response.

**Formative recognition:** Resident alpha current, charge and material stress change the field and circulation that constitute the mean.

**Dependency:** R03, R09, R13. Upstream: D1-D5; FR §§1,2.

**Recognition history:** An alpha-free mean and a resident current were initially inherited from different organizations.

**Originating constructor:** Joint_Organization

**Source:** [Joint_Electromagnetic_Constitution_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R17 · Resolve curved waterbag sources with compatible field spaces

**Newly available operation:** Co-refine magnetic, scalar and kinetic representations around the same physical source and boundary.

**Demonstrated construction:** Independent current L2 residual 0.73311%, FEM-quadrature residual 0.68770%; neither is a maximum pointwise bound.

**Mathematical realization:** Construct curved P3/P7 fields, common canonical streaming-force generator and conformal sheet response.

**Formative recognition:** Curved geometry and compatible magnetic/scalar spaces make the waterbag source representable.

**Dependency:** R16, R07. Upstream: PEG conjugacy; D6-D17; FR §§3,6.

**Recognition history:** Kinetic refinement alone left unmatched field response and a polynomial boundary error.

**Originating constructor:** CoRefined_Organization

**Source:** [CoRefined_Constitution_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R18 · Calculate continuous exterior field and containing reaction

**Newly available operation:** Construct field continuation, retarded response, induced sheet current and Maxwell traction as one containing relation.

**Demonstrated construction:** Derived field/support maps and retarded-impedance diagnostics close within their finite representations.

**Mathematical realization:** Construct Green/Poisson continuation, retarded impedance and conformal sheet energy and traction.

**Formative recognition:** Constitutive regions differ while Maxwell field continuation, energy and support remain common.

**Dependency:** R07, R14, R17. Upstream: TAC; QC; FR §6.

**Recognition history:** A vacuum approximation could be read as terminating electromagnetic progression at the plasma boundary.

**Originating constructor:** Joint_Organization

**Source:** [Joint_Electromagnetic_Constitution_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R19 · Advance positive anisotropic stress with reciprocal deformation work

**Newly available operation:** Use covariance congruence and the complementary pressure force to carry finite-amplitude material progression.

**Demonstrated construction:** Positivity and reciprocal pressure-work identities on the admitted moment closure; zero heat flux is a supplied restriction.

**Mathematical realization:** Advance C+=exp(hK) C exp(hK)^T and the same Π:∇u bulk/internal exchange.

$$
C_s^+=e^{hK_s}C_s^-e^{hK_s^T},\quad\dot U_{int,s}=-\int\Pi_s:\nabla u_s\,dV
$$

**Formative recognition:** A positive covariance congruence carries anisotropic stress with complementary deformation work.

**Dependency:** R03, R09, R17. Upstream: D1-D5; FR §8.

**Recognition history:** A signed tangent boundary perturbation cannot carry unrestricted finite-amplitude positive density.

**Originating constructor:** Nonlinear_Return

**Source:** [Nonlinear_Electromagnetic_Participation_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R20 · Advance fast electromagnetic phase through reciprocal exponential action

**Newly available operation:** Calculate the admitted phase, source actions and stage work with the actual frozen generator.

**Demonstrated construction:** 2.229 ps frozen clock; 2 ns exponential state error 5.822e-12, with nonlinear coupling accuracy tested separately.

**Mathematical realization:** Identify the fast eigenvector and implement reciprocal Hermitian-Krylov exponential and phi actions.

$$
\theta_{MP}=2\arctan(\omega h/2),\quad\theta_{exact}=\omega h
$$

**Formative recognition:** Its Cayley angle differs from the physical exponential angle even when the energy norm is exact.

**Dependency:** R15, R19. Upstream: D26-D34; FR §§5,7.

**Recognition history:** An energy-conserving midpoint map was treated as faithful to fast electromagnetic progression.

**Originating constructor:** Phase_Return

**Source:** [Phase_Faithful_Participation_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R21 · Generate fusion products from evolving material overlap

**Newly available operation:** Use density Jacobians and local velocity distributions to calculate co-located D–T reactions and their fuel/product accounts.

**Demonstrated construction:** Co-located source agrees with the shifted-ball reference on matched undeformed inputs; deformed source remains a declared quadrature.

**Mathematical realization:** Evaluate D-T overlap and create alpha/neutron products with fuel debit and receiving accounts.

**Formative recognition:** Density Jacobians and velocity distributions jointly determine the co-located reaction measure.

**Dependency:** R12, R19. Upstream: D1-D5; CC §3.1.

**Recognition history:** A width-dependent reaction localization substituted a kernel for the actual overlapping fuel charts.

**Originating constructor:** Phase_Return

**Source:** [Phase_Faithful_Participation_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [03_Nuclear_Source_and_Channel](03_Nuclear_Source_and_Channel.md).

## R22 · Prepare a quiet positive nonlinear starting organization

**Newly available operation:** Solve force compatibility and orbit-informed source quadrature on the maps used by the subsequent evolution.

**Demonstrated construction:** 2 ns scalar energy 0.204773 J; quietness over this interval is not indefinite stationarity.

**Mathematical realization:** Solve the nonlinear material force relation and positive alpha quadrature using propagated readouts.

**Formative recognition:** Force compatibility and orbit-informed positive quadrature are both needed for a quiet initial organization.

**Dependency:** R16, R19, R20, R21. Upstream: CC operation sufficiency; FR §§2,4.

**Recognition history:** Moment-matched initial sources did not retain their next orbital current progression.

**Originating constructor:** Quiet_Return

**Source:** [Quiet_Constitution_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R23 · Prepare a collective phase vector through physical sheet ports

**Newly available operation:** Derive a reachable phase target and its boundary waveform; calculate handed work and angular impulse on the nonlinear test carrier.

**Demonstrated construction:** Frozen-stage endpoint bound 8.281e-8; nonlinear handedness experiments have distinct input work and finite-time scope.

**Mathematical realization:** Use Duhamel/Gramian inverse engagement with real port work and endpoint metrics.

$$
\delta z(T)=\int_0^T e^{(T-t)L}Bv(t)\,dt
$$

**Formative recognition:** Actual sheet ports can select handed work and prepare a complete admitted linear-stage phase target.

**Dependency:** R15, R20, R22. Upstream: CC §9; D26-D34.

**Recognition history:** A target magnetic energy did not identify the field-material phase vector being prepared.

**Originating constructor:** Common_Phase

**Source:** [Common_Phase_Renewal_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R24 · Differentiate the complete nonlinear participating law

**Newly available operation:** Construct response directions including deformation, stress, live orbits, charge and support.

**Demonstrated construction:** Sparse-versus-JVP agreement 1.601e-15 is implementation consistency, supplemented by finite-perturbation tests.

**Mathematical realization:** Construct sparse and independent directional derivatives on 18,853 coordinates.

$$
L_{full}=D\mathcal F(z_0)
$$

**Formative recognition:** Differentiate the complete positive nonlinear force/source law.

**Dependency:** R19, R22, R23. Upstream: CC §3.1; D6-D17; FR §3.

**Recognition history:** A frozen current-stage matrix omitted displacement, covariance and field-gradient derivatives.

**Originating constructor:** Complete_Progression

**Source:** [Complete_Progression_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [04_Reciprocal_Dynamics_and_Phase](04_Reciprocal_Dynamics_and_Phase.md).

## R25 · Calculate response through a moving physical distribution

**Newly available operation:** Advance the nonlinear background and its variational action to obtain causal field and participant response.

**Demonstrated construction:** 32 ns moving response and chain-rule checks; a full-period nonlinear return is not inferred.

**Mathematical realization:** Advance the background, rebase DF, test variational composition and Eulerian source response.

$$
\dot V=D\mathcal F(z_0(t))V,\quad V(0)=I
$$

**Formative recognition:** The variational action must follow the actual nonlinear background and physical source projection.

**Dependency:** R24. Upstream: D18-D25; FR §§4,5.

**Recognition history:** An instantaneous particle-coordinate eigenvector was identified with an Eulerian returning mode.

**Originating constructor:** Physical_Return

**Source:** [Physical_Return_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [05_Source_Succession_and_Return](05_Source_Succession_and_Return.md).

## R26 · Halve independent orbit work through an exact physical symmetry

**Newly available operation:** Advance one representative per half-turn pair and reconstruct actual partner sources, work and torque on compatible even fields.

**Demonstrated construction:** Exact conditional quotient on even fields, compatible source/collision/support laws; release it when operative odd harmonics occur.

**Mathematical realization:** Advance 1,096 representatives and reconstruct 2,192 partners under Q=diag(-1,-1,1).

$$
\mathcal P_t(Qx,Qv)=Q\mathcal P_t(x,v)
$$

**Formative recognition:** Half-turn equivariance permits fewer independent histories without moving their physical endpoints.

**Dependency:** R03, R24. Upstream: CC §3.1; D6-D17.

**Recognition history:** Sparse endpoint snapping preserved selected moments while changing the next orbit and work.

**Originating constructor:** Complete_Progression

**Source:** [Complete_Progression_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [05_Source_Succession_and_Return](05_Source_Succession_and_Return.md).

## R27 · Construct positive source-to-receiver succession

**Newly available operation:** Accumulate physical source histories and one-period renewal actions with actual collision, field and terminal receiving accounts.

**Demonstrated construction:** Finite-age transport and one-period renewal action close their accounts; no full-lifetime stationary fixed point is certified.

**Mathematical realization:** Construct positive six-dimensional source histories and one-period nuclear/collision receiving actions; retain rejected clouds as separating witnesses.

$$
f_*=\mu_T+\mathcal P_Tf_*
$$

**Formative recognition:** f*=μ_T+P_T f* requires the actual continuing source, collision, characteristic and exit map.

**Dependency:** R13, R21, R25, R26. Upstream: D18-D25; CC §§3,8; FR §4.

**Recognition history:** A young prefix, invariant-leaf average or finite old-energy quadrature was treated as a full resident population.

**Originating constructor:** Physical_Return

**Source:** [Physical_Return_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [05_Source_Succession_and_Return](05_Source_Succession_and_Return.md).

## R28 · Express distribution transport through an Eulerian reference chart

**Newly available operation:** Use the derived pullback–pushforward identity under its reference-invariance condition and test the chosen reference independently.

**Demonstrated construction:** 3.563e-7 inverse-forward current consistency and 7.9735% independent atomic-current change measure different operations.

**Mathematical realization:** Compare inverse-reference consistency with independent forward reference current/charge progression.

$$
\Phi_{t\#}\mu_0=(\Phi_t\circ\Phi^0_{-t})_\#\mu_0\quad\text{if }\Phi^0_{t\#}\mu_0=\mu_0
$$

**Formative recognition:** The exact pullback-pushforward identity assumes a continuous invariant reference measure.

**Dependency:** R25, R26, R27. Upstream: D18-D25; D26-D34; CC §3.

**Recognition history:** An inverse-forward reference cancellation could be mistaken for proof that a supplied sourced population is stationary.

**Originating constructor:** Physical_Return

**Source:** [Physical_Return_Master.md — source locator](../registers/Original_Source_Locators.md). Hash and executable trails: [recognition register](../registers/recognitions.json). **Public treatment:** [05_Source_Succession_and_Return](05_Source_Succession_and_Return.md).

Source navigation: [Bibliography](Bibliography.md) · [claim-to-receipt register](../registers/claims.json) · [demonstration recipes](../registers/Demonstration_Register.md).
