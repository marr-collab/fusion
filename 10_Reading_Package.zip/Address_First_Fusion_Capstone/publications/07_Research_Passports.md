# Research Translation Passports
## Concrete entry points into the Address-first fusion corpus

**R. Wade H. Marr and Joseph Adam Thiel**  
YooperSoulProductions@Gmail.com  
21 October 2026 · Public research release 1.0.0

Each passport gives a completed operation, its admitted carrier and a concrete continuation. The proposed continuations are research invitations, not results claimed by this package. Start with the capstone README and the indicated annex. Every demonstration ID resolves to exact scripts, receipts and dependencies in `registers/demonstrations.json`.

## 1. For a three-dimensional MHD equilibrium researcher

**Available operation:** Select field geometry with containing stress and finite-energy current participation. The exact nonsymmetric equilibrium family supplies a separate geometry/solver benchmark (R01, R07–R08).

**Usable construction:** The generative G1 field-line implementation; the normalized polynomial family; the derived membrane stress; the finite-edge drift-energy bound; and the smooth-edge Ritz family. Read Annex A, equations A1-A6. Preserve the meaning $q=(a/c)^2$ and the matched volume/peak-field constraints.

**Open first:** `archive/Fusion_POG/Generative/constructors.py`, `archive/Fusion_POG/Inverse_Synthesis/support_and_preparation.py`, and `results/regular_shape_solution.json` in the latter directory. The `generative` quick reproduction already runs the analytic return witness. Use `geometry` for the larger original recipe.

**Next calculation:** Replace the zero-exterior polynomial boundary realization by a supplied continuous exterior field and solve its new traction problem. Compare admissible shape and birth functional at explicitly matched resources. Keep the external MHD paper's theorem separate from this selected support realization.

**Acceptance:** Force balance, divergence, admitted flux domain, field jump, tension or compression law, virial balance and independent current residual. Particle confinement and temporal return require subsequent maps.

## 2. For a computational Maxwell/Vlasov researcher

**Available operation:** Construct reciprocal field–participant dynamics, positive stress transport and phase-faithful frozen progression on a common numerical action (R03, R17, R19–R20).

**Usable construction:** The canonical implicit field relation; common particle interpolation/force; positive covariance congruence; exponential and phi-function action; analytical stage-work integration; and complete nonlinear Jacobian. Read Annex C, C1-C6, and Annex D, D2.

**Open first:** `archive/Fusion_POG/Phase_Return/exponential.py`, `archive/Fusion_POG/Physical_Return/analytic_work.py`, `archive/Fusion_POG/Complete_Progression/full_tangent.py`. Receipts are `Phase_Return/results/verification.json`, `Physical_Return/results/analytic_work_check.json` and `Complete_Progression/results/full_constructor.json`.

**Next calculation:** Add a new spatial basis or source participant using the same evaluation and transpose force map. Compare physical port responses on common field quadrature, then differentiate the actual advancing law. Test a resolved nonlinear reference separately from the frozen exponential identity.

**Acceptance:** Charge compatibility, source-force work cancellation, support constraint, covariance positivity, phase error, nonlinear step convergence and finite-perturbation derivative agreement. A small total-energy residual alone is insufficient for the selected phase operation.

## 3. For an alpha-transport kineticist

**Available operation:** Calculate non-Maxwellian sources, species receiving and physical source-history transport; reduce orbit work through exact symmetry and express distribution transport in an admitted Eulerian reference chart (R12–R13, R26–R28).

**Usable construction:** Exact shifted-ball speed PDF, analytic isotropic collision response, control-variate anisotropic receiving, actual source histories, conditional half-turn orbit bundles and the distinct Eulerian reference tests. Read Annex B, B1-B5, and Annex D, D4-D9.

**Open first:** `archive/Fusion_POG/Burn_Renewal/waterbag_reactions.py` (quick executable); `archive/Fusion_POG/Quiet_Return/quiet_collisions.py`; `archive/Fusion_POG/Physical_Return/eulerian_rechart.py`, `reference_admission.py` and `renewal_action.py`.

**Next calculation:** Construct an orbit-family/age reduction and test whether it preserves the next deposited current, charge, phase work and canonical torque against independent physical histories. Add a genuine terminal receiver and prove or measure finite occupation before solving the stationary renewal equation.

**Acceptance:** Positive source measure, actual characteristic accessibility, collision receiving, energy/canonical work, physical exits and next-period readout convergence. Do not turn unresolved transport into artificial exhaust or infer stationary residence from inverse-flow cancellation.

## 4. For a magnetic-support or field-control researcher

**Available operation:** Co-design containing geometry, field response and reachable preparation through support stress, induced currents and actual flux ports (R07, R18, R23, R29).

**Usable construction:** Inverse membrane stress, conformal sheet field and mutual flux, ideal support constraint, quadrupolar ports, Duhamel inverse preparation and the local two-mesh coupling-essential return.

**Open first:** `archive/Fusion_POG/Generative/constructors.py`, `archive/Fusion_POG/Joint_Organization/oblate_support.py`, `archive/Fusion_POG/Common_Phase/README.md`, and `Phase_Return/results/fast_structure.json`. Demonstrations `generative`, `volume` and `preparation` preserve their different target scopes.

**Next calculation:** Supply a realizable constitutive sheet/circuit law approximating the ideal flux constraint over a declared bandwidth and current range. Recompute exterior energy, Maxwell traction, real loss, reactive work and reachable preparation on the same volume response.

**Acceptance:** Physical current density, field continuation, work-conjugate ports, support stress, endpoint phase vector and source-off response. Ideal flux conservation is a target law; it does not certify an ordinary conducting foil or a superconducting vessel.

## 5. For a fusion-energy or useful-work researcher

**Available operation:** Calculate distribution-dependent nuclear birth, species receiving and coherent exchange as explicit physical channels, then formulate the thermal and conversion operations that receive their outputs (R04, R12–R13, R21, R27).

**Usable construction:** The non-Maxwellian reaction functional, actual source/fuel debit, deposited-energy and momentum ledger, separate channel/bulk-heating ports, and the earlier thermal/inventory/conversion account. Read Annex B and the preserved v0.2 plant ledger.

**Open first:** `archive/Fusion_POG/Burn_Renewal/results/dimensional_results.json`, `archive/Fusion_POG/Finite_Slip_Renewal/results/continuation_admission.json`, `archive/Fusion_POG/Program/Fusion_Operational_Stack_Master.md`, and `archive/Fusion_POG/Integrated/RADIAL_ENVELOPE_CONSTRUCTION.md`.

**Next calculation:** Specify common field, particle-inventory, source-power, material and conversion constraints before comparing two physical organizations. Feed actual deposited products into thermal exhaust, fuel replenishment, ash removal, neutron receiving and conversion. Retain imported energy and all support loads once.

**Acceptance:** An unambiguous Q-value convention; actual resource matching; complete material renewal; auxiliary demand; support/transport losses; and exported useful work. The 2.54747 birth ratio is a well-defined geometric source comparison, not a net-electric performance ratio.

## 6. What to share with each reader

The light reading bundle contains the flagship, four technical annexes, recognition atlas, these passports, presentation, bibliography and claim/demo registers. The full research bundle adds the immutable historical snapshot and reproduction tools. The former is sufficient for understanding and selecting an experiment; the latter is required for running the historical code and inspecting all original receipts. Release rights and third-party notices are specified in the publication package.


Source navigation: [Bibliography](Bibliography.md) · [claim-to-receipt register](../registers/claims.json) · [demonstration recipes](../registers/Demonstration_Register.md).
