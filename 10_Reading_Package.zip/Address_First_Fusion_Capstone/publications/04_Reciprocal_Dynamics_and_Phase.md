# Reciprocal Electromagnetic Dynamics and Preserved Phase
## Constructing positive participation, phase control and physical preparation

**R. Wade H. Marr and Joseph Adam Thiel**  
YooperSoulProductions@Gmail.com  
21 October 2026 · Public research release 1.0.0

### Abstract

We construct a shared electromagnetic–material–alpha–support dynamics whose sources and forces are work conjugates. Positive covariance transport advances anisotropic stress with deformation work. A reciprocal exponential advances fast electromagnetic phase and source actions. Physical sheet ports prepare collective phase states and expose handedness-dependent work. Full differentiation and moving response connect control calculations to the nonlinear participant law. These executable constructions make participation, phase, preparation and response available to quantitative design on their stated carriers.

## 1. Common action and canonical composition

**Operational freedom.** New participants can be introduced through their source and conjugate force, finite material response can remain positive, and a desired admitted phase state can determine its preparation engagement. The equations below construct these operations and provide independent work, phase and response checks.

Let $a$ be field coordinates and $u$ material velocities. A canonical finite representation has

$$
p_f=Mu+Ha,\qquad K_Ba=H^Tu+j_\alpha+Gs.
\tag{C1}
$$

The current interpolation used in $j_\alpha$ also enters the alpha force. Differentiating this common relation produces the implicit kinetic-field matrix, including the alpha response, rather than a prescribed gain. Positive definiteness on the admitted constrained subspace supplies a well-posed finite solve. Work and angular reaction follow from the same action and its rotational symmetry.

Atlas II's tight-run energy residual is 0.0138800 J on its represented state [C10]. This demonstrates complementary discrete accounts on that carrier and supplies a common action for the phase, preparation and material-response constructions that follow.

## 2. Circulation and magnetized volume response

Retaining $q_sn_s(E_1+U_s\times B_0+u_{s0}\times B_1)$ is consequential in a finite magnetized plasma. The earlier unmagnetized axial conductor's skin depth remains a property of that approximation. It is not a universal boundary-to-volume prohibition.

For rigid equilibrium circulation, the Cartan relation is

$$
u_{s0}\times(\nabla\times A)
=\nabla(u_{s0}\cdot A)-\Omega_sD_\phi A.
\tag{C2}
$$

Here $D_\phi$ is the physical vector rotation generator, including basis rotation. After the gradient contribution is treated in the compatible scalar space, the weak matrix relation is $R=-VJ$. Thus a harmonic's co-rotating phase is $\omega-m\Omega_s$. The numerical closeness of one mode to twice electron circulation follows a recognizable mechanism but is not itself a basis-independent theorem.

The selected finite-volume mode admits a quadrupolar preparation and retains 99.99026% perturbation energy over twenty periods [C09]. Later collective and kinetic refinements change the spectrum. The source/force/port map lets a new volume configuration select its own mode profile and compatible engagement.

## 3. Compatible fields, pressure and exterior

The waterbag tangent comes from moving its boundary: $\delta f_s=C_s\delta(K_s)\delta W_s$. Its canonical streaming and force must use one generator. Curved magnetic/scalar spaces represent the same source relation; the selected P3/P7 pairing gives independent strong-current L2 residual 0.73311%, while the FEM-quadrature result is about 0.68770% [C11]. The interface jump estimator is a separate error measure.

The exterior field is retained through Green/Poisson continuation and a retarded impedance diagnostic. The conformal sheet supplies current, energy and Maxwell traction. A magnetic-quasistatic reduction remains conditional on its phase and source scales; the word vacuum does not terminate the electromagnetic field at a boundary.

For ideal flux-conserving support, preparation acts through the actual flux port:

$$
G^T\dot a=v_{prep},\qquad
G^T\Omega\mathcal Ja_*=0\quad\text{after release for a rigid rotating field}.
\tag{C3}
$$

The second relation selects admissible rotating fields. It is not an arbitrary stiffness or damping term. The ideal material law is an inverse constitutive target. Its finite-current capability, cooling and mechanical implementation are not supplied by declaring it ideal. A rigid surface carries reaction without displacement work; a deformable structure would require its additional state and work.

## 4. Positive finite-amplitude material

A positive local velocity ellipsoid has covariance $C_s\succ0$, density transported by its material Jacobian, and pressure tensor $\Pi_s=m_sn_sC_s$. On the admitted zero-central-heat-flux moment projection,

$$
\dot C_s=K_sC_s+C_sK_s^T,
\qquad K_s=-\nabla u_s+\frac{q_s}{m_s}[\,\cdot\times B\,].
\tag{C4}
$$

For a frozen stage, $C_s^+=e^{hK_s}C_s^-e^{hK_s^T}$ remains positive. Taking the trace and retaining material transport gives

$$
\dot U_{int,s}=-\int\Pi_s:\nabla u_s\,dV.
\tag{C5}
$$

The opposite power enters the bulk deformation force. The pressure force follows from the same distribution-derived stress. Spatial affine and later non-affine projections have different resolving power. Positivity alone does not close the Vlasov moment hierarchy: the zero-heat-flux assumption and its counterexamples remain part of the implementation's physical scope.

## 5. A constructed fast-phase and work operation

The D-Series action relation $T_O(\theta)p_O=p_OU_Q(\theta)$ provides the operative distinction. For an oscillator eigenvalue $i\omega$, midpoint uses the Cayley multiplier $(1+i\omega h/2)/(1-i\omega h/2)$. Its modulus is one while its phase is $2\arctan(\omega h/2)$.

The Atlas VI frozen fast mode has frequency $2.818764858\times10^{12}$ rad/s and period 2.229056 ps [C13]. About 54.1% of its quadratic energy is electron kinetic, 37.2% inductive electric and 8.7% scalar electric on that representation. At 2 ns its physical unwrapped phase is 5637.53 radians, while midpoint advances approximately 3.14088 radians. The resulting phase-state error is 1.45434.

![Energy preservation and phase accuracy are separate tests on the fast frozen carrier.](../figures/phase.png)

The reciprocal exponential constructor uses a Hermitian-Krylov action. With a linear stage source $b(t)=b_0+t b_1$,

$$
y(h)=e^{hL}y_0+h\varphi_1(hL)b_0+h^2\varphi_2(hL)b_1,
\tag{C6}
$$

where $\varphi_1(z)=(e^z-1)/z$ and $\varphi_2(z)=(e^z-1-z)/z^2$, interpreted by their entire-function limits at zero. The recorded 2 ns fast-phase state error is $5.82249\times10^{-12}$ [C14]. The later real-basis implementation retains the admitted operation, while analytical pair-exponential work integration agrees with independent quadrature to $1.47704\times10^{-11}$ J [C23].

These tests establish the frozen temporal action and work quadrature. Moving geometry and nonlinear force composition still require resolved references and step comparisons. Fast sheet decay also requires its physical dissipative treatment; preserving an oscillatory block is not permission to omit a resistive participant.

## 6. Preparing phase-bearing field–participant states

The quiet construction solves material force and field/source compatibility on the maps that actually advance. Orbit-informed positive alpha quadrature retains subsequent source moments over its fitting interval. Its 2 ns final scalar energy is 0.204773 J [C15]. This provides a useful preparation background, not an indefinite stationary-population certificate.

On that carrier, reversed quadrupolar engagement changes post-release incremental alpha-to-inductive work from approximately +0.286340 J to +0.174777 J [C16-C17]. Source work and canonical impulse differ as well. This is a finite-time phase-control result; it is not an equal-input efficiency comparison or a persistent power source.

Inverse engagement targets a phase vector through real ports:

$$
\delta z(T_p)=\int_0^{T_p}e^{(T_p-t)L}B_vv(t)\,dt.
\tag{C7}
$$

The 1.024 microsecond frozen-stage construction reaches its admitted target with a full-stage error bound of $8.28058\times10^{-8}$ [C18]. Its carrier has 6,742 coordinates. The nonlinear material derivative is a different operator; the next construction differentiates the full law on 18,853 coordinates. Sparse-versus-directional agreement is $1.60104\times10^{-15}$ [C19-C20], supplemented by independent finite perturbation checks. This implementation agreement is not a continuum convergence certificate.

## 7. A completed local higher-return specimen

The pre-Atlas generative library contains a positive two-mesh circuit constructor. For inductance matrix $L$ and stiffness $K$, inverse synthesis chooses components so $Kw=\omega_*^2Lw$ for a target relative profile $w=(1,\rho)^T$. A controllability engagement prepares that state; source removal yields intrinsic conservative return. Reciprocal removal of the shared restoring relation destroys the selected profile under the declared participant-local decomposition class.

This is a completed coupling-essential electromagnetic identity on its circuit carrier. It supplies a concrete J5 witness and a method of inverse preparation. It does not by itself identify a distributed plasma-support circuit reduction. Likewise, the helicity-constrained curl-eigenfield and fixed-source reactive matching constructions are useful local operations: the latter changes delivered load power by 3.25 times in its stated Thevenin example, without claiming equal wall-plug draw.

## 8. Reusable implementation

**What this opens.** A researcher can construct new reciprocal participants, advance positive material stress, retain an admitted fast phase, integrate its work, select a reachable phase target and differentiate the common nonlinear law. The local circuit specimen also supplies an achieved coupling-essential return with preparation and reciprocal removal.

Demonstration sets `generative`, `reciprocity`, `phase`, `quiet`, `preparation` and `tangent` point to authoritative scripts, inputs and checks. The quick suite reruns selected analytical witnesses in a disposable workspace. The historical receipts remain immutable. The principal reusable result is a common reciprocal computation whose positivity, work, phase, preparation and derivative are separately testable on the same admitted law.


Source navigation: [Bibliography](Bibliography.md) · [claim-to-receipt register](../registers/claims.json) · [demonstration recipes](../registers/Demonstration_Register.md).
