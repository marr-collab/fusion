# Nuclear Source and Reciprocal Alpha Receiving
## Distribution-dependent fusion production and designed energy destinations

**R. Wade H. Marr and Joseph Adam Thiel**  
YooperSoulProductions@Gmail.com  
21 October 2026 · Public research release 1.0.0

### Abstract

We construct direct nuclear-source and receiving calculations from the participating distributions. Exact shifted-ball geometry reduces the D–T reaction integral to one speed quadrature. Co-located material overlap makes the source evolve with the fuel. Full-Lorentz slowing assigns alpha energy and momentum to receiving species. Spatially shaped catalytic engagement supplies a distinct, dynamically tested wave channel. Together these operations make velocity distribution, spatial overlap, resonance and receiving interaction explicit variables of fusion research.

## 1. Distribution, transport and receiver define calculable design choices

**Operational freedom.** Nuclear production and its destinations can be calculated through distinct physical interactions, then connected through their complementary accounts. Distribution shape and drift enter the source; characteristic transport enters delivery; phase and resonance enter coherent exchange. Each calculation below identifies the parameters a researcher can vary and the receiver that makes the operation quantitative.

Recognitions R04-R06, R12-R13 and R21 share a dependency: a physical handoff must retain the donor, the interaction and the receiver. *From Closure to Composition* §3.1 requires the retained signature to carry the next admitted operation, while *From Participation to Quantitative Closure* requires complementary accounts. Here the actual distribution determines the reaction measure, the orbit determines transport, and the receiving species or field determines the usable form of deposited energy.

## 2. Exact shifted-ball reduction

At a fixed spatial point, the D and T distributions are uniform balls with radii $a_v,b_v$, center separation $d=|u_D-u_T|$, and volumes $V_a,V_b$. Let $p=a_v+b_v$ and $c_v=|a_v-b_v|$. Their centered difference density is the intersection volume divided by $V_aV_b$:

$$
V_\cap(s)=\begin{cases}
4\pi\min(a_v,b_v)^3/3,&s\le c_v,\\
\pi(p-s)^2(s^2+2ps-3c_v^2)/(12s),&c_v<s<p,\\
0,&s\ge p.
\end{cases}
\tag{B1}
$$

Angular integration gives the relative-speed probability density

$$
P_d(g)=\frac{2\pi g}{dV_aV_b}\int_{|g-d|}^{g+d}sV_\cap(s)\,ds,
\quad d>0;
\qquad P_0(g)=\frac{4\pi g^2V_\cap(g)}{V_aV_b}.
\tag{B2}
$$

The inner integral is piecewise polynomial. Its exact evaluation leaves a single numerical cross-section quadrature:

$$
\mathcal R_{DT}(x)=n_Dn_T\int_0^{a_v+b_v+d}
P_d(g)\,\sigma_{DT}(\mu g^2/2)g\,dg,
\qquad\mu=\frac{m_Dm_T}{m_D+m_T}.
\tag{B3}
$$

The nonzero-drift support includes $d$. The zero-drift limit and equal-radius case are explicitly tested. Normalization and the second moment

$$
\int P_d(g)dg=1,\qquad
\int g^2P_d(g)dg=\tfrac35(a_v^2+b_v^2)+d^2
\tag{B4}
$$

provide independent geometric checks. The original implementation also compares against a 600,000-sample six-dimensional Monte Carlo calculation and a separate Maxwellian convolution. The latter does not make the waterbag Maxwellian.

The supplied Bosch-Hale cross-section fit is an empirical nuclear input. The implementation specifies center-of-mass keV, millibarn-to-square-metre conversion and its accepted energy domain. Exactness refers to B1-B2 and their reduction, not to an exact fundamental nuclear cross section. An arbitrary anisotropic ellipsoid pair does not generally retain this one-dimensional formula; the later overlap constructor performs its own positive velocity quadrature.

## 3. A matched geometric birth comparison

The degree-nine specimen fixes peak field to 5 T, volume-equivalent radius to 1 m, volume to $4\pi/3$ cubic metres and peak electron moment temperature to 16.71 keV. The retained oblate shape is $q=3.016827$, inherited as a test member from the earlier fluid search.

| Account | Sphere | Oblate |
|---|---:|---:|
| Nuclear Q-value birth, MW | 673.912 | 1716.768 |
| Alpha birth, MW | 134.017 | 341.403 |
| Resistive current moment, MW | 0.300910 | 0.487322 |
| Mean electron density, $10^{21}\,\mathrm{m}^{-3}$ | 0.710131 | 1.18002 |

The ratio is **2.54746728** [C05-C07]. The differing inventories and field energies are essential comparison conditions. This is a selected nuclear birth functional, not equal-total-resource plant performance. Degree and field reconstruction errors are separate from the very small final speed-quadrature error.

![Nuclear birth powers on the matched field-volume-temperature comparison.](../figures/birth.png)

## 4. Co-located source on moving material

For a positive material map $x_s(X,t)$ with deformation gradient $F_s$, conservation gives

$$
n_s(x,t)=\frac{n_{s0}(X_s)}{\det F_s(X_s,t)}.
\tag{B5}
$$

The actual spatial overlap of D and T charts and their local velocity measures determines reaction events. It replaces a width-dependent localization kernel. Each event removes one D and one T, creates an alpha and a neutron, and retains momentum and Q-value accounting. The source constructor compares its undeformed limit with B3; deformed anisotropic cases retain their own quadrature and convergence requirements.

This operation is especially important in a nonlinear return model. Resetting density to its old value would be an undeclared material source. Real fuel admission requires a specified incoming phase-space measure, charge, energy and momentum. The capstone retains the implemented reaction debits without claiming an unconstructed fuel-processing plant.

## 5. Physical slowing and its receivers

The isotropic-waterbag collision construction evaluates Rosenbluth potentials from the actual compact velocity population. Its drift and diffusion then enter full Lorentz characteristics. The anisotropic extension uses the analytic isotropic result as a control variate and retains explicit species receiving.

For each collision increment, the complementary receiving material takes the lost alpha momentum and energy. Electromagnetic work is recorded separately. In the full-rate 16-history specimen, all sampled 3.5 MeV histories reach the 200 keV cutoff after approximately 35.7 ms and yield about 321.18 MW scaled species deposition [C08]. The fraction near 94.08% is consistent with the large birth-to-cutoff energy interval, with the actual field and collision accounts retained. It is not an independent claim that an arbitrary alpha population has that confinement fraction. The 64-history result in the later carrier is a separate ensemble.

The distinction between birth and receiving matters quantitatively. A large alpha birth-to-resistive-moment ratio does not derive a coherent current-renewal channel. Nor does species heating establish net useful electrical work. Those operations require their actual conversion and support relations.

## 6. Catalytic engagement with a derived spatial map

The integrated slab construction uses a potential

$$
\Phi=\frac{E_0}{|k_y|}h(x)\cos(k_yy+k_\parallel z-\omega t),
\qquad h(x)=\sum_\ell b_\ell e^{iq_\ell x}.
\tag{B6}
$$

Its gyro-orbit harmonic is calculated along the entire orbit:

$$
C_n(X,\rho)=\frac1{2\pi}\int_0^{2\pi}
h(X+\rho\cos\varphi)e^{ik_y\rho\sin\varphi-in\varphi}\,d\varphi.
\tag{B7}
$$

A Gaussian potential notch suppresses core coupling but does not delete reverse transitions. The same sidebands determine resonant alpha diffusion and receiver absorption. For a canonical transition edge,

$$
J_{hl}=E_0^2G_{hl}\left(N_h/g_h-N_l/g_l\right),
\quad g(E)\propto\sqrt E,
\quad\Delta x=\frac{k_y}{q_\alpha B\omega}\Delta E.
\tag{B8}
$$

Opposite population updates conserve count internally; the energy and canonical transverse momentum have complementary field or boundary recipients. Thermalization retains spatial position. The selected equal-D/T fuel return is a supplied material closure; quasineutrality alone does not uniquely derive a fuel pinch.

The catalytic wave has its own energy account and receiver. Bulk ion auxiliary input is a separate port, and electrons float thermally without an active temperature-restoring heater. The 550 keV notched case gives a bounded 30 s seed-free channel endpoint [C01]. The 560 keV higher-gain equilibrium fails the tested startup admission. Neither demonstrates the hypothesized decrease in fast-alpha resident inventory. These retained counterexamples make the design operation usable: spatial shaping can remove desirable receiver damping as well as parasitic donor reheating.

## 7. Source and receiving as an executable design space

**What this opens.** Velocity-space shape and drift can enter reaction calculation directly. Material deformation can change the source through actual overlap. Species receiving can be traced along characteristic histories, and a separately constituted wave channel can be designed through spatial and resonant coupling. These are four concrete operations available for comparison and composition.

The exact reaction measure, co-located source and collision receiving are usable numerical constructors. The slab potential is a conditional interaction family with a supplied dielectric energy normalization; it is not a solved global launcher and mode. A source-to-orbit-to-wave composition must therefore supply that map, retain pitch and parallel momentum where relevant, and recompute receiving and loss under the same geometry.

For reproduction, use demonstration sets `reaction`, `deposition`, `channel` and `source`. The authoritative JSON pointers for the selected numbers are in the claim register; the full recipes remain in the archived READMEs. Each accounts for its own physical carrier. A researcher can now calculate how a changed distribution, spatial engagement or receiver alters production and energy delivery through an explicit interaction.


Source navigation: [Bibliography](Bibliography.md) · [claim-to-receipt register](../registers/claims.json) · [demonstration recipes](../registers/Demonstration_Register.md).
