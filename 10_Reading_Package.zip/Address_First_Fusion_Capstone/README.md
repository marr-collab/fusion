# Address-First Fusion POG: constructed plasma organizations

**R. Wade H. Marr and Joseph Adam Thiel**  
Public research release 1.0.0 · 21 October 2026  
https://doi.org/10.5281/zenodo.23523832

This research constructs current with pointwise zero summed mechanical spin, support-selected magnetic geometry, exact non-Maxwellian reaction sources, reciprocal positive dynamics, phase-faithful frozen progression and physical preparation. It supplies positive source-history transport and exact conditional orbit reduction. The publications explain the operational freedom each construction creates and the equations through which another researcher can use it.

## Begin with a capability

| What you want to construct | Read | Execute |
|---|---|---|
| Current with zero net mechanical spin; geometry with support | [Geometry/current](publications/02_Geometry_and_Current.md) | `current`, `geometry` |
| Non-Maxwellian fusion sources and species receiving | [Source/receiving](publications/03_Nuclear_Source_and_Channel.md) | `reaction`, `source`, `deposition` |
| Spatial or phase-selective energy exchange | [Source/receiving](publications/03_Nuclear_Source_and_Channel.md) | `generative`, `channel` |
| Reciprocal dynamics, positive stress and fast phase | [Dynamics/phase](publications/04_Reciprocal_Dynamics_and_Phase.md) | `reciprocity`, `phase`, `work` |
| Physical-port phase preparation and nonlinear response | [Dynamics/phase](publications/04_Reciprocal_Dynamics_and_Phase.md) | `quiet`, `handedness`, `preparation`, `tangent` |
| Source succession and distribution-level response | [Physical succession](publications/05_Source_Succession_and_Return.md) | `moving`, `orbit`, `renewal`, `reference` |

The [flagship](publications/01_Flagship.md) presents the common constructive argument. The [Recognition and Construction Atlas](publications/06_Recognition_Atlas.md) maps 33 capabilities to their derivational dependencies and witnesses. [Research Passports](publications/07_Research_Passports.md) give concrete first calculations for five research communities. The [presentation](output/Capstone_Overview.pptx) and [speaking notes](presentation/Speaking_Outline.md) follow the discoveries and their consequences.

## Run the first demonstrations

Use Python 3.12 in a separate virtual environment. The validated environment and installed package versions are in [environment.json](registers/environment.json).

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements-science.txt
.\.venv\Scripts\python -X utf8 demos/run.py verify
.\.venv\Scripts\python -X utf8 demos/run.py quick
```

`verify` checks archived byte identities and quantitative receipt pointers. `quick` stages and executes the original generative witnesses and exact shifted-ball reaction checks in `work/`. To select a larger constructor, use `python demos/run.py run geometry`, substituting a demonstration name from the table. The [demonstration register](registers/Demonstration_Register.md) gives original commands, dependencies and receiving/model conditions. Each selected directory has a current reproduction guide. The package does not invoke complete historical campaigns. Necessary inherited modules support the published operation, not a claim that their original Atlas closed.

## Read, reproduce, and share

The Reading package contains the current publications, machine-readable LaTeX masters, illustrated presentation, passports, figures and evidence maps. The Full Research package includes those same current public files plus selected executable sources, required data, numerical receipts and reproduction instructions for the demonstrated constructions under `archive/`. Choose the Full package when executing historical constructors. The original Atlas manuscripts remain local-only. Their provenance is retained in the [source locators](registers/Original_Source_Locators.md).

The trace is **operation → equation → constructor → receipt → figure**. [Claims](registers/claims.json) identify 24 quantitative receipts; [recognitions](registers/recognitions.json) identify the capability genealogy; [source navigation](registers/source_navigation.json) locates original mathematical masters. The public archive manifest identifies 209 selected construction and evidence files. Whole exploratory campaigns and cleanup history remain local-only. The bibliography distinguishes external equilibrium and cross-section research, upstream grammar and the independent calculations.

## What the shared construction enables

Support law and magnetic shape can be selected together. Current can satisfy a zero summed mechanical-spin constraint. Compact distributions can determine their nuclear sources directly. Phase and handedness can enter actual preparation and work calculations. Positive source measures can carry physical succession. These are achieved operations on their declared carriers, available for new comparisons and compatible compositions.

The next integrated research objective is a source-renewed distributed fusion return with complete thermal, fuel, ash, containing and useful-work participation. The current package supplies the constructive ground for that investigation. Comparison resources and physical conditions accompany each result.

## What is admitted for publication

The [closure register](registers/Closure_Register.md) identifies each published operation. An Atlas is a research notebook, not the unit of closure. Original manuscripts, rejected remapping campaigns, exploratory probes, production logs and cleanup reports are not the public research corpus. Comparisons necessary to establish a claimed operation retain their actual meaning and accounts.
