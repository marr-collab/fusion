# Provenance and numerical reconciliation

## Four distinct source roles

1. **External result E1:** Issan, Citrin, Landreman and Tracey, arXiv:2610.07304v1, 5 October 2026. Verified against the full HTML article on 19 October 2026. Its license is CC BY 4.0. Its MHD equations, explicit solution families and Hamada argument are the authors' work. Their paper's own AI-use statement does not establish any collaboration with this program.
2. **Recognition testimony:** `Argon_Recapture_supplied.md`, copied byte-for-byte from the supplied Downloads file. Stage 0 records the original retyping retrospectively. No separate contemporaneous original Argon transcript was located in the workspace search. The supplied conversational history and recapture remain distinct from the external paper and are not substituted for numerical receipts.
3. **Dependency ground:** the upstream FAP/D-Series and electromagnetic sources in `upstream_sources.json`. Imported structural results are identified as such. A particular numerical model is a selected physical realization, not a unique deduction of geometry, nuclear cross section or transport from those structural relations.
4. **Independent constructions:** the Fusion POG masters, Python implementations and receipts. Their original author/date metadata is unchanged. The new capstone preserves Marr and Thiel's manuscript authorship and contact information. AI-assisted recognition, mathematical development and packaging are documented by the archived ledgers and supplied recapture; authors should review attribution before submission.

## Resolved distinctions

| Item | Source-grounded resolution |
|---|---|
| 2.41198 and 2.54747 | Earlier fluid birth functional versus later non-Maxwellian waterbag reaction. The former JSON stores fractional gain 1.41198; its ratio is 1 plus that field. |
| q≈3.01683 | q=(a/c)^2, not c/a or an elongation directly. The kinetic study retains the fluid-selected q as a test member; it does not re-establish global kinetic optimality. |
| 0.6876/0.68770 and 0.73311% | FEM/source integration and independent-point volume-weighted strong-current L2 checks. Neither is a maximum local relative residual. |
| 2.30048, 2.22906 and 2.31154 ps | Atlas V discrete clock, Atlas VI frozen clock, and independently denser material quadrature comparison. These are different representations, not conflicting exact device frequencies. |
| 321.18 and 321.284 MW | Different alpha samples/carriers and source normalization. The capstone identifies the originating ensemble; sampled retention is not a universal confinement theorem. |
| 8.28e-8 and 1.67e-8 | Full-stage Duhamel bound versus a reduced endpoint measure in the frozen-stage preparation. Neither is the moving nonlinear endpoint error. |
| 3.56e-7 and 7.974% | Inverse-forward reference consistency versus independent forward atomic-current change. The first does not establish source-stationary residence. |
| Skin barrier | The unmagnetized k_z=0 conductor calculation is conditional, not universally false. Restoring magnetized finite-volume response changes the admitted physical problem. |
| Null-ring obstruction | The selected static scalar-resistive Ohm law cannot supply the required current. This is narrower than an unrestricted invocation of Cowling's theorem. |
| Symmetry and closure | Stellarator symmetry is a physical discrete symmetry, not merely a coordinate error. The external result proves that its absence need not destroy the stated equilibrium relations. It does not prove temporal fusion return. |
| Source off | Channel-seed removal, externally driven RMF removal, linear mode preparation removal and nonlinear plasma source removal are different experiments. |
| All obstructions are artifacts | Not adopted from the recapture. The archive contains real constitutive restrictions, resource costs, numerical defects and unfinished physical handoffs. Their distinction preserves the constructive results. |

## Mathematical source policy

Machine-readable MD/TXT from the corpus is authoritative for this synthesis. The D-Series catalog is present as PDF only; the supplied individual D-Series TXT papers and existing Fusion Grammar Recapture supply the operative mathematical locators. The capstone has not silently reconstructed the catalog's formulas through PDF extraction. Human PDFs complement, rather than replace, the literal LaTeX masters.

## Publication status and rights

Prepared as the public release; Zenodo remains an unpublished draft for author inspection. Original historical manuscripts remain local-only. No new blanket open-source license is assigned to historical code or manuscripts. The external arXiv work retains its own attribution/license. The authors should select publication venues, rights and any public code license before distribution.
