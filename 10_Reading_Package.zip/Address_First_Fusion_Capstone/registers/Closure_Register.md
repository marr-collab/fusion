# Publication closure register

The public unit is a completed operation on its stated carrier. Atlas I–XI remain the inward-facing research history. Their whole models are not promoted as closed. Necessary inherited functions are included as dependencies of specific operations; their inclusion does not publish or endorse their original exploratory campaigns.

## generative — G1-G5: 41 original constructor checks; geometry, helicity, phase exchange, RF matching, circuit preparation/removal

**Public treatment:** 01_Flagship. **Receipt:** `archive/Fusion_POG/Generative/results/construction_results.json`.

**Selected source:** `archive/Fusion_POG/Generative/constructors.py`.

**Reproduction:** `python demos/run.py run generative`. Commands: `python constructors.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## geometry — Field equations, support tension, drift admission and restricted smooth-edge shape search

**Public treatment:** 02_Geometry_and_Current. **Receipt:** `archive/Fusion_POG/Inverse_Synthesis/results/regular_shape_solution.json`.

**Selected source:** `archive/Fusion_POG/Inverse_Synthesis/edge_regular_ritz.py`, `archive/Fusion_POG/Inverse_Synthesis/solve_regular_shape.py`, `archive/Fusion_POG/Inverse_Synthesis/support_and_preparation.py`.

**Reproduction:** `python demos/run.py run geometry`. Commands: `python support_and_preparation.py`; `python edge_regular_ritz.py`; `python solve_regular_shape.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## current — Positive invariant waterbag, current/spin and phase-correlated radial renewal

**Public treatment:** 02_Geometry_and_Current. **Receipt:** `archive/Fusion_POG/Active_Renewal/results/profile_handoff.json`.

**Selected source:** `archive/Fusion_POG/Active_Renewal/kinetic_accounts.py`, `archive/Fusion_POG/Active_Renewal/kinetic_constructor.py`, `archive/Fusion_POG/Active_Renewal/profile_handoff.py`, `archive/Fusion_POG/Active_Renewal/rmf_constructor.py`.

**Reproduction:** `python demos/run.py run current`. Commands: `python kinetic_constructor.py`; `python kinetic_accounts.py`; `python rmf_constructor.py`; `python profile_handoff.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## reaction — Exact shifted-ball reduction and matched dimensioned birth comparison

**Public treatment:** 03_Nuclear_Source_and_Channel. **Receipt:** `archive/Fusion_POG/Burn_Renewal/results/dimensional_results.json`.

**Selected source:** `archive/Fusion_POG/Burn_Renewal/independent_checks.py`, `archive/Fusion_POG/Burn_Renewal/waterbag_reactions.py`.

**Reproduction:** `python demos/run.py run reaction`. Commands: `python waterbag_reactions.py`; `python independent_checks.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## channel — Bounded spatially shaped catalytic channel with separate bulk heater

**Public treatment:** 03_Nuclear_Source_and_Channel. **Receipt:** `archive/Fusion_POG/Integrated/results/envelope_channel/dynamic_envelope_0.04_550_384_2e-07.json`.

**Selected source:** `archive/Fusion_POG/Integrated/check_envelope_channel.py`, `archive/Fusion_POG/Integrated/run_envelope_channel.py`.

**Reproduction:** `python demos/run.py run channel`. Commands: `python check_envelope_channel.py`; `python run_envelope_channel.py dynamic_envelope .04 550 384 2e-7 30`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## deposition — Physical-rate full Lorentz alpha slowing and species receiving; see original CLI before choosing expensive run

**Public treatment:** 03_Nuclear_Source_and_Channel. **Receipt:** `archive/Fusion_POG/Finite_Slip_Renewal/results/continuation_admission.json`.

**Selected source:** `archive/Fusion_POG/Finite_Slip_Renewal/alpha_slowing.py`, `archive/Fusion_POG/Finite_Slip_Renewal/extended_slowing.py`.

**Reproduction:** `python demos/run.py run deposition`. Commands: `python alpha_slowing.py`; `python extended_slowing.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## volume — Magnetized volume mode, quadrupolar preparation and source-off linear continuation

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Internal_Renewal/results/preparation.json`.

**Selected source:** `archive/Fusion_POG/Internal_Renewal/prepare_volume.py`, `archive/Fusion_POG/Internal_Renewal/volume_modes.py`.

**Reproduction:** `Original exact command sequence in archived README (recipe_commands)`. Inspect the selected source and current directory guide; the saved receipt is supplied. No full historical campaign is invoked.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## reciprocity — Implicit live alpha-field reciprocity and common energy/momentum

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Reciprocal_Atlas/results/live_d3_b32_az8_t2_p1_h0.05_s1e-05_a1_precision.json`.

**Selected source:** `archive/Fusion_POG/Reciprocal_Atlas/live_precise.py`, `archive/Fusion_POG/Reciprocal_Atlas/poisson_carrier.py`.

**Reproduction:** `Original exact command sequence in archived README (recipe_commands)`. Inspect the selected source and current directory guide; the saved receipt is supplied. No full historical campaign is invoked.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## compatible — Curved field/scalar source compatibility and completed canonical generator

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/CoRefined_Organization/results/curved_r5_n48_e64_p96_verification.json`.

**Selected source:** `archive/Fusion_POG/CoRefined_Organization/curved_mean.py`, `archive/Fusion_POG/CoRefined_Organization/verify_curved.py`.

**Reproduction:** `Original exact command sequence in archived README (recipe_commands)`. Inspect the selected source and current directory guide; the saved receipt is supplied. No full historical campaign is invoked.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## phase — Fast-mode identification, phase-action and pressure/source identities

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Phase_Return/results/verification.json`.

**Selected source:** `archive/Fusion_POG/Phase_Return/exponential.py`, `archive/Fusion_POG/Phase_Return/structure.py`.

**Reproduction:** `python demos/run.py run phase`. Commands: `python structure.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## source — Co-located material overlap and reciprocal reaction receiving

**Public treatment:** 03_Nuclear_Source_and_Channel. **Receipt:** `archive/Fusion_POG/Phase_Return/results/overlap_source.json`.

**Selected source:** `archive/Fusion_POG/Phase_Return/overlap_source.py`, `archive/Fusion_POG/Phase_Return/source_update.py`.

**Reproduction:** `python demos/run.py run source`. Commands: `python overlap_source.py`; `python source_update.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## quiet — Positive force-compatible and orbit-informed quiet constitution

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Quiet_Return/results/quiet_positive_2ns.json`.

**Selected source:** `archive/Fusion_POG/Quiet_Return/enrich_material.py`, `archive/Fusion_POG/Quiet_Return/forward.py`.

**Reproduction:** `Original exact command sequence in archived README (recipe_commands)`. Inspect the selected source and current directory guide; the saved receipt is supplied. No full historical campaign is invoked.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## handedness — Matched nonlinear preparation and handedness response

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Rotating_Transport/results/paired_comparison.json`.

**Selected source:** `archive/Fusion_POG/Rotating_Transport/prepared_quiet.py`, `archive/Fusion_POG/Rotating_Transport/pulse_physical_accounts.py`.

**Reproduction:** `Original exact command sequence in archived README (recipe_commands)`. Inspect the selected source and current directory guide; the saved receipt is supplied. No full historical campaign is invoked.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## preparation — Full frozen-stage phase-vector inverse engagement and bound

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Common_Phase/results/preparation_bound.json`.

**Selected source:** `archive/Fusion_POG/Common_Phase/mode_preparation.py`, `archive/Fusion_POG/Common_Phase/verify_preparation.py`.

**Reproduction:** `Original exact command sequence in archived README (recipe_commands)`. Inspect the selected source and current directory guide; the saved receipt is supplied. No full historical campaign is invoked.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## tangent — Complete moving nonlinear derivative and independent directional construction

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Complete_Progression/results/full_constructor.json`.

**Selected source:** `archive/Fusion_POG/Complete_Progression/full_tangent.py`.

**Reproduction:** `python demos/run.py run tangent`. Commands: `python full_tangent.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## moving — Moving nonlinear response and rebased chain-rule tests using preserved trajectories

**Public treatment:** 05_Source_Succession_and_Return. **Receipt:** `archive/Fusion_POG/Physical_Return/results/comparisons.json`.

**Selected source:** `archive/Fusion_POG/Physical_Return/moving_flow.py`, `archive/Fusion_POG/Physical_Return/moving_tangent.py`, `archive/Fusion_POG/Physical_Return/variational_composition.py`.

**Reproduction:** `python demos/run.py run moving`. Commands: `python variational_composition.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## orbit — Exact conditional half-turn history quotient

**Public treatment:** 05_Source_Succession_and_Return. **Receipt:** `archive/Fusion_POG/Complete_Progression/results/orbit_bundles.json`.

**Selected source:** `archive/Fusion_POG/Complete_Progression/orbit_bundles.py`.

**Reproduction:** `python demos/run.py run orbit`. Commands: `python orbit_bundles.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## reference — Conditional inverse-reference rechart plus distinct independent forward test

**Public treatment:** 05_Source_Succession_and_Return. **Receipt:** `archive/Fusion_POG/Physical_Return/results/reference_admission.json`.

**Selected source:** `archive/Fusion_POG/Physical_Return/eulerian_rechart.py`, `archive/Fusion_POG/Physical_Return/reference_admission.py`.

**Reproduction:** `python demos/run.py run reference`. Commands: `python eulerian_rechart.py --name capstone_reference --phases 4 --rtol 1e-13`; `python reference_admission.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## renewal — Positive one-period nuclear/collision receiving action; not full-age fixed point

**Public treatment:** 05_Source_Succession_and_Return. **Receipt:** `archive/Fusion_POG/Physical_Return/results/renewal_cubature.json`.

**Selected source:** `archive/Fusion_POG/Physical_Return/renewal_action.py`.

**Reproduction:** `python demos/run.py run renewal`. Commands: `python renewal_action.py --name capstone_renewal --phases 1 --deterministic`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

## work — Analytical exponential stage work versus numerical quadrature

**Public treatment:** 04_Reciprocal_Dynamics_and_Phase. **Receipt:** `archive/Fusion_POG/Physical_Return/results/analytic_work_check.json`.

**Selected source:** `archive/Fusion_POG/Physical_Return/check_analytic.py`.

**Reproduction:** `python demos/run.py run work`. Commands: `python check_analytic.py`.

**Admission:** The positive operation stated here and in the current technical annex; selected receipt checks and model conditions apply. No Atlas is admitted as a wholly closed model.

