from pathlib import Path
import json,hashlib
from pypdf import PdfReader
import pdfplumber
R=Path(__file__).resolve().parents[1]
reports=[]
for p in sorted((R/'output/pdf').glob('*.pdf')):
 r=PdfReader(p);outside=[];badlinks=[]
 with pdfplumber.open(p) as doc:
  for i,page in enumerate(doc.pages):
   for c in page.chars:
    if c['x0'] < -1 or c['x1']>page.width+1 or c['top'] < -1 or c['bottom']>page.height+1:outside.append(i+1);break
 for page in r.pages:
  for a in page.get('/Annots',[]):
   action=a.get_object().get('/A');uri=str(action.get('/URI','')) if action else ''
   if uri and not uri.startswith(('http:','https:','mailto:')):
    if uri.startswith('file:') or not (p.parent/uri).exists():badlinks.append(uri)
 reports.append({'file':p.relative_to(R).as_posix(),'pages':len(r.pages),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'outside_page_text':outside,'bad_local_links':badlinks})
assert not any(x['outside_page_text'] or x['bad_local_links'] for x in reports),reports
(R/'validation/final_pdf_structure.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
print('Final PDFs',len(reports),'pages',sum(x['pages'] for x in reports),'all text in bounds and local links resolve')
claims=json.loads((R/'registers/claims.json').read_text(encoding='utf-8'));recognitions=json.loads((R/'registers/recognitions.json').read_text(encoding='utf-8'))
seen=set()
for row in recognitions:
 assert set(row['depends_on'])<=seen,row['id'];seen.add(row['id'])
 for k in ['source']:
  p=R/row[k];assert p.exists();assert hashlib.sha256(p.read_bytes()).hexdigest()==row['source_sha256']
for p in (R/'publications').glob('0*.md'):
 assert p.with_suffix('.txt').read_text(encoding='utf-8').split('\n\n',1)[1]==p.read_text(encoding='utf-8')
print('Recognition dependencies and exact math companions pass')
