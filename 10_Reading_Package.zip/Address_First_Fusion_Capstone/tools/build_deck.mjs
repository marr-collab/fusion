import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
const R=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const runtime='C:/Users/ArtLab/.cache/codex-runtimes/codex-primary-runtime/dependencies';
process.env.RUNTIME_NODE_MODULES=runtime+'/node/node_modules';
const skill='C:/Users/ArtLab/.codex/plugins/cache/openai-primary-runtime/presentations/26.1011.51657/skills/presentations';
const {Presentation,PresentationFile}=await import(pathToFileURL(runtime+'/node/node_modules/@oai/artifact-tool/dist/artifact_tool.mjs').href);
const {finalizePresentation}=await import(pathToFileURL(skill+'/container_tools/artifact_tool_utils.mjs').href);
const slides=JSON.parse(await fs.readFile(path.join(R,'presentation/slides.json'),'utf8'));
await fs.mkdir(path.join(R,'presentation/previews'),{recursive:true});await fs.mkdir(path.join(R,'tmp/deck'),{recursive:true});await fs.mkdir(path.join(R,'output'),{recursive:true});
const pres=Presentation.create({slideSize:{width:1280,height:720}});
function text(s,str,x,y,w,h,size=28,color='#17394a',bold=false){let t=s.shapes.add({geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}});t.text=str;t.text.style={typeface:'Arial',fontSize:size,color,bold};return t;}
for(let i=0;i<slides.length;i++){
 const d=slides[i],s=pres.slides.add();s.background.fill=i===0?'#123e50':'#f8faf9';
 text(s,d.title,64,50,1150,i===0?180:110,i===0?60:42,i===0?'#ffffff':'#123e50',true);
 if(i===0){text(s,d.body,68,300,1050,160,32,'#d5e8e9');text(s,'R. Wade H. Marr and Joseph Adam Thiel\n21 October 2026 · Public research release',68,560,1080,80,23,'#d5e8e9');}
 else{
  text(s,d.body,64,190,d.image||d.aside?440:1120,400,29);
  if(d.image)s.images.add({blob:new Uint8Array(await fs.readFile(path.join(R,'figures',d.image))),contentType:'image/png',alt:d.title,fit:'contain',position:{left:540,top:180,width:680,height:430}});
  if(d.aside)text(s,d.aside,585,235,600,340,33,'#087f7d',true);
  text(s,String(i+1).padStart(2,'0')+'  ·  Address-first Fusion Capstone',64,658,1100,28,17,'#53707d');
 }
 s.speakerNotes.text=d.note+"\n\nTechnical reference and scope: "+d.scope;
 const png=await pres.export({slide:s,format:'png',scale:1});await fs.writeFile(path.join(R,'presentation/previews',String(i+1).padStart(2,'0')+'.png'),new Uint8Array(await png.arrayBuffer()));console.log('slide',i+1);
}
const candidate=path.join(R,'tmp/deck/candidate.pptx');await (await PresentationFile.exportPptx(pres)).save(candidate);
const result=await finalizePresentation({workspaceDir:R,candidatePath:candidate,finalPath:path.join(R,'tmp/deck/final/complete.pptx'),pythonExecutable:runtime+'/python/python.exe',integrityValidatorPath:skill+'/container_tools/inspect_presentation_package_integrity.py',layoutValidatorPath:skill+'/container_tools/inspect_presentation_layout_geometry.py',layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit'],fontPolicy:{basis:'design',families:['Arial']},verifyArtifactToolImport:true,receiptPath:path.join(R,'validation/presentation-final.json')});
console.log(JSON.stringify(result));

await fs.copyFile(path.join(R,"tmp/deck/final/complete.pptx"),path.join(R,"output/Capstone_Overview.pptx"));
await fs.copyFile(path.join(R,"validation/presentation-final.json"),path.join(R,"validation/presentation.json"));
