from pathlib import Path
import json,hashlib,shutil,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];F=R/'figures';F.mkdir(exist_ok=True)
C={c['id']:c for c in json.loads((R/'registers/claims.json').read_text())}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':180})
navy='#12465a';teal='#168c88';gold='#be7835';notes=[]
def save(fig,name,data,claims):
 fig.tight_layout();fig.savefig(F/(name+'.png'),facecolor='white');fig.savefig(F/(name+'.svg'),facecolor='white');plt.close(fig)
 (F/(name+'.json')).write_text(json.dumps({'data':data,'claims':claims,'source_receipts':[C[x] for x in claims]},indent=2))
 notes.append({'figure':f'figures/{name}.png','data':f'figures/{name}.json','claims':claims})
fig,ax=plt.subplots(figsize=(9,4.2));ys=['Polynomial field only','Polynomial + tension-only support','Smooth-edge fluid family'];vals=[8/3,np.sqrt(13)-1,C['C02']['value']]
ax.barh(ys,vals,color=[navy,teal,gold]);ax.invert_yaxis();ax.set_xlim(0,3.6);ax.set_xlabel(r'Shape parameter $q=(a/c)^2$')
for i,v in enumerate(vals):ax.text(v+.04,i,f'{v:.6f}',va='center')
ax.set_title('Support and current admission change selected shape',loc='left',pad=18)
save(fig,'geometry',dict(labels=ys,q=vals),['C02','C03'])
d=json.loads((R/'archive/Fusion_POG/Burn_Renewal/results/dimensional_results.json').read_text());m=[d['members'][1],d['members'][4]]
fig,ax=plt.subplots(figsize=(8.5,4.3));x=np.arange(2);ap=[r['alpha_birth_W']/1e6 for r in m];nn=[r['neutron_birth_W']/1e6 for r in m]
ax.bar(x,ap,color=teal,label='Alpha Q-value birth');ax.bar(x,nn,bottom=ap,color=navy,label='Neutron Q-value birth');ax.set_xticks(x,['Sphere: q=1','Oblate: q=3.016827']);ax.set_ylabel('Nuclear birth power (MW)');ax.set_ylim(0,2150);ax.legend(frameon=False,loc='upper left');ax.text(1,1900,'2.54747× total birth',ha='center',color=navy)
ax.set_title('Matched peak field, volume and moment temperature',loc='left',pad=18)
save(fig,'birth',dict(alpha_MW=ap,neutron_MW=nn),['C05','C06','C07'])
p=json.loads((R/'archive/Fusion_POG/Phase_Return/results/verification.json').read_text())['phase_tests'][:4]
fig,ax=plt.subplots(figsize=(8.5,4.2));x=np.array([v['dt'] for v in p])*1e9
ax.semilogy(x,[v['midpoint_phase_state_error'] for v in p],'o-',color=gold,label='Implicit midpoint');ax.semilogy(x,[v['exponential_phase_state_error'] for v in p],'s-',color=teal,label='Reciprocal exponential');ax.set_xlabel('Frozen-stage step (ns)');ax.set_ylabel('Phase-state error');ax.legend(frameon=False);ax.set_title('The 2.229 ps frozen electromagnetic clock',loc='left',pad=18);ax.grid(axis='y',alpha=.2)
save(fig,'phase',p,['C13','C14'])
fig,ax=plt.subplots(figsize=(8.5,4.0));ys=['Inverse-forward reference\nconsistency','Independent forward\natomic-current change'];v=[C['C21']['value'],C['C22']['value']]
ax.barh(ys,v,color=[teal,gold]);ax.set_xscale('log');ax.set_xlim(1e-8,1);ax.set_xlabel('Relative current difference (different tests)');ax.invert_yaxis();ax.set_title('A reference rechart and a population test',loc='left',pad=18)
for i,x in enumerate(v):ax.text(x*1.25,i,f'{x:.3g}',va='center')
save(fig,'reference',dict(labels=ys,value=v),['C21','C22'])
fig,ax=plt.subplots(figsize=(8.5,4));vals=[66867.5,C['C15']['value']];ax.bar(['Inherited Atlas VI','Quiet complete'],vals,color=[gold,teal]);ax.set_yscale('log');ax.set_ylabel('Scalar-field energy at 2 ns (J)');ax.set_ylim(.03,1e6);ax.set_title('Constitution on the actual advancing maps',loc='left',pad=18)
for i,v in enumerate(vals):ax.text(i,v*1.5,f'{v:,.6g} J',ha='center')
save(fig,'quiet',dict(inherited_manuscript_value_J=66867.5,quiet_J=C['C15']['value']),['C15'])
fig,ax=plt.subplots(figsize=(8.5,4));vals=[C['C16']['value'],C['C17']['value']];ax.bar(['Original handedness','Reversed handedness'],vals,color=[navy,teal]);ax.set_ylim(0,.36);ax.set_ylabel('Incremental alpha-to-inductive work (J)');ax.set_title('Finite-time phase control on the quiet carrier',loc='left',pad=18)
for i,v in enumerate(vals):ax.text(i,v+.012,f'+{v:.5f} J',ha='center')
save(fig,'handedness',dict(work_J=vals,qualification='Distinct source work; not an equal-input efficiency comparison.'),['C16','C17'])
for src,dst in [('Generative/results/geometry_return.png','asymmetric_return.png'),('Generative/results/matching_support.png','circuit.png'),('Generative/results/phase_design.png','phase_design.png'),('Generative/results/wave_channel.png','wave_channel.png'),('Physical_Return/figures/physical_response.png','moving_response.png')]:
 p=R/'archive/Fusion_POG'/src
 if p.exists():shutil.copy2(p,F/dst);notes.append({'figure':'figures/'+dst,'source':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'registers/figure_manifest.json').write_text(json.dumps(notes,indent=2))
print('Figures',len(notes))
