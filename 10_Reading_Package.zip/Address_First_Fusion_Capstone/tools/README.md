# Current publication tools

The public mathematical masters, figures and presentation are the source of the rendered publications. `render_papers.cjs`, `proof.py` and `build_deck.mjs` render these existing materials; their workstation/runtime requirements are recorded in source. `build_figures.py` uses preserved numerical receipts. Scientific reproduction begins with `demos/run.py`, not these editorial tools.

The executable evidence library is selected by completed operation and required dependency. The Closure Register and public archive manifest state that boundary. Original Atlas manuscripts, whole exploratory campaigns, logs and cleanup scripts remain local-only.
