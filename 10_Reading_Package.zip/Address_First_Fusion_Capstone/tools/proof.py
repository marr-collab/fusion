from pathlib import Path
import json,subprocess,os,re
from pypdf import PdfReader,PdfWriter
from PIL import Image,ImageOps,ImageDraw
R=Path(__file__).resolve().parents[1];out=R/'output/pdf';prev=R/'validation/pages';prev.mkdir(parents=True,exist_ok=True)
pop='C:/Users/ArtLab/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/poppler/Library/bin/pdftoppm.exe'
reports=[]
for p in prev.glob('*.png'):p.unlink()
for p in sorted(out.glob('0[1-7]_*.pdf')):
 reader=PdfReader(p);w=PdfWriter();w.clone_document_from_reader(reader)
 w.add_metadata({'/Title':p.stem.replace('_',' '),'/Author':'R. Wade H. Marr and Joseph Adam Thiel','/Subject':'Address-first Fusion Capstone; public research release, 21 October 2026'})
 for page in w.pages:
  for ann in page.get('/Annots',[]):
   obj=ann.get_object();action=obj.get('/A')
   if action and '/URI' in action:
    uri=str(action['/URI'])
    if uri.startswith('file:'):
     from urllib.parse import unquote,urlparse
     from pypdf.generic import TextStringObject,NameObject
     local=unquote(urlparse(uri).path).lstrip('/')
     if '/mailto:' in local:action[NameObject('/URI')]=TextStringObject('mailto:'+local.split('/mailto:',1)[1])
     if Path(local).exists():action[NameObject('/URI')]=TextStringObject(os.path.relpath(local,p.parent).replace('\\','/'))
 tmp=p.with_suffix('.new.pdf');w.write(tmp);tmp.replace(p)
 subprocess.run([pop,'-scale-to','1400','-png',str(p),str(prev/p.stem)],check=True,capture_output=True)
 text='\n'.join(x.extract_text() or '' for x in PdfReader(p).pages)
 reports.append({'file':p.relative_to(R).as_posix(),'pages':len(reader.pages),'replacement_character':'\ufffd' in text,'authors':all(x in text for x in ('Marr','Thiel'))})
 # Literal source fidelity, not a PDF-to-math transcription.
 md=R/'publications'/p.with_suffix('.md').name;txt=md.with_suffix('.txt')
 if md.exists():assert txt.read_text(encoding='utf-8').split('\n\n',1)[1]==md.read_text(encoding='utf-8')
# Slide PDF is a portable illustrated companion to the editable PowerPoint.
from reportlab.pdfgen import canvas
c=canvas.Canvas(str(out/'08_Presentation.pdf'),pagesize=(960,540));c.setAuthor('R. Wade H. Marr and Joseph Adam Thiel');c.setTitle('Address-first Fusion Capstone: overview')
for p in sorted((R/'presentation/previews').glob('*.png')):c.drawImage(str(p),0,0,960,540);c.showPage()
c.save()
files=sorted(prev.glob('*.png'))
for batch in range(0,len(files),6):
 chunk=files[batch:batch+6];sheet=Image.new('RGB',(1260,1000),'#d7dfe2');dr=ImageDraw.Draw(sheet)
 for j,p in enumerate(chunk):
  im=Image.open(p);im.thumbnail((406,465));x=(j%3)*420+7;y=(j//3)*500+22;sheet.paste(im,(x,y));dr.text((x,y-18),p.stem,fill='black')
 sheet.save(R/'validation'/f'paper_contact_{batch//6+1:02}.jpg')
(R/'validation/pdf_checks.json').write_text(json.dumps(reports,indent=2));print(json.dumps(reports,indent=2));print('Page PNGs',len(files))
