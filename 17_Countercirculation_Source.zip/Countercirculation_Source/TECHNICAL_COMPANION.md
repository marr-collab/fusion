# Current without net mechanical spin

## Technical companion to the 45-second numerical visualization

Research: R. Wade H. Marr and Joseph Adam Thiel. Address-First Fusion POG.
Reserved research DOI supplied by the authors: https://doi.org/10.5281/zenodo.23523832.

The movie renders an existing stationary, collisionless, quasineutral waterbag construction. It is not reactor footage, a new burn simulation, or a demonstration of stability. Its positive result is specific: electron and D–T mean circulations carry electric current while their **summed mechanical angular momentum vanishes pointwise**. Electromagnetic angular momentum is a separate account. Zero summed mechanical angular momentum does not eliminate individual centrifugal stresses.

## 1. The actual spatial carrier

The archived degree-nine member has

\[
\mathcal G=\{(R,\phi,z):R^2/a^2+z^2/c^2\le1\},\qquad
q=(a/c)^2=3.0168271858,
\]
\[
a=q^{1/6}L=1.2020570285825316\ \mathrm m,\qquad
c=q^{-1/3}L=0.6920697321326482\ \mathrm m,\quad L=1\ \mathrm m.
\]

Its volume is \(4\pi L^3/3=4.1887902047863905\ \mathrm{m^3}\), peak calculated magnetic field is 5 T, and peak electron waterbag temperature parameter is 16.71 keV. The admissible domain is an oblate ellipsoid, not an imposed toroidal vessel. The density of this member vanishes on its symmetry axis as well as at its edge; its bright annular region follows the calculated density. The selected q was inherited from the earlier inverse family; this video makes no new optimality claim.

## 2. Distribution, current and mechanical angular momentum

\[
f_s=C_s\mathbf1_{K_s<0},\quad
K_s=H_s-\Omega_sP_{\phi s},\quad
H_s=\tfrac12m_s|v|^2+q_s\Phi,\quad
P_{\phi s}=m_sRv_\phi+q_s\psi.
\]
\[
\mathbf u_s=\Omega_sR\mathbf e_\phi,\qquad
n_D=n_T=\tfrac12n_e,\qquad
\Omega_e=-\Omega,\quad\Omega_D=\frac{m_e}{m_D}\Omega,\quad
\Omega_T=\frac{m_e}{m_T}\Omega.
\]

The archived mass ratios are \(m_D/m_e=3670.48\), \(m_T/m_e=5496.92\). The **same physical clock** drives every species in the movie:

| Species | Mean rotation (rad/s) | Integrated mechanical angular momentum (kg m²/s) |
|---|---:|---:|
| Electron | −65743.11885681943 | −0.00020709539184586887 |
| Deuterium | +17.91131374011558 | +0.00010354769592293444 |
| Tritium | +11.959991933086062 | +0.00010354769592293444 |
| Sum | Not an angular velocity | 0 |

\[
\ell_z=R^2\sum_s m_sn_s\Omega_s
=m_en_e\Omega R^2(-1+\tfrac12+\tfrac12)=0.
\]
\[
J_\phi=\sum_s q_sn_s\Omega_sR
=en_e\Omega R\left(1+\frac{m_e}{2m_D}+\frac{m_e}{2m_T}\right)>0
\]
where \(n_e>0\) and \(R>0\). Negative charge circulating in the negative direction and positive charges circulating in the positive direction produce currents of the same sign. The three displayed colors are qualitative species identifiers, not temperatures, number weights or current magnitudes. Electron current dominates in this member; equal visual brightness does not imply equal species current.

## 3. Regenerated magnetic field and volume

The preserved conditioned Ritz constructor solves the same nonlinear field equation as the historical calculation:

\[
-\Delta^*\widehat\chi=\kappa\widehat R^2\widehat\chi^{3/2},\quad
\widehat\psi=\widehat\chi-\tfrac12h\widehat R^2,\quad
\widehat\chi=\widehat R^2u(\widehat R,\widehat z).
\]
\[
B_R=-B_*\widehat R\,u_{,\widehat z},\qquad
B_z=B_*(2u+\widehat R u_{,\widehat R}-h),\qquad B_\phi=0.
\]
\[
n_e=\frac{m_e}{\mu_0e^2L^2}\frac{\kappa\widehat\chi^{3/2}}{h(1+\bar\mu)},\quad
\bar\mu=\frac{m_e}{2m_D}+\frac{m_e}{2m_T},\quad p\propto\chi^{5/2}.
\]

Here \(B_*=5\ \mathrm T\), \(h=7.475821123668978\times10^{-8}\), and \(\kappa=96.10688940199039\). The small uniform centrifugal correction is included: \(B_{\mathrm{bias}}=-3.737910561834489\times10^{-7}\ \mathrm T\).

The historical NPZ stores quadrature profiles, not a complete 3D field texture. We therefore reran `ConditionedOrganization(q, degree=9, spin=spin_input)` from an unchanged copy of the preserved constructor. Both regenerated χ and density agree with the stored 2,304-point profile with relative L² difference **0.0 in this run**. The historical strong-field residual is 0.0007440645 (0.07440645%); bitwise profile agreement is not a claim of zero PDE discretization error.

Independent checks of the resampled drawn flux curves give a maximum flux range of 1.868 × 10⁻⁵ of peak χ and an RMS tangent/B misalignment sine of 5.521 × 10⁻⁴. Every curve remains inside the admitted domain; its maximum ellipsoidal level is 0.970394. These are geometric rendering checks, not new equilibrium claims.

The cinematic density volume uses a 641 × 641 R–z sample of \(n_e/n_{e,\max}\), revolved about the symmetry axis. The calculated peak density is \(4.6509806419872344\times10^{21}\ \mathrm{m^{-3}}\). Lavender curves follow contours of the **corrected ψ**, then rotate to four azimuths. Their tangent is parallel or antiparallel to the interior poloidal B field. Only the admitted interior field is drawn; no exterior magnetic geometry is invented. The direction of B is not encoded by traveling light on these static curves.

## 4. What the viewer sees

| Film element | Mathematical source | Display treatment |
|---|---|---|
| Oblate outline | Exact a, c above | Faint spatial guide; not a metal shell |
| Blue volume | Regenerated χ³ᐟ² density | Emission, color and lighting are illustrative, not predicted radiation |
| Cyan / amber / rose streaks | Mean flow at fixed R,z; φ(t)=φ₀+Ωₛt | 150 electron, 60 D, 60 T representative traces; density-sampled inside ellipsoidal level 0.96; not thermal single-particle orbits |
| Lavender curves, revealed at 21 s | Corrected ψ contours | Representative interior field lines; density of curves does not encode field strength |
| Camera motion | Rendering only | Changes viewing direction, not the equilibrium |
| Ambient audio | Original synthesized tones | Sound design, not plasma sonification |

There are two clock scales, disclosed on screen. From film time 0 to 13 s, one film second represents 40 μs. Thereafter, one film second represents 75 ms. Position is continuous at the clock change. The electron / D / T rate ratios never change. The trails cover 0.12 film seconds at the first scale and 0.20 film seconds at the second. Full-turn electron exposure is represented as stationary circular averages; 25 representative electron rings are retained after the scale change to keep fuel motion readable. This is a deliberate exposure and sampling treatment, not ion-speed exaggeration. The electron distribution remains represented by its density volume.

The visualization advances exact mean-flow coordinates on the supplied stationary construction. The accumulated display time does not establish collisional lifetime, stability, maintained burning, or integrated reactor continuation. The original construction's quasineutral scope remains unchanged.

## 5. Receipts and reproduction

`data/visualization_receipt.json` records exact parameters, regenerated-profile errors, angular momentum, current moments and SHA-256 hashes of the constructor copies. `data/field_grid.npz` contains the field and density grid. `data/field_lines.json` contains every calculated flux curve. `data/tracers.npy` fixes the density-sampled starting positions. `data/dimensional_results.json` and the original profile NPZ retain the historical receipt.

Constructor genealogy in the preserved Full Research archive:

- `archive/Fusion_POG/Inverse_Synthesis/edge_regular_ritz.py`: oblate boundary and basis.
- `archive/Fusion_POG/Active_Renewal/kinetic_constructor.py`: invariant waterbags, fields and mean circulation.
- `archive/Fusion_POG/Burn_Renewal/conditioned_fields.py`: derivative-QR numerical solve of that same field equation.
- `archive/Fusion_POG/Burn_Renewal/dimensional_constructor.py`: dimensional parameter selection and profile accounts.
- `archive/Fusion_POG/Burn_Renewal/results/dimensional_results.json`: selected q, degree-nine, L=1 m record.

Use `python production/regenerate_data.py`, then `blender -b --python production/scene.py -- --render`, then `python production/finish_film.py`. The package includes local constructor copies for field regeneration after extraction; the original archive is unchanged. Dependencies and complete reproduction steps are in `README.md`. The companion's field figure and algebra provide the technical receipt; the movie provides a visual entrance to it.
