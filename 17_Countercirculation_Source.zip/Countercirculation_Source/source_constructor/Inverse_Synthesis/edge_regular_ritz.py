"""Smooth-boundary Rayleigh-Ritz inverse for p=kappa psi^2/2.

All basis functions vanish on the ellipsoid; no staircase surface is used.
This repairs the current-energy embedding, not kinetic/current-renewal closure.
Peak-field normalization is numerical (grid plus bounded optimization).
"""
from pathlib import Path
import json
import numpy as np
from numpy.polynomial.legendre import Legendre,leggauss
from scipy.linalg import eigh
from scipy.optimize import minimize
from scipy.integrate import cumulative_trapezoid

class RitzOrganization:
    def __init__(self,q=1.,degree=5):
        self.q=q;self.a=q**(1/6);self.c=q**(-1/3);self.degree=degree
        self.pairs=[(i,j) for i in range(degree+1) for j in range(degree+1-i)]
        self.coeff=np.ones(len(self.pairs));self.norm=1.
        g,w=leggauss(max(40,4*degree+12));r=(g+1)/2;t=(g+1)*np.pi/4
        rr,tt=np.meshgrid(r,t,indexing='ij')
        R=self.a*rr*np.sin(tt);Z=self.c*rr*np.cos(tt)
        weights=np.outer(w/2,w*np.pi/4)*self.a*self.c*rr
        b,br,bz=self.basis(R.ravel(),Z.ravel())
        wk=(weights*R**3).ravel();wm=(weights*R**5).ravel()
        K=(br*wk)@br.T+(bz*wk)@bz.T;M=(b*wm)@b.T
        vals,vec=eigh(K,M,subset_by_index=[0,0]);self.kappa=float(vals[0])
        self.coeff=vec[:,0]*np.sign(vec[:,0].sum())
        # Choose sign by evaluating a physical interior point, not coefficients.
        if self.evaluate(np.array([self.a*.4]),np.array([0.]))[0][0]<0:self.coeff*=-1
        self.galerkin_residual=float(np.linalg.norm(K@self.coeff-self.kappa*M@self.coeff)/np.linalg.norm(K@self.coeff))
        def objective(x):
            R=self.a*x[0]*np.sin(x[1]);Z=self.c*x[0]*np.cos(x[1])
            _,br,bz=self.evaluate(np.array([R]),np.array([Z]));return -float(br[0]**2+bz[0]**2)
        candidates=[]
        for rho in [0.,.4,.8,1.]:
            for angle in [0.,.4,.9,np.pi/2]:
                o=minimize(objective,[rho,angle],bounds=[(0,1),(0,np.pi/2)],method='L-BFGS-B')
                candidates.append(-o.fun)
        self.norm=1/np.sqrt(max(candidates))
        self.quad=(R,Z,weights)

    def basis(self,R,Z):
        x=(R/self.a)**2;y=(Z/self.c)**2;f=1-x-y
        out=[];dx=[];dy=[]
        px=[Legendre.basis(i)(2*x-1) for i in range(self.degree+1)]
        py=[Legendre.basis(i)(2*y-1) for i in range(self.degree+1)]
        dpx=[Legendre.basis(i).deriv()(2*x-1) for i in range(self.degree+1)]
        dpy=[Legendre.basis(i).deriv()(2*y-1) for i in range(self.degree+1)]
        for i,j in self.pairs:
            v=px[i]*py[j]
            out.append(f*v)
            dx.append(-v+2*f*dpx[i]*py[j])
            dy.append(-v+2*f*px[i]*dpy[j])
        return np.array(out),np.array(dx)*2*R/self.a**2,np.array(dy)*2*Z/self.c**2

    def evaluate(self,R,Z):
        b,br,bz=self.basis(R,Z);u=self.norm*(self.coeff@b)
        ur=self.norm*(self.coeff@br);uz=self.norm*(self.coeff@bz)
        return u,-R*uz,2*u+R*ur

    def report(self):
        R,Z,w=self.quad;u,br,bz=self.evaluate(R.ravel(),Z.ravel());R=R.ravel();Z=Z.ravel();w=w.ravel()
        psi=R*R*u;p=.5*self.kappa*psi**2;j=self.kappa*R*psi
        dv=4*np.pi*R*w;V=4*np.pi/3
        h=1e-4
        # Strong PDE evaluated away from coordinate boundaries by differentiating u.
        sel=(R>.02*self.a)&(Z>.02*self.c)&((R/self.a)**2+(Z/self.c)**2<.95)
        r=R[sel];z=Z[sel];v=u[sel]
        up=self.evaluate(r+h,z)[0];um=self.evaluate(r-h,z)[0]
        zp=self.evaluate(r,z+h)[0];zm=self.evaluate(r,z-h)[0]
        lap=(up-2*v+um)/h**2+3/r*(up-um)/(2*h)+(zp-2*v+zm)/h**2
        rel=np.sqrt(np.mean((lap+self.kappa*r*r*v)**2))/np.sqrt(np.mean((self.kappa*r*r*v)**2))
        th=np.linspace(0,np.pi/2,4001);st=np.sin(th);ct=np.cos(th)
        _,bs,bz=self.evaluate(self.a*st,self.c*ct);load=(bs*bs+bz*bz)/2
        ell=np.sqrt(self.a**2*ct**2+self.c**2*st**2)
        integ=cumulative_trapezoid(load*st*ct,th,initial=0)
        Ns=np.divide(self.a*ell*integ,self.c*st**2,out=np.zeros_like(th),where=st>0)
        ks=self.a*self.c/ell**3;kp=self.c/(self.a*ell);Np=(load-ks*Ns)/kp
        return dict(q=self.q,degree=self.degree,kappa=self.kappa,galerkin_residual=self.galerkin_residual,
            strong_residual_rms_relative=float(rel),pressure_square_mean=float(np.sum(p*p*dv)/V),
            pressure_mean=float(np.sum(p*dv)/V),min_interior_u=float(u.min()),
            current_energy_proxy=float(np.sum(np.divide(j*j,psi,out=np.zeros_like(j),where=psi>0)*dv)),
            min_hoop_tension=float(Np.min()),max_tension=float(max(Ns.max(),Np.max())),
            scope='smooth fluid eigenfunction; current/thermal/drift and material constitutive closure remain unsolved')

    def birth_optimum(self):
        """Maxwellian DT birth functional, with n~psi and Ti=Te~psi.

        Returns <p^2 <sigma v>(T)/T_keV^2>. Multiply by the dimensional
        pressure scale squared / (16 keV_in_joule^2) to obtain rate density.
        No transport, radiation, heat balance or ash claim is attached.
        """
        import sys
        from scipy.optimize import minimize_scalar
        sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Integrated'))
        from kinetic_model import reactivity_dt
        R,Z,w=self.quad;u,_,_=self.evaluate(R.ravel(),Z.ravel())
        psi=R.ravel()**2*u;dv=4*np.pi*R.ravel()*w.ravel();p=.5*self.kappa*psi**2
        def negpsi(x):return -float((x[0]**2*self.evaluate(np.array([x[0]]),np.array([0.]))[0])[0])
        op=minimize_scalar(lambda r:negpsi([r]),bounds=(0,self.a),method='bounded')
        maximum=-op.fun
        def score(Tpeak):
            T=Tpeak*psi/maximum
            # Bosch-Hale is not validated down to zero temperature. Do not
            # extrapolate; bound the negligible excluded cold-edge contribution.
            active=T>=.2
            return float(np.sum(p[active]**2*reactivity_dt(T[active])/T[active]**2*dv[active])/(4*np.pi/3))
        opt=minimize_scalar(lambda T:-score(T),bounds=(1,100),method='bounded')
        T=opt.x*psi/maximum;excluded=float(np.sum(p[T<.2]**2*dv[T<.2])/(4*np.pi/3))
        return dict(Tpeak_keV=float(opt.x),birth_functional=float(-opt.fun),
            excluded_cold_pressure_square=excluded,
            temperature_profile='Ti=Te=Tpeak psi/psi_max; physical transport balance not supplied')

def run():
    root=Path(__file__).resolve().parent;rows=[]
    for q in [.5,1.,2.,np.sqrt(13)-1,4.]:
        for d in ([3,5,7] if q==1 else [5]):
            m=RitzOrganization(q,d);r=m.report();rows.append(r);print(r,flush=True)
    (root/'results/edge_regular_ritz.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    assert all(r['galerkin_residual']<1e-8 and r['min_interior_u']>0 for r in rows)

if __name__=='__main__':run()
