"""Same Ritz family, derivative-QR solve to avoid squaring basis conditioning.

No change to the field equation or distribution. Earlier ledgers are preserved.
"""
import numpy as np
from scipy.linalg import solve_triangular
from scipy.interpolate import RectBivariateSpline
from kinetic_constructor import KineticOrganization

class ConditionedOrganization(KineticOrganization):
    def __init__(self,q=3.0168271858,degree=9,power=1.5,spin=.02):
        # Build the inherited basis and quadrature, without its nonlinear
        # normal-equation solve. The first basis function is a positive seed.
        self.q=q;self.degree=degree;self.power=power;self.spin=spin
        self.a=q**(1/6);self.c=q**(-1/3)
        self.pairs=[(i,j) for i in range(degree+1) for j in range(degree+1-i)]
        self.norm=1.;self.coeff=np.zeros(len(self.pairs));self.coeff[0]=1.
        g,w=np.polynomial.legendre.leggauss(max(40,4*degree+12))
        rr,tt=np.meshgrid((g+1)/2,(g+1)*np.pi/4,indexing='ij')
        R=self.a*rr*np.sin(tt);Z=self.c*rr*np.cos(tt)
        weights=np.outer(w/2,w*np.pi/4)*self.a*self.c*rr
        self.quad=(R,Z,weights);r=R.ravel();z=Z.ravel();w=weights.ravel()
        b,br,bz=self.basis(r,z);sqrtw=np.sqrt(w*r**3)
        A=np.concatenate([(br*sqrtw).T,(bz*sqrtw).T],axis=0)
        _,QR=np.linalg.qr(A,mode='reduced')
        whitened=solve_triangular(QR.T,b,lower=True)
        d=QR@self.coeff;d/=max(r*r*(d@whitened))
        for it in range(1000):
            chi=np.maximum(r*r*(d@whitened),0)
            nd=whitened@(w*r**3*chi**power)
            scale=max(r*r*(nd@whitened));nd/=scale
            err=np.linalg.norm(r*r*((nd-d)@whitened))/np.linalg.norm(chi)
            d=.5*(d+nd)
            if err<2e-11:break
        assert err<2e-9
        self.coeff=solve_triangular(QR,d);self.kappa=1/scale
        rr,tt=np.meshgrid(np.linspace(0,1,301),np.linspace(0,np.pi/2,301),indexing='ij')
        _,br,bz=self.evaluate((self.a*rr*np.sin(tt)).ravel(),(self.c*rr*np.cos(tt)).ravel())
        peak=np.sqrt(br*br+(bz-spin)**2).max()
        self.norm=1/peak;self.spin=spin/peak;self.kappa*=peak**(power-1)
        self.iterations=it+1;self.label=f'QR_kinetic_q{q:g}_d{degree}'
        rg=np.linspace(0,1.04*self.a,251);zg=np.linspace(-1.04*self.c,1.04*self.c,321)
        rr,zz=np.meshgrid(rg,zg,indexing='ij');u,_,_=self.evaluate(rr.ravel(),zz.ravel())
        self.spline=RectBivariateSpline(rg,zg,u.reshape(rr.shape),kx=3,ky=3,s=0)
        self.derivative_basis_condition=float(np.linalg.cond(QR))
