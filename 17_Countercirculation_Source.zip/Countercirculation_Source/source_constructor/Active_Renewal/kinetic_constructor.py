"""Invariant-distribution construction, including electron centrifugal stress.

The compact velocity-waterbag F(H-Omega Pphi) is an exact collisionless
Vlasov solution in its specified stationary fields. Ampere/force closure is
quasineutral; finite-Debye Gauss closure is measured, NOT silently assumed.
"""
from pathlib import Path
import sys,json
import numpy as np
from scipy.linalg import solve
from scipy.interpolate import RectBivariateSpline
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Inverse_Synthesis'))
from edge_regular_ritz import RitzOrganization

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'
MD=3670.48;MT=5496.92;MU_BAR=.5/MD+.5/MT

class KineticOrganization(RitzOrganization):
    def __init__(self,q=3.0168271858,degree=7,power=1.5,spin=.02):
        super().__init__(q,degree);self.power=power;self.spin=spin
        R,Z,w=self.quad;r=R.ravel();z=Z.ravel();w=w.ravel()
        b,br,bz=self.basis(r,z);K=(br*(w*r**3))@br.T+(bz*(w*r**3))@bz.T
        self.coeff*=self.norm;self.norm=1.
        self.coeff/=np.max(r*r*(self.coeff@b))
        for iteration in range(1000):
            chi=r*r*(self.coeff@b)
            rhs=b@(w*r**3*np.maximum(chi,0)**power)
            nxt=solve(K,rhs,assume_a='pos');scale=np.max(r*r*(nxt@b));nxt/=scale
            err=np.linalg.norm(r*r*((nxt-self.coeff)@b))/np.linalg.norm(r*r*(nxt@b))
            self.coeff=.5*(nxt+self.coeff)
            if err<2e-11:break
        assert err<2e-9
        self.kappa=1/scale
        # Normalize the actual field, INCLUDING the inertial uniform bias.
        rr,tt=np.meshgrid(np.linspace(0,1,301),np.linspace(0,np.pi/2,301),indexing='ij')
        _,bx,bzz=self.evaluate((self.a*rr*np.sin(tt)).ravel(),(self.c*rr*np.cos(tt)).ravel())
        peak=np.sqrt(bx*bx+(bzz-spin)**2).max()
        self.norm=1/peak;self.spin=spin/peak;self.kappa*=peak**(power-1)
        self.iterations=iteration+1
        self.label=f'kinetic_q{q:g}_d{degree}'
        # Interpolate the scalar potential, then differentiate the SAME spline
        # for E and B, retaining their shared Hamiltonian field definition.
        rg=np.linspace(0,1.04*self.a,251);zg=np.linspace(-1.04*self.c,1.04*self.c,321)
        rr,zz=np.meshgrid(rg,zg,indexing='ij');u,_,_=self.evaluate(rr.ravel(),zz.ravel())
        self.spline=RectBivariateSpline(rg,zg,u.reshape(rr.shape),kx=3,ky=3,s=0)

    def at(self,x):
        R=np.sqrt(x[:,0]**2+x[:,1]**2);z=x[:,2]
        u=self.spline.ev(R,z);ur=self.spline.ev(R,z,dx=1);uz=self.spline.ev(R,z,dy=1)
        chi=R*R*u;cr=2*R*u+R*R*ur;cz=R*R*uz
        B=np.column_stack([-x[:,0]*uz,-x[:,1]*uz,2*u+R*ur-self.spin])
        E=.5*self.spin*np.column_stack([np.divide(cr*x[:,0],R,out=np.zeros_like(R),where=R>0),
            np.divide(cr*x[:,1],R,out=np.zeros_like(R),where=R>0),cz])
        phi=-.5*self.spin*chi;psi=chi-.5*self.spin*R*R
        return chi,phi,psi,E,B

    def sample(self,n=128,mass=1,charge=-1,seed=161026):
        rng=np.random.default_rng(seed);batch=[];count=0
        r=np.linspace(0,self.a,1001);u,_,_=self.evaluate(r,np.zeros_like(r));maxchi=max(r*r*u)*1.0001
        while count<n:
            x=rng.normal(size=(2048,3));x/=np.linalg.norm(x,axis=1)[:,None]
            x*=rng.random((len(x),1))**(1/3);x*=np.array([self.a,self.a,self.c])
            chi=self.at(x)[0];take=x[rng.random(len(x))<(np.maximum(chi,0)/maxchi)**self.power]
            batch.append(take);count+=len(take)
        x=np.concatenate(batch)[:n];chi=self.at(x)[0]
        v=rng.normal(size=(n,3));v/=np.linalg.norm(v,axis=1)[:,None]
        thermal_factor=1. if charge<0 else 1+2/mass
        v*=rng.random((n,1))**(1/3)*np.sqrt(thermal_factor*self.spin*chi/mass)[:,None]
        if charge<0:v+=self.spin*np.column_stack([x[:,1],-x[:,0],np.zeros(n)])
        else:v+=self.spin/mass*np.column_stack([-x[:,1],x[:,0],np.zeros(n)])
        return x,v

    def orbit(self,mass=1,charge=-1,n=128,duration=100,dt=.04):
        x,v=self.sample(n,mass,charge);spin=-self.spin if charge<0 else self.spin/mass
        def invariants(x,v):
            chi,phi,psi,_,_=self.at(x)
            H=mass*np.sum(v*v,axis=1)/2+charge*phi
            P=mass*(x[:,0]*v[:,1]-x[:,1]*v[:,0])+charge*psi
            return H,P,H-spin*P
        H0,P0,K0=invariants(x,v);maxH=maxP=maxK=0.;maxlevel=0.
        count=int(np.ceil(duration/dt));dt=duration/count
        for _ in range(count):
            mid=x+dt*v/2;_,_,_,E,B=self.at(mid)
            vm=v+charge/mass*dt*E/2;t=charge/mass*dt*B/2;s=2*t/(1+np.sum(t*t,axis=1))[:,None]
            vp=vm+np.cross(vm,t);vnew=vm+np.cross(vp,s)+charge/mass*dt*E/2
            x=mid+dt*vnew/2;v=vnew
            H,P,K=invariants(x,v)
            maxH=max(maxH,float(max(abs(H-H0))));maxP=max(maxP,float(max(abs(P-P0))));maxK=max(maxK,float(max(abs(K-K0))))
            maxlevel=max(maxlevel,float(np.max((x[:,0]**2+x[:,1]**2)/self.a**2+x[:,2]**2/self.c**2)))
        return dict(species_mass_over_electron=mass,charge_sign=charge,n=n,duration=duration,dt=dt,
            max_energy_error=maxH,max_canonical_momentum_error=maxP,max_distribution_invariant_error=maxK,
            max_boundary_level=maxlevel,initial_max_distribution_invariant=float(K0.max()),
            scope='finite-orbit stationary-distribution continuation in constructed fields; not collisional or Gauss-complete plasma')

    def diagnostics(self):
        R,Z,w=self.quad;r=R.ravel();z=Z.ravel();w=w.ravel();u,br,bz=self.evaluate(r,z);chi=r*r*u
        p=self.kappa*np.maximum(chi,0)**(self.power+1)/(self.power+1)
        n=self.kappa*np.maximum(chi,0)**self.power/(self.spin*(1+MU_BAR))
        dv=4*np.pi*r*w
        # Differentiate chi from the analytic basis for independent interior test.
        h=1e-4;sel=(r>.02)&(z>.01)&((r/self.a)**2+(z/self.c)**2<.94)
        rr=r[sel];zz=z[sel];uc=u[sel]
        up=self.evaluate(rr+h,zz)[0];um=self.evaluate(rr-h,zz)[0]
        zp=self.evaluate(rr,zz+h)[0];zm=self.evaluate(rr,zz-h)[0]
        Lu=(up-2*uc+um)/h**2+3/rr*(up-um)/(2*h)+(zp-2*uc+zm)/h**2
        rhs=self.kappa*np.maximum(rr*rr*uc,0)**self.power
        residual=np.sqrt(np.mean((Lu+rhs)**2)/np.mean(rhs**2))
        # Gauss defect: rho_required/(e n) = alpha^2 * theta*h*lap chi / n,
        # alpha=Omega_ce L/c. Return coefficient, so no density/size is invented.
        lapchi=-self.kappa*rr*rr*np.maximum(rr*rr*uc,0)**self.power+2*(2*uc+rr*(up-um)/(2*h))
        ni=self.kappa*np.maximum(rr*rr*uc,0)**self.power/(self.spin*(1+MU_BAR))
        defect=.5*self.spin*lapchi/ni
        # Full-volume charge norm, separate from the selected interior
        # pointwise ratio. Use the solved field equation for Delta*chi; its
        # independent strong-form error is reported above.
        lapchi_full=-self.kappa*r*r*np.maximum(chi,0)**self.power+2*bz
        rho_coef=.5*self.spin*lapchi_full
        global_defect=np.sqrt(np.sum(rho_coef*rho_coef*dv)/np.sum(n*n*dv))
        return dict(q=self.q,degree=self.degree,power=self.power,spin=self.spin,kappa=self.kappa,iterations=self.iterations,
            strong_residual_relative=float(residual),mean_pressure=float(np.sum(p*dv)/(4*np.pi/3)),
            mean_rotational_energy=float(np.sum(n*self.spin**2*(1+MU_BAR)*r*r/2*dv)/(4*np.pi/3)),
            net_angular_momentum_coefficient=-1+.5+.5,
            gauss_relative_defect_coefficient_rms=float(np.sqrt(np.mean(defect**2))),
            gauss_charge_L2_over_density_L2_coefficient=float(global_defect),
            gauss_parameter='multiply defect by (Omega_ce L/c)^2; nonuniform near zero-density surfaces',
            old_birth_gain_inherited=False,distribution='constant for H_s-Omega_s Pphi_s<0; zero otherwise',
            pressure_law='p=kappa chi^(5/2)/(5/2); ne=kappa chi^(3/2)/(spin*(1+MU_BAR))',
            field_correction='psi=chi-spin R^2/2; Bz=Bchi_z-spin')

def run():
    rows=[]
    for q,d in [(1.,5),(2.5,5),(3.0168271858,5),(3.0168271858,7),(3.0168271858,9)]:
        m=KineticOrganization(q,d);row=m.diagnostics();rows.append(row);print(row,flush=True)
    (OUT/'kinetic_fields.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    m=KineticOrganization(degree=9);orbits=[]
    for mass,charge in [(1,-1),(MD,1),(MT,1)]:
        for dt in [.04,.02]:
            row=m.orbit(mass,charge,dt=dt);orbits.append(row);print(row,flush=True)
    (OUT/'kinetic_orbits.json').write_text(json.dumps(orbits,indent=2),encoding='utf-8')
    assert rows[-1]['strong_residual_relative']<.03
    assert all(x['max_boundary_level']<1.0001 for x in orbits)

if __name__=='__main__':run()
