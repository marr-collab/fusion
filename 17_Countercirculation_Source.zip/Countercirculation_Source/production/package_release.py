"""Finalize local public attachments; does not upload or publish anything."""
from pathlib import Path
import json,hashlib,shutil,zipfile,re
ROOT=Path(__file__).resolve().parents[1];KIT=ROOT.parent;UP=KIT/'UPLOAD_TO_ZENODO';POST=KIT/'POST_TO_X'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
for name in ['Countercirculation_Vertical_45s.mp4','Countercirculation_Widescreen_45s.mp4','Countercirculation_Poster_Vertical.jpg','Countercirculation_Poster_Widescreen.jpg']:
    shutil.copy2(ROOT/'final'/name,POST/name)
shutil.copy2(ROOT/'X_POST.txt',POST/'X_COUNTERCIRCULATION_POST.txt')
shutil.copy2(ROOT/'VIDEO_DESCRIPTION.txt',POST/'COUNTERCIRCULATION_DESCRIPTION.txt')
shutil.copy2(ROOT/'final/Countercirculation_Widescreen_45s.mp4',UP/'09_Countercirculation_45s.mp4')
shutil.copy2(ROOT/'final/Countercirculation_Technical_Companion.pdf',UP/'16_Countercirculation_Companion.pdf')
shutil.copy2(ROOT/'TECHNICAL_COMPANION.md',ROOT/'final/Countercirculation_Technical_Companion.md')
paths=[]
for folder in ['data','source_constructor','production']:
    for p in (ROOT/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.log','.blend1']:
            paths.append(p)
paths += [ROOT/'README.md',ROOT/'TECHNICAL_COMPANION.md',ROOT/'requirements.txt',ROOT/'X_POST.txt',ROOT/'VIDEO_DESCRIPTION.txt',ROOT/'final/Countercirculation_Technical_Companion.pdf']
manifest=dict(version='1.0.0-cinematic',research_doi='10.5281/zenodo.23523832',doi_status='reserved; supplied by authors',source_files=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(paths)],films=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p),included_in_source_zip=False) for p in sorted((ROOT/'final').glob('*.mp4'))])
(ROOT/'CINEMATIC_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(UP/'17_Countercirculation_Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in paths+[ROOT/'CINEMATIC_MANIFEST.json']:z.write(p,'Countercirculation_Source/'+p.relative_to(ROOT).as_posix())
doi='https://doi.org/10.5281/zenodo.23523832'
for p in [POST/'X_LAUNCH_POST.txt',POST/'X_FOLLOWUP_THREAD.txt']:
    if p.exists():p.write_text(p.read_text(encoding='utf-8').replace('[ZENODO_URL]',doi),encoding='utf-8')
(KIT/'RELEASE_TEXT/PUBLIC_DOI.txt').write_text(doi+'\nStatus: reserved DOI supplied by the authors. Publish the Zenodo record before promoting the public link.\n')
meta=KIT/'RELEASE_TEXT/ZENODO_METADATA.json'
j=json.loads(meta.read_text(encoding='utf-8'));j['reserved_doi']='10.5281/zenodo.23523832';meta.write_text(json.dumps(j,indent=2),encoding='utf-8')
guide=KIT/'PUBLICATION_GUIDE.md';g=guide.read_text(encoding='utf-8')
g='''> **Cinematic release update, 20 October 2026.** Lead on X with `POST_TO_X/Countercirculation_Vertical_45s.mp4` and `X_COUNTERCIRCULATION_POST.txt`. The landscape film is `Countercirculation_Widescreen_45s.mp4`. The reserved DOI is **10.5281/zenodo.23523832**. Use that existing record; do not reserve a second DOI. The original phase video remains an optional technical follow-up.\n\n'''+g
g=g.replace('all 15 attachments','all 18 attachments').replace('There are 15 attachments total.','There are 18 attachments total, including the cinematic movie (09), its companion (16), and its reproducible source package (17).')
g=g.replace('Choose **Get a DOI now / Reserve DOI** for this new record.','Your existing reserved DOI is **10.5281/zenodo.23523832**; continue with that draft record.')
g=g.replace('Attach **`POST_TO_X/Phase_Preservation_56s.mp4`** to the launch post. Copy **`X_LAUNCH_POST.txt`**, replacing `[ZENODO_URL]` with `https://doi.org/` followed by your new DOI.','Attach **`POST_TO_X/Countercirculation_Vertical_45s.mp4`** to the launch post. Copy **`X_COUNTERCIRCULATION_POST.txt`**, which already contains your reserved DOI link. The landscape version is available alongside it. Use the original phase-preservation post as an optional later technical demonstration.')
g += '\n## Cinematic movie and receipt\n\nAttachment 09 is the 45-second landscape countercirculation film; 16 is its three-page technical companion; 17 is the source/data/Blender reconstruction package. The portrait film is ready in POST_TO_X. Both formats are 24 fps native HD, H.264/yuv420p with AAC audio. Original synthesized ambient sound is included; no voiceover is required. The historical Reading and Full Research ZIPs are unchanged. Rendering, time scaling and exact rate ratios are documented in the companion. No external publication has been performed.\n'
guide.write_text(g,encoding='utf-8')
(KIT/'START_HERE.txt').write_text('''ADDRESS-FIRST FUSION - PUBLIC RELEASE KIT\n\nNEW CINEMATIC FILM\n1. Watch POST_TO_X/Countercirculation_Vertical_45s.mp4 (X/mobile).\n2. Landscape: POST_TO_X/Countercirculation_Widescreen_45s.mp4.\n3. Read UPLOAD_TO_ZENODO/16_Countercirculation_Companion.pdf for the equations and exact visual conventions.\n4. Use POST_TO_X/X_COUNTERCIRCULATION_POST.txt with the film.\n\nZENODO\nContinue your existing draft with reserved DOI 10.5281/zenodo.23523832.\nUpload the 18 files in UPLOAD_TO_ZENODO. The flagship is 01; the new movie is 09; its companion and source are 16 and 17.\nPUBLICATION_GUIDE.md gives the full operating instructions.\nPublish the record before promoting https://doi.org/10.5281/zenodo.23523832.\n\nThe original phase-preservation video remains available as a technical follow-up. The historical Reading and Full Research ZIPs are unchanged. No upload, publication or social post has been made.\n''',encoding='utf-8')
readfirst=UP/'00_READ_FIRST.txt';old=readfirst.read_text(encoding='utf-8');readfirst.write_text('CINEMATIC ENTRANCE: 09_Countercirculation_45s.mp4\nIts exact equations and rendering disclosures: 16_Countercirculation_Companion.pdf\nReproduce the geometry, fields and movie: 17_Countercirculation_Source.zip\nResearch DOI: '+doi+'\n\n'+old,encoding='utf-8')
desc=KIT/'RELEASE_TEXT/ZENODO_DESCRIPTION.txt';d=desc.read_text(encoding='utf-8');d+='\n\nCINEMATIC SCIENTIFIC VISUALIZATION\nAttachment 09 renders the actual oblate countercirculating waterbag: opposing species motion carries current while summed mechanical angular momentum cancels in the selected construction. The 45-second movie uses regenerated numerical fields, true relative circulation rates and disclosed shared time scaling. Attachment 16 gives the mathematical receipt; attachment 17 contains the rendering sources and data.\n';desc.write_text(d,encoding='utf-8')
html=KIT/'RELEASE_TEXT/ZENODO_DESCRIPTION.html';html.write_text(html.read_text(encoding='utf-8')+'\n<h2>Cinematic scientific visualization</h2><p>Attachment 09 renders the actual oblate countercirculating waterbag. Opposing species motion carries current while summed mechanical angular momentum cancels in the selected construction. The 45-second movie uses regenerated numerical fields, true relative circulation rates and disclosed shared time scaling. Attachment 16 gives the mathematical receipt; attachment 17 contains the rendering sources and data.</p>\n',encoding='utf-8')
prev=json.loads((UP/'13_RELEASE_CONTENTS.json').read_text(encoding='utf-8'));roles={x['filename']:x['role'] for x in prev['files']};roles.update({'09_Countercirculation_45s.mp4':'Cinematic numerical countercirculation film, landscape','16_Countercirculation_Companion.pdf':'Exact equations, numerical parameters and rendering disclosures','17_Countercirculation_Source.zip':'Reproducible numerical geometry, field and cinematic source package'})
entries=[]
for p in sorted(UP.iterdir()):
    if p.is_file() and p.name not in ['13_RELEASE_CONTENTS.json','14_SHA256SUMS.txt']:
        entries.append(dict(filename=p.name,role=roles.get(p.name,'Release attachment'),bytes=p.stat().st_size,sha256=sha(p)))
prev['files']=entries;prev['reserved_doi']='10.5281/zenodo.23523832';prev['production_revision']='cinematic visualization, 2026-10-20'
(UP/'13_RELEASE_CONTENTS.json').write_text(json.dumps(prev,indent=2),encoding='utf-8')
checks=[(e['sha256'],e['filename']) for e in entries]+[(sha(UP/'13_RELEASE_CONTENTS.json'),'13_RELEASE_CONTENTS.json')]
(UP/'14_SHA256SUMS.txt').write_text(''.join(h+'  '+name+'\n' for h,name in sorted(checks,key=lambda x:x[1])),encoding='utf-8')
post=(ROOT/'X_POST.txt').read_text(encoding='utf-8').strip();count=len(re.sub(r'https://\S+','x'*23,post));assert count<=280,count
print(json.dumps(dict(attachments=len(list(UP.iterdir())),X_post_weighted_characters=count,source_zip_bytes=(UP/'17_Countercirculation_Source.zip').stat().st_size),indent=2))
