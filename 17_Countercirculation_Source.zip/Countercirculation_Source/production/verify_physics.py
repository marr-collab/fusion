from pathlib import Path
import sys,json,numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'source_constructor/Burn_Renewal'),str(ROOT/'source_constructor/Active_Renewal')]
from conditioned_fields import ConditionedOrganization
r=json.loads((ROOT/'data/visualization_receipt.json').read_text());s=r['source'];m=ConditionedOrganization(s['q'],9,spin=s['spin_input'])
lines=json.loads((ROOT/'data/field_lines.json').read_text());maxlev=0;fluxerr=0;tangent=[]
for line in lines:
    x=np.array(line['xyz']);R=np.linalg.norm(x[:,:2],axis=1);u,br,bz=m.evaluate(R,x[:,2]);chi=R**2*u;psi=chi-.5*m.spin*R**2
    maxlev=max(maxlev,float(np.max((R/m.a)**2+(x[:,2]/m.c)**2)))
    fluxerr=max(fluxerr,float(np.ptp(psi)/s['chi_max']))
    dl=x[2:]-x[:-2];B=np.c_[br[1:-1]*x[1:-1,0]/R[1:-1],br[1:-1]*x[1:-1,1]/R[1:-1],bz[1:-1]-m.spin]
    sine=np.linalg.norm(np.cross(dl,B),axis=1)/(np.linalg.norm(dl,axis=1)*np.linalg.norm(B,axis=1))
    tangent.extend(sine.tolist())
w=r['omega_rad_s'];ratioD=abs(w['electron'])/w['deuterium'];ratioT=abs(w['electron'])/w['tritium']
out=dict(max_fieldline_domain_level=maxlev,max_flux_range_over_chi_peak=fluxerr,fieldline_tangent_sine_rms=float(np.sqrt(np.mean(np.array(tangent)**2))),electron_to_D_rate=ratioD,electron_to_T_rate=ratioT,mechanical_L_sum=r['angular_momentum_kg_m2_s']['total'],archived_strong_field_residual=s['strong_field_residual'],historical_profile_checks=r['verification'])
assert maxlev<=1+1e-8
assert fluxerr<.001
assert out['fieldline_tangent_sine_rms']<.005
assert abs(ratioD-3670.48)<1e-9 and abs(ratioT-5496.92)<1e-9
assert out['mechanical_L_sum']==0
(ROOT/'data/visualization_validation.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
