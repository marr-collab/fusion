"""21 October 2026: caption-only revision; refresh public copies and integrity records."""
from pathlib import Path
import json,hashlib,shutil,zipfile
ROOT=Path(__file__).resolve().parents[1];KIT=ROOT.parent;UP=KIT/'UPLOAD_TO_ZENODO';POST=KIT/'POST_TO_X'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
prior=json.loads((ROOT/'revisions/2026-10-20/CINEMATIC_MANIFEST.json').read_text())
prior_hash={x['path']:x['sha256'] for x in prior['source_files']}
retained=['production/scene.py','data/field_grid.npz','data/field_lines.json','data/tracers.npy','data/original_ambient.wav','data/visualization_receipt.json','final/Countercirculation_Technical_Companion.pdf']
for name in retained:assert sha(ROOT/name)==prior_hash[name],f'Unexpected physical/animation change: {name}'
for name in ['Countercirculation_Vertical_45s.mp4','Countercirculation_Widescreen_45s.mp4','Countercirculation_Poster_Vertical.jpg','Countercirculation_Poster_Widescreen.jpg']:
    shutil.copy2(ROOT/'final'/name,POST/name)
shutil.copy2(ROOT/'final/Countercirculation_Widescreen_45s.mp4',UP/'09_Countercirculation_45s.mp4')
description=ROOT/'VIDEO_DESCRIPTION.txt'
intro='The opening announces: “WE CONSTRUCTED A PLASMA THAT CARRIES CURRENT WITHOUT NET MECHANICAL SPIN.” It then explains the countercirculation, cancellation of mechanical angular momenta and remaining electromagnetic current as an executable result of the Address-First Fusion POG. '
old=description.read_text(encoding='utf-8')
if not old.startswith(intro):description.write_text(intro+old,encoding='utf-8')
shutil.copy2(description,POST/'COUNTERCIRCULATION_DESCRIPTION.txt')
transcript=[(0,6,'WE CONSTRUCTED A PLASMA THAT CARRIES CURRENT WITHOUT NET MECHANICAL SPIN.'),(6,13,'Electrons and fuel ions countercirculate.'),(13,21,'Their mechanical angular momenta cancel.'),(21,29,'The electromagnetic current remains.'),(29,37,'This is one of the executable results of the Address-First Fusion POG.'),(37,45,'ADDRESS-FIRST FUSION POG. Mathematical construction. Executable receipts. Full research archive: doi.org/10.5281/zenodo.23523832')]
(ROOT/'data/caption_transcript.json').write_text(json.dumps([dict(start_s=a,end_s=b,text=t) for a,b,t in transcript],indent=2),encoding='utf-8')
revision=dict(date='2026-10-21',kind='Declarative achievement captions',version='1.0.1-cinematic',physical_animation_unchanged=True,unchanged_artifacts={p:sha(ROOT/p) for p in retained},prior_versions='revisions/2026-10-20; local only, excluded from public source ZIP')
(ROOT/'data/caption_revision.json').write_text(json.dumps(revision,indent=2))
readme=ROOT/'README.md';txt=readme.read_text(encoding='utf-8');note='\n## Caption revision - 21 October 2026\n\nThe opening now announces the completed construction, followed by the authors’ declarative explanation. The 3D animation, geometry, numerical inputs, circulation ratios, soundtrack and technical companion are unchanged. Both video formats, posters and public copies have been refreshed.\n'
if '## Caption revision - 21 October 2026' not in txt:readme.write_text(txt+note,encoding='utf-8')
paths=[]
for folder in ['data','source_constructor','production']:
    for p in (ROOT/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.log','.blend1']:paths.append(p)
paths += [ROOT/'README.md',ROOT/'TECHNICAL_COMPANION.md',ROOT/'requirements.txt',ROOT/'X_POST.txt',description,ROOT/'final/Countercirculation_Technical_Companion.pdf']
manifest=dict(version='1.0.1-cinematic',research_doi='10.5281/zenodo.23523832',doi_status='reserved; supplied by authors',revision=revision,source_files=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(paths)],films=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p),included_in_source_zip=False) for p in sorted((ROOT/'final').glob('*.mp4'))])
(ROOT/'CINEMATIC_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(UP/'17_Countercirculation_Source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in paths+[ROOT/'CINEMATIC_MANIFEST.json']:z.write(p,'Countercirculation_Source/'+p.relative_to(ROOT).as_posix())
release=json.loads((UP/'13_RELEASE_CONTENTS.json').read_text(encoding='utf-8'))
for entry in release['files']:
    p=UP/entry['filename']
    if p.name in ['09_Countercirculation_45s.mp4','17_Countercirculation_Source.zip']:
        entry.update(bytes=p.stat().st_size,sha256=sha(p))
release['production_revision']='Declarative cinematic captions, 2026-10-21; cinematic v1.0.1; numerical research unchanged'
(UP/'13_RELEASE_CONTENTS.json').write_text(json.dumps(release,indent=2),encoding='utf-8')
checks=[(e['sha256'],e['filename']) for e in release['files']]+[(sha(UP/'13_RELEASE_CONTENTS.json'),'13_RELEASE_CONTENTS.json')]
(UP/'14_SHA256SUMS.txt').write_text(''.join(h+'  '+name+'\n' for h,name in sorted(checks,key=lambda x:x[1])),encoding='utf-8')
with zipfile.ZipFile(UP/'17_Countercirculation_Source.zip') as z:assert z.testzip() is None
print(json.dumps(revision,indent=2))
