"""Cinematic typography, original ambient sound design, and two native HD crops."""
from pathlib import Path
import sys,subprocess,wave,json,time
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageEnhance
import imageio_ffmpeg
ROOT=Path(__file__).resolve().parents[1];FPS=24;N=1080
FONT='C:/Windows/Fonts/seguisb.ttf';REG='C:/Windows/Fonts/segoeui.ttf'
OUT=ROOT/'final';OUT.mkdir(exist_ok=True)
def font(size,bold=True):return ImageFont.truetype(FONT if bold else REG,size)
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def stage(t):
    if t<6:return 0,0,6
    if t<13:return 1,6,13
    if t<21:return 2,13,21
    if t<29:return 3,21,29
    if t<37:return 4,29,37
    return 5,37,45
def compose(im,t,portrait):
    W,H=(1080,1920) if portrait else (1920,1080)
    # Exact crops of a native 1920px square, never distorted or upscaled.
    im=im.convert('RGB');sz=im.width
    if sz!=1920:im=im.resize((1920,1920),Image.Resampling.LANCZOS)
    im=im.crop(((1920-W)//2,(1920-H)//2,(1920+W)//2,(1920+H)//2))
    k,start,end=stage(t);alpha=smooth((t-start)/.4)*smooth((end-t)/.4)
    if k==0:alpha=smooth((end-t)/.4) # first frame already communicates
    layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer)
    def txt(text,y,size=48,color=(235,244,251),op=1,bold=True,spacing=12):
        f=font(size,bold);lines=text.split('\n')
        for j,line in enumerate(lines):
            box=d.textbbox((0,0),line,font=f);x=(W-(box[2]-box[0]))/2
            yy=y+j*(size+spacing)
            d.text((x+1,yy+2),line,font=f,fill=(0,0,0,int(140*op)))
            d.text((x,yy),line,font=f,fill=(*color,int(255*op)))
    def legend(y):
        labels=[('ELECTRONS',(66,198,255)),('DEUTERIUM',(255,177,86)),('TRITIUM',(255,103,148))]
        size=23 if portrait else 24;f=font(size);widths=[d.textlength(s,font=f)+44 for s,c in labels];x=(W-sum(widths)-36)/2
        for (s,col),ww in zip(labels,widths):
            d.ellipse((x,y+10,x+10,y+20),fill=(*col,220));d.text((x+20,y),s,font=f,fill=(*col,240));x+=ww+18
    top=180 if portrait else 52;bottom=1460 if portrait else 852
    if k==0:
        txt('WE CONSTRUCTED A PLASMA',top,44 if portrait else 48,op=alpha)
        txt('THAT CARRIES CURRENT',top+64,56,op=alpha)
        txt('WITHOUT NET MECHANICAL SPIN.',top+140,46 if portrait else 48,op=alpha)
    elif k==1:
        txt('Electrons and fuel ions',top,50,(89,210,255),alpha)
        txt('countercirculate.',top+78,58,op=alpha)
    elif k==2:
        txt('Their mechanical angular',top,48,(255,180,100),alpha)
        txt('momenta cancel.',top+78,58,op=alpha)
    elif k==3:
        txt('The electromagnetic',top,52,op=alpha)
        txt('current remains.',top+82,58,op=alpha)
        txt('Calculated magnetic organization',bottom-24,30,(183,173,238),alpha,bold=False)
    elif k==4:
        txt('This is one of the executable results',top,37 if portrait else 42,op=alpha)
        txt('of the Address-First Fusion POG.',top+68,39 if portrait else 44,op=alpha)
        txt('NET MECHANICAL SPIN CANCELS.',bottom-24,30,op=alpha)
    else:
        # Keep the actual moving plasma behind the close, rather than a title slide.
        im=ImageEnhance.Brightness(im).enhance(.65)
        txt('ADDRESS-FIRST',top,61,op=alpha)
        txt('FUSION POG',top+80,76,op=alpha)
        txt('Mathematical construction.',bottom-35,34,op=alpha)
        txt('Executable receipts.',bottom+14,34,op=alpha)
        txt('FULL RESEARCH ARCHIVE',bottom+104 if portrait else bottom+78,24,(143,175,198),alpha)
        txt('doi.org/10.5281/zenodo.23523832',bottom+147 if portrait else bottom+117,32,(219,237,250),alpha,bold=False)
    if k<5:
        legend(1550 if portrait else 938)
        note='Shared clock: 40 µs / film second' if t<13 else 'Shared clock: 75 ms / film second'
        txt(note,1630 if portrait else 990,24,(154,178,197),bold=False)
        if t>=13:txt('Fast electron circulation is exposure-averaged.',1666 if portrait else 1022,23,(154,178,197),bold=False)
    txt('NUMERICAL VISUALIZATION  •  MEAN-FLOW TRACERS',1748 if portrait else 24,21,(138,164,184),bold=False)
    if portrait:txt('Selected stationary waterbag construction',1784,23,(138,164,184),bold=False)
    im=Image.alpha_composite(im.convert('RGBA'),layer).convert('RGB')
    if t>44:im=ImageEnhance.Brightness(im).enhance(float(smooth((45-t))))
    return im

def audio():
    sr=48000;t=np.arange(45*sr)/sr;waveform=np.zeros_like(t)
    # Original synthesized ambient texture, not plasma sonification.
    for f,amp,ph in [(55,.12,0),(82.4069,.055,.4),(110,.035,1),(164.814,.022,2),(220,.013,.9)]:
        waveform+=amp*np.sin(2*np.pi*f*t+ph+.045*np.sin(2*np.pi*.07*t))
    for center,f in [(0,440),(13,330),(21,493.88),(29,392),(37,523.25)]:
        env=np.exp(-np.maximum(t-center,0)/2.8)*(t>=center)*(1-np.exp(-np.maximum(t-center,0)*9))
        waveform+=.045*env*np.sin(2*np.pi*f*t)
    env=smooth(t/2)*smooth((45-t)/3)*(.8+.1*np.sin(.7*t))
    left=waveform*env;right=.98*waveform*env+.005*env*np.sin(2*np.pi*110.13*t)
    pcm=np.int16(np.stack([left,right],1)*32767)
    with wave.open(str(ROOT/'data/original_ambient.wav'),'wb') as w:
        w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(pcm.tobytes())

if '--preview' in sys.argv:
    for t in [0,7,17,28,36,40]:
        p=ROOT/'renders/master'/f'{t*FPS:05d}.png'
        if not p.exists():p=ROOT/'renders'/f'preview_{min([0,7,17,28,36],key=lambda v:abs(t-v)):02d}.png'
        for portrait in [True,False]:
            compose(Image.open(p),float(t),portrait).save(ROOT/'renders'/f"layout_{'vertical' if portrait else 'wide'}_{t:02d}.jpg",quality=94)
else:
    audio();ff=imageio_ffmpeg.get_ffmpeg_exe();process=[]
    for portrait in [True,False]:
        W,H=(1080,1920) if portrait else (1920,1080);name='Countercirculation_Vertical_45s.mp4' if portrait else 'Countercirculation_Widescreen_45s.mp4'
        log=open(ROOT/'production'/('encode_vertical.log' if portrait else 'encode_wide.log'),'w')
        args=[ff,'-y','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',str(ROOT/'data/original_ambient.wav'),'-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-movflags','+faststart','-t','45',str(OUT/name)]
        process.append((portrait,subprocess.Popen(args,stdin=subprocess.PIPE,stdout=log,stderr=log),log))
    for i in range(N):
        framepath=ROOT/'renders/master'/f'{i:05d}.png'
        # Permit encoding to follow a still-running render without reading a partial PNG.
        while True:
            try:
                if i<N-1 and not (ROOT/'renders/master'/f'{i+1:05d}.png').exists():
                    time.sleep(.5);continue
                if i==N-1 and (not framepath.exists() or time.time()-framepath.stat().st_mtime<1):
                    time.sleep(.5);continue
                im=Image.open(framepath);im.load();break
            except (FileNotFoundError,OSError,SyntaxError):time.sleep(.5)
        for portrait,p,log in process:p.stdin.write(compose(im,i/FPS,portrait).tobytes())
        if i%120==0:print('Encoded',i,'/',N,flush=True)
    for portrait,p,log in process:
        p.stdin.close();assert p.wait()==0;log.close()
    for portrait in [True,False]:
        im=compose(Image.open(ROOT/'renders/master/00048.png'),2,portrait)
        im.save(OUT/('Countercirculation_Poster_Vertical.jpg' if portrait else 'Countercirculation_Poster_Widescreen.jpg'),quality=96)
