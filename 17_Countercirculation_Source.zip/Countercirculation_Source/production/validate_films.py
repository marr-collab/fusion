from pathlib import Path
import json,subprocess,hashlib
import imageio_ffmpeg
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1];qa=ROOT/'renders/encoded_checks';qa.mkdir(exist_ok=True)
ff=imageio_ffmpeg.get_ffmpeg_exe();rows=[]
for orientation,size in [('Vertical',(1080,1920)),('Widescreen',(1920,1080))]:
    p=ROOT/'final'/f'Countercirculation_{orientation}_45s.mp4'
    reader=imageio_ffmpeg.read_frames(str(p));meta=next(reader);reader.close()
    n,duration=imageio_ffmpeg.count_frames_and_secs(str(p))
    assert n==1080,(p,n);assert abs(duration-45)<.05,(p,duration)
    assert tuple(meta['size'])==size,meta;assert meta['fps']==24,meta
    result=subprocess.run([ff,'-v','error','-i',str(p),'-f','null','-'],capture_output=True,text=True)
    assert result.returncode==0 and not result.stderr,result.stderr
    screenshots=[]
    for t in [0,7,13.5,22,32,40]:
        out=qa/f'{orientation}_{t:g}.png'
        subprocess.run([ff,'-y','-v','error','-ss',str(t),'-i',str(p),'-frames:v','1',str(out)],check=True)
        screenshots.append(out.name)
    rows.append(dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),frames=n,duration_s=duration,size=size,fps=meta['fps'],codec=meta['codec'],decode_errors=result.stderr,check_frames=screenshots))
    cell=(270,480) if orientation=='Vertical' else (480,270)
    sheet=Image.new('RGB',(cell[0]*3,cell[1]*2),(8,12,18))
    for i,name in enumerate(screenshots):
        im=Image.open(qa/name);im.thumbnail(cell,Image.Resampling.LANCZOS);sheet.paste(im,((i%3)*cell[0],(i//3)*cell[1]))
    sheet.save(qa/f'{orientation}_contact.jpg',quality=94)
(ROOT/'data/video_validation.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
