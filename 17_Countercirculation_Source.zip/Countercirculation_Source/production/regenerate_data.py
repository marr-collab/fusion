"""Regenerate the archived degree-nine magnetic organization; never fit a visual field."""
from pathlib import Path
import sys,json,hashlib,shutil
import numpy as np
from scipy.constants import e,m_e,mu_0
from PIL import Image
import contourpy

ROOT=Path(__file__).resolve().parents[1]
ARCH=Path(r'D:/Grammar 1/Fusion_POG/Capstone/archive/Fusion_POG')
LOCAL=ROOT/'source_constructor'
for folder,name in [('Active_Renewal','kinetic_constructor.py'),('Inverse_Synthesis','edge_regular_ritz.py'),('Burn_Renewal','conditioned_fields.py')]:
    dest=LOCAL/folder/name;dest.parent.mkdir(parents=True,exist_ok=True)
    if (ARCH/folder/name).exists():shutil.copy2(ARCH/folder/name,dest)
    assert dest.exists(),f'Missing preserved constructor: {dest}'
for name in ['dimensional_results.json','profile_q3.016827_d9_L1.npz']:
    if (ARCH/'Burn_Renewal/results'/name).exists():shutil.copy2(ARCH/'Burn_Renewal/results'/name,ROOT/'data'/name)
    assert (ROOT/'data'/name).exists()
sys.path[:0]=[str(LOCAL/'Burn_Renewal'),str(LOCAL/'Active_Renewal')]
from conditioned_fields import ConditionedOrganization
from kinetic_constructor import MD,MT,MU_BAR
rows=json.loads((ROOT/'data/dimensional_results.json').read_text())['members']
row=next(x for x in rows if x['q']>3 and x['degree']==9)
m=ConditionedOrganization(row['q'],9,spin=row['spin_input'])
p=np.load(ROOT/'data/profile_q3.016827_d9_L1.npz')
u,_,_=m.evaluate(p['R'],p['Z']);chi=p['R']**2*u
n=m_e/(mu_0*e*e)*m.kappa*np.maximum(chi,0)**1.5/(m.spin*(1+MU_BAR))
verification=dict(chi_relative_L2=float(np.linalg.norm(chi-p['chi'])/np.linalg.norm(p['chi'])),density_relative_L2=float(np.linalg.norm(n-p['density'])/np.linalg.norm(p['density'])))
assert max(verification.values())<1e-9,verification
a,c=m.a,m.c;nr,nz=641,641
r=np.linspace(0,a,nr);z=np.linspace(-c,c,nz);rr,zz=np.meshgrid(r,z)
u,br,bz=m.evaluate(rr.ravel(),zz.ravel());u=u.reshape(rr.shape);br=br.reshape(rr.shape);bz=bz.reshape(rr.shape)-m.spin
inside=(rr/a)**2+(zz/c)**2<=1
chi=rr**2*u;psi=chi-.5*m.spin*rr**2
rho=np.where(inside,np.maximum(chi,0)**1.5,0);rho/=rho.max()
np.savez_compressed(ROOT/'data/field_grid.npz',R_m=r,Z_m=z,chi=chi,psi=psi,B_R_T=br*5,B_Z_T=bz*5,density_relative=rho,inside=inside,coeff=m.coeff,norm=m.norm)
# Image rows are top-to-bottom; UV v is bottom-to-top.
Image.fromarray(np.uint16(np.flipud(rho)*65535)).save(ROOT/'data/density_RZ.png')
cg=contourpy.contour_generator(x=r,y=z,z=np.ma.masked_where(~inside,psi))
lines=[]
for frac in [.075,.18,.34,.52,.71,.87,.96]:
    for curve in cg.lines(float(np.max(psi)*frac)):
        if len(curve)>30:
            # Uniform arclength resampling of calculated flux contour.
            ss=np.r_[0,np.cumsum(np.linalg.norm(np.diff(curve,axis=0),axis=1))]
            s=np.linspace(0,ss[-1],240);curve=np.column_stack([np.interp(s,ss,curve[:,j]) for j in [0,1]])
            for phi in np.linspace(0,2*np.pi,8,endpoint=False):
                lines.append(dict(level=frac,xyz=np.column_stack([curve[:,0]*np.cos(phi),curve[:,0]*np.sin(phi),curve[:,1]]).tolist()))
(ROOT/'data/field_lines.json').write_text(json.dumps(lines))
# A fixed, reproducible spatial sample from the actual n ~ chi^(3/2) measure.
rng=np.random.default_rng(23523832);samples=[]
while len(samples)<270:
    xyz=rng.uniform([-a,-a,-c],[a,a,c],(1000,3));R=np.linalg.norm(xyz[:,:2],axis=1)
    mask=(R/a)**2+(xyz[:,2]/c)**2<.96
    xyz=xyz[mask];R=R[mask];v=m.at(xyz)[0]
    keep=rng.random(len(xyz))<(np.maximum(v,0)/row['chi_max'])**1.5
    samples.extend(xyz[keep].tolist())
np.save(ROOT/'data/tracers.npy',np.array(samples[:270]))
omega=row['rotation_rad_s'];dV=p['dV'];R=p['R'];ne=p['density']
L_e=float(np.dot(-m_e*ne*omega*R**2,dV));L_D=float(np.dot(.5*m_e*ne*omega*R**2,dV));L_T=L_D
I_e=float(np.dot(e*ne*omega*R,dV));I_D=I_e/(2*MD);I_T=I_e/(2*MT)
meta=dict(source=row,verification=verification,omega_rad_s=dict(electron=-omega,deuterium=omega/MD,tritium=omega/MT),angular_momentum_kg_m2_s=dict(electron=L_e,deuterium=L_D,tritium=L_T,total=L_e+L_D+L_T),volume_integral_Jphi_A_m=dict(electron=I_e,deuterium=I_D,tritium=I_T,total=I_e+I_D+I_T),bias_T=-5*m.spin,geometry='R^2/a^2 + z^2/c^2 <= 1; q=(a/c)^2; a=q^(1/6) L; c=q^(-1/3) L',field_lines='Contours of psi=chi-h R^2/2 revolved at fixed azimuth. Interior field only.',rendering='Mean-flow tracers, not full thermal particle trajectories. Luminosity artistic; spatial emissivity follows normalized electron density.',source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in LOCAL.rglob('*.py')})
(ROOT/'data/visualization_receipt.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(meta,indent=2))
