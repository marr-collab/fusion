from pathlib import Path
import sys,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1]
blender=shutil.which('blender') or 'C:/Program Files/Blender Foundation/Blender 4.3/blender.exe'
if not Path(blender).exists():raise SystemExit('Install Blender 4.3 or place blender on PATH.')
for name in ['regenerate_data.py','verify_physics.py']:
    subprocess.run([sys.executable,str(ROOT/'production'/name)],check=True,cwd=ROOT)
subprocess.run([blender,'-b','--python',str(ROOT/'production/scene.py'),'--','--render'],check=True,cwd=ROOT)
for name in ['finish_film.py','companion_pdf.py']:
    subprocess.run([sys.executable,str(ROOT/'production'/name)],check=True,cwd=ROOT)
