"""Blender 4.3: numerical interior field + density + exact rigid mean circulation.
Run with blender -b --python scene.py -- --preview or --render.
One square cinematic master feeds two independently typeset social formats.
"""
import bpy,math,json,sys,time
from pathlib import Path
import numpy as np
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
M=json.loads((ROOT/'data/visualization_receipt.json').read_text());a=M['source']['a_m'];c=M['source']['c_m']
FPS=24;DURATION=45;SIZE=1920
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.render.engine='CYCLES' if '--cycles' in sys.argv else 'BLENDER_EEVEE_NEXT'
scene.render.resolution_x=SIZE;scene.render.resolution_y=SIZE;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.fps=FPS
scene.render.film_transparent=False
scene.world.color=(.001,.001,.001)
scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.0015,.003,.009,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.15
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.3
scene.eevee.taa_render_samples=32
scene.eevee.volumetric_samples=48
scene.eevee.volumetric_tile_size='8'
scene.render.image_settings.color_depth='8'
def emission(name,col,strength):
    m=bpy.data.materials.new(name);m.use_nodes=True;nodes=m.node_tree.nodes;nodes.clear()
    out=nodes.new('ShaderNodeOutputMaterial');s=nodes.new('ShaderNodeEmission');s.inputs[0].default_value=(*col,1);s.inputs[1].default_value=strength
    m.node_tree.links.new(s.outputs[0],out.inputs['Surface']);return m,s
cyan,ce=emission('Electron • negative charge',(.015,.53,1),5)
gold,de=emission('Deuterium • positive charge',(1,.35,.035),4)
rose,te=emission('Tritium • positive charge',(1,.055,.25),4)
fieldmat,fe=emission('Calculated B • silver lavender',(.5,.38,1),.8)
boundmat,be=emission('Domain outline',(.035,.13,.22),.8)
def curve(name,xyz,mat,radius=.001,cyclic=False):
    cu=bpy.data.curves.new(name,'CURVE');cu.dimensions='3D';cu.resolution_u=1;cu.bevel_depth=radius;cu.bevel_resolution=2
    sp=cu.splines.new('POLY');sp.points.add(len(xyz)-1);sp.points.foreach_set('co',np.c_[xyz,np.ones(len(xyz))].ravel());sp.use_cyclic_u=cyclic
    ob=bpy.data.objects.new(name,cu);bpy.context.collection.objects.link(ob);cu.materials.append(mat);return ob,sp
field=[]
for j,line in enumerate(json.loads((ROOT/'data/field_lines.json').read_text())):
    if j%2:continue
    ob,sp=curve('B integral curve %02d'%j,np.array(line['xyz']),fieldmat,.00115)
    field.append(ob)
# A faint spatial boundary, not a vessel or invented coil.
tt=np.linspace(0,2*np.pi,240)
for ph in [0,np.pi/2]:
    curve('Admitted oblate boundary',np.c_[a*np.cos(tt)*np.cos(ph),a*np.cos(tt)*np.sin(ph),c*np.sin(tt)],boundmat,.0007)
curve('Equatorial domain',np.c_[a*np.cos(tt),a*np.sin(tt),tt*0],boundmat,.0007)
# Volumetric emissivity is the regenerated density lookup in cylindrical R,z.
bpy.ops.mesh.primitive_uv_sphere_add(segments=96,ring_count=48,radius=1)
volume=bpy.context.object;volume.name='Waterbag density volume';volume.scale=(a,a,c)
vm=bpy.data.materials.new('n_e proportional chi^(3/2) • volume');vm.use_nodes=True
ns=vm.node_tree.nodes;ns.clear();lk=vm.node_tree.links
out=ns.new('ShaderNodeOutputMaterial');pv=ns.new('ShaderNodeVolumePrincipled');lk.new(pv.outputs['Volume'],out.inputs['Volume'])
pv.inputs['Color'].default_value=(.03,.16,.35,1);pv.inputs['Anisotropy'].default_value=.1;pv.inputs['Emission Color'].default_value=(.03,.23,.50,1)
tex=ns.new('ShaderNodeTexCoord');sep=ns.new('ShaderNodeSeparateXYZ');lk.new(tex.outputs['Generated'],sep.inputs[0])
def mathnode(op,aa,bb=None):
    n=ns.new('ShaderNodeMath');n.operation=op
    for k,v in enumerate([aa,bb]):
        if v is None:continue
        if isinstance(v,(int,float)):n.inputs[k].default_value=v
        else:lk.new(v,n.inputs[k])
    return n.outputs[0]
x=mathnode('SUBTRACT',sep.outputs['X'],.5);y=mathnode('SUBTRACT',sep.outputs['Y'],.5)
rad=mathnode('MULTIPLY',mathnode('SQRT',mathnode('ADD',mathnode('MULTIPLY',x,x),mathnode('MULTIPLY',y,y))),2)
uv=ns.new('ShaderNodeCombineXYZ');lk.new(rad,uv.inputs[0]);lk.new(sep.outputs['Z'],uv.inputs[1])
im=ns.new('ShaderNodeTexImage');im.image=bpy.data.images.load(str(ROOT/'data/density_RZ.png'));im.image.colorspace_settings.name='Non-Color';im.extension='CLIP';lk.new(uv.outputs[0],im.inputs[0])
lk.new(mathnode('MULTIPLY',im.outputs['Color'],.85),pv.inputs['Density']);lk.new(mathnode('MULTIPLY',im.outputs['Color'],1.2),pv.inputs['Emission Strength'])
volume.data.materials.append(vm)
# Each visible trace is an exact mean-flow circular arc at fixed R,z.
pts=np.load(ROOT/'data/tracers.npy');traces=[]
for k,(label,mat,num,omega) in enumerate([('e',cyan,150,M['omega_rad_s']['electron']),('D',gold,60,M['omega_rad_s']['deuterium']),('T',rose,60,M['omega_rad_s']['tritium'])]):
    start=[0,150,210][k]
    for j,x in enumerate(pts[start:start+num]):
        ob,sp=curve(label+' mean-flow tracer %03d'%j,np.tile(x,(56,1)),mat,.0014 if k==0 else .0022)
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=.004 if k==0 else .006,location=x)
        head=bpy.context.object;head.name=label+' luminous mean-flow head';head.data.materials.append(mat)
        traces.append((ob,sp,head,float(np.linalg.norm(x[:2])),math.atan2(x[1],x[0]),x[2],omega,k))
# Lighting participates only in rendering, never in the numerical field.
for name,loc,power,color in [('Cyan rim',(1,-3,3),180,(.04,.5,1)),('Warm rim',(-2,1,2),100,(1,.3,.06))]:
    da=bpy.data.lights.new(name,'AREA');da.energy=power;da.color=color;da.shape='DISK';da.size=3
    ob=bpy.data.objects.new(name,da);bpy.context.collection.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector((0,0,0))-ob.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.lens=50;cam.data.sensor_width=36;cam.data.clip_start=.01;cam.data.clip_end=100
scene.use_nodes=True;nd=scene.node_tree.nodes;nd.clear();rl=nd.new('CompositorNodeRLayers');gl=nd.new('CompositorNodeGlare');gl.glare_type='FOG_GLOW';gl.quality='HIGH';gl.threshold=1.2;gl.size=8
comp=nd.new('CompositorNodeComposite');scene.node_tree.links.new(rl.outputs['Image'],gl.inputs['Image']);scene.node_tree.links.new(gl.outputs['Image'],comp.inputs[0])
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def physical_time(t):
    # Common clock, same for every species. Cut to ion-scale exposure at 13 s.
    return t*4e-5 if t<13 else 13*4e-5+(t-13)*.075
def update(t):
    pt=physical_time(t);scale=4e-5 if t<13 else .075
    # Rotation changes the VIEWPOINT, never the mathematical configuration.
    az=-1.1+.019*t+.12*math.sin(t*.13);elev=.28+.20*smooth(t/8)+.18*math.sin(t*.105)
    # Keep the full shape safe inside both portrait and landscape crops.
    dist=4.65+1.9*smooth(t/8)+.2*math.sin(t*.15)
    cam.location=(dist*math.cos(elev)*math.cos(az),dist*math.cos(elev)*math.sin(az),dist*math.sin(elev))
    cam.rotation_euler=(Vector((0,0,.02))-cam.location).to_track_quat('-Z','Y').to_euler()
    fe.inputs[1].default_value=1.8
    for ob in field:ob.hide_render=t<21
    ce.inputs[1].default_value=4.2 if t<13 else 1.2
    de.inputs[1].default_value=3.8;te.inputs[1].default_value=3.3
    for ob,sp,head,R,ph,z,om,k in traces:
        # Exposure interval common to all species; long e exposure is exactly a full ring average.
        shutter=.12 if t<13 else .20
        arc=min(2*np.pi,abs(om)*scale*shutter)
        ang=ph+om*pt-np.sign(om)*np.linspace(0,arc,56)
        xyz=np.c_[R*np.cos(ang),R*np.sin(ang),np.full(56,z),np.ones(56)]
        sp.points.foreach_set('co',xyz.ravel());sp.use_cyclic_u=(arc>=2*np.pi)
        sp.points.foreach_set('radius',np.ones(56) if arc>=2*np.pi else np.linspace(1.8,.08,56))
        head.location=xyz[0,:3];head.hide_render=(arc>=2*np.pi)
        ob.hide_render=(k==0 and t>=13 and int(ob.name.split()[-1])%6!=0)
    scene.frame_set(round(t*FPS)+1)
    return pt

if '--preview' in sys.argv:
    for t in [0,7,17,28,36]:
        update(t);scene.render.filepath=str(ROOT/'renders'/f'preview_{t:02d}.png');bpy.ops.render.render(write_still=True)
    bpy.ops.file.pack_all()
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'production/countercirculation.blend'))
elif '--render' in sys.argv:
    output=ROOT/'renders/master';output.mkdir(exist_ok=True)
    start=int(sys.argv[sys.argv.index('--start')+1]) if '--start' in sys.argv else 0
    stop=int(sys.argv[sys.argv.index('--stop')+1]) if '--stop' in sys.argv else FPS*DURATION
    for i in range(start,stop):
        path=output/f'{i:05d}.png'
        if path.exists():continue
        update(i/FPS);scene.render.filepath=str(path);bpy.ops.render.render(write_still=True)
else:
    update(0);bpy.ops.file.pack_all();bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'production/countercirculation.blend'))
