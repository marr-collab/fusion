from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
ROOT=Path(__file__).resolve().parents[1];FINAL=ROOT/'final';FINAL.mkdir(exist_ok=True)
R=json.loads((ROOT/'data/visualization_receipt.json').read_text());g=np.load(ROOT/'data/field_grid.npz')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig,ax=plt.subplots(figsize=(5.7,3.5),layout='constrained')
im=ax.pcolormesh(g['R_m'],g['Z_m'],g['density_relative'],shading='auto',cmap='magma')
ax.contour(g['R_m'],g['Z_m'],np.ma.masked_where(~g['inside'],g['psi']),levels=np.max(g['psi'])*np.array([.075,.18,.34,.52,.71,.87,.96]),colors='#a8e8ff',linewidths=.8)
ax.set(xlabel='Cylindrical radius R (m)',ylabel='z (m)',title='Density and corrected poloidal flux');ax.set_aspect('equal');fig.colorbar(im,ax=ax,label='Electron density / peak density')
fig.savefig(ROOT/'data/field_receipt.png',dpi=190);plt.close(fig)
def equation(name,lines):
    fig=plt.figure(figsize=(7.5,.55*len(lines)));fig.patch.set_alpha(0)
    for i,eq in enumerate(lines):fig.text(.02,1-(i+.8)/len(lines),'$'+eq.replace(r'\frac12',r'\frac{1}{2}')+'$',fontsize=15,color='#112637')
    fig.savefig(ROOT/'data'/name,dpi=180,transparent=True,bbox_inches='tight',pad_inches=.05);plt.close(fig)
equation('eq_current.png',[r'n_D=n_T=\frac12 n_e,\quad \Omega_e=-\Omega,\quad \Omega_D=\frac{m_e}{m_D}\Omega,\quad\Omega_T=\frac{m_e}{m_T}\Omega',r'\ell_z=R^2\sum_s m_s n_s\Omega_s=m_en_e\Omega R^2(-1+\frac12+\frac12)=0',r'J_\phi=en_e\Omega R\left(1+\frac{m_e}{2m_D}+\frac{m_e}{2m_T}\right)>0'])
equation('eq_field.png',[r'-\Delta^*\hat\chi=\kappa\hat R^2\hat\chi^{3/2},\quad \hat\chi=\hat R^2u,\quad\hat\psi=\hat\chi-\frac12h\hat R^2',r'B_R=-B_*\hat R u_{,\hat z},\quad B_z=B_*(2u+\hat R u_{,\hat R}-h),\quad B_\phi=0',r'n_e\propto\chi^{3/2},\qquad p\propto\chi^{5/2}'])
equation('eq_waterbag.png',[r'f_s=C_s\mathbf{1}_{H_s-\Omega_sP_{\phi s}<0},\quad P_{\phi s}=m_sRv_\phi+q_s\psi'])
pdfmetrics.registerFont(TTFont('Segoe','C:/Windows/Fonts/segoeui.ttf'));pdfmetrics.registerFont(TTFont('SegoeB','C:/Windows/Fonts/seguisb.ttf'))
cv=canvas.Canvas(str(FINAL/'Countercirculation_Technical_Companion.pdf'),pagesize=(612,792));cv.setTitle('Current without net mechanical spin - visualization companion');cv.setAuthor('R. Wade H. Marr and Joseph Adam Thiel; visualization production with Codex')
style=ParagraphStyle('body',fontName='Segoe',fontSize=10.2,leading=15,textColor=HexColor('#213c4d'))
def para(text,y,size=10.2):
    st=ParagraphStyle('p',parent=style,fontSize=size,leading=size*1.45);p=Paragraph(text,st);w,h=p.wrap(510,700);p.drawOn(cv,51,y-h);return y-h-12
def heading(k,title,sub):
    cv.setFillColor(HexColor('#0b2637'));cv.rect(0,748,612,44,fill=1,stroke=0);cv.setFillColor(HexColor('#65d2ef'));cv.setFont('SegoeB',10);cv.drawString(51,765,'ADDRESS-FIRST FUSION POG / VISUALIZATION RECEIPT')
    cv.setFillColor(HexColor('#102e40'));cv.setFont('SegoeB',23);cv.drawString(51,705,title);cv.setFont('Segoe',10);cv.drawString(51,683,sub)
    cv.setFont('Segoe',8);cv.setFillColor(HexColor('#607988'));cv.drawString(51,30,'Reserved DOI: 10.5281/zenodo.23523832   |   20 October 2026');cv.drawRightString(561,30,str(k))
def img(name,x,y,w,h):cv.drawImage(str(ROOT/'data'/name),x,y,width=w,height=h,mask='auto',preserveAspectRatio=True,anchor='c')
heading(1,'The calculated organization','An oblate domain. Opposing mean circulation. A nonzero electric current.')
y=para('This 45-second film makes an existing stationary waterbag construction visible. Its key result is exact in that construction: the summed mechanical angular momentum cancels pointwise, while the electron, deuterium and tritium currents reinforce one another.',657)
img('field_receipt.png',85,360,442,240)
y=para('<b>Actual geometry.</b> R²/a² + z²/c² ≤ 1, with a = 1.202057 m, c = 0.692070 m, q = (a/c)² = 3.016827 and volume 4.188790 m³. The selected member has peak B = 5 T and peak electron temperature parameter 16.71 keV.',347)
y=para('<b>Regeneration, not invented field lines.</b> The archived degree-nine conditioned constructor regenerated χ and density with relative L² differences of 0.0 against the stored 2,304-point profile in this run. The historical strong-field residual is 0.0744%. The rendering uses a new 641 × 641 R–z field grid and contours of the corrected flux ψ.',y)
y=para('The density peaks away from the axis and vanishes at the boundary. Its bright annular region is a property of this computed member; no toroidal vessel or external coil geometry is inserted. The lavender curves show the admitted interior magnetic field only.',y)
y=para('<b>Scope.</b> Numerical visualization of a stationary, collisionless, quasineutral construction. It is not reactor footage, a stability demonstration or an integrated burning-plasma return.',y)
cv.showPage()
heading(2,'Why current survives','Charge-weighted circulation and mass-weighted angular momentum are different accounts.')
img('eq_waterbag.png',51,608,510,45)
img('eq_current.png',51,458,510,142)
data=[['Species','Rotation / rad s⁻¹','Angular momentum / kg m² s⁻¹'],['Electron','−65,743.1188568','−2.07095391846 × 10⁻⁴'],['Deuterium','+17.9113137401','+1.03547695923 × 10⁻⁴'],['Tritium','+11.9599919331','+1.03547695923 × 10⁻⁴'],['Sum','Not an angular velocity','0']]
tab=Table(data,colWidths=[80,153,277],rowHeights=28);tab.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'Segoe'),('FONTSIZE',(0,0),(-1,-1),9),('BACKGROUND',(0,0),(-1,0),HexColor('#dfedf2')),('TEXTCOLOR',(0,0),(-1,-1),HexColor('#173a4d')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LINEBELOW',(0,0),(-1,0),.5,HexColor('#a8c6d5'))]));tab.wrap(510,200);tab.drawOn(cv,51,299)
y=para('Mass ratios in the archived calculation: m<sub>D</sub>/m<sub>e</sub> = 3670.48 and m<sub>T</sub>/m<sub>e</sub> = 5496.92. The movie retains those rotation-rate ratios exactly. The tracers represent mean circulation, not the full thermal velocity of individual particles.',282)
img('eq_field.png',51,119,510,108)
para('The uniform centrifugal bias is retained: −0.373791 μT in B<sub>z</sub>. Zero net mechanical angular momentum does not mean zero individual rotation, zero centrifugal stress, or zero electromagnetic angular momentum.',105,9.4)
cv.showPage()
heading(3,'How to read and reproduce it','The numerical receipt and the cinematic treatment remain separately inspectable.')
y=657
for title,body in [
('One clock, two viewing scales','0–13 s: 40 μs of physical mean-flow time per film second. After 13 s: 75 ms per film second. All species use the same clock; positions are continuous across the change.'),
('Exposure, not altered ion speed','At the ion scale, fast electron circulation becomes a full-turn exposure average. Twenty-five representative cyan rings remain visible; the density volume retains the electron spatial profile. No separate speed multiplier is applied to fuel ions.'),
('A visible model, not an optical prediction','Cyan identifies electrons, amber deuterium, rose tritium and lavender calculated magnetic curves. Brightness, glow and camera lighting are illustrative. Density determines the spatial volume. Original ambient audio is sound design, not measured plasma sound.'),
('Exact source trail','Copied constructors: edge_regular_ritz.py → kinetic_constructor.py → conditioned_fields.py. Parameter receipt: Burn_Renewal/results/dimensional_results.json, q = 3.016827, degree 9, L = 1 m. Original research: R. Wade H. Marr and Joseph Adam Thiel.'),
('Machine-readable companion','TECHNICAL_COMPANION.md retains literal LaTeX. data/visualization_receipt.json records checks and source hashes. field_grid.npz, field_lines.json and tracers.npy contain the actual visual inputs.'),
('Reproduction','Run python production/regenerate_data.py; then Blender 4.3 with -b --python production/scene.py -- --render; then python production/finish_film.py. README.md contains the complete commands and environment. The original research archive remains unchanged.')]:
    y=para('<b>'+title+'.</b> '+body,y)
para('The exact cancellation belongs to the selected waterbag construction. This visualization does not establish collisional sustainment or reactor performance. Its purpose is to expose the difference between current and net mechanical spin through the actual constructed geometry and circulation.',y,9.4)
cv.save();print(FINAL/'Countercirculation_Technical_Companion.pdf')
